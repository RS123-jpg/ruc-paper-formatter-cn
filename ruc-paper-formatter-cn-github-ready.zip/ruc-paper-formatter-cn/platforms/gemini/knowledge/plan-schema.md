# 排版计划 JSON 说明

`inspect_docx.py` 生成 inventory 和 `plan_scaffold`。模型必须复核后再执行。

## 完整示例

```json
{
  "request_overrides": {
    "body_font_size_pt": {
      "value": 12,
      "source": "current_user_request",
      "evidence": "正文统一改为小四号"
    }
  },
  "template_requirements": {},
  "style_overrides": {
    "body": {
      "font_size_pt": 12
    }
  },
  "paragraph_roles": {
    "0": "title",
    "1": "author",
    "2": "author_info",
    "3": "abstract",
    "4": "keywords",
    "5": "heading1",
    "6": "body",
    "7": "table_caption",
    "8": "references_heading",
    "9": "reference_item"
  },
  "insertions": [
    {
      "before_paragraph": 5,
      "role": "abstract",
      "text": "［摘要］依据全文生成的摘要。",
      "source": "model_generated",
      "evidence_paragraphs": [5, 12, 18, 23]
    }
  ],
  "manual_citation_conversions": [
    {
      "paragraph": 6,
      "marker_text": "①",
      "occurrence": 1,
      "reference_paragraph": 22,
      "confidence": "medium",
      "reason": "按角标序号与文末条目匹配，需结合上下文复核"
    }
  ],
  "reference_links": [
    {
      "footnote_id": "3",
      "reference_paragraph": 9
    }
  ],
  "tables": {
    "0": {
      "mode": "three_line",
      "header_rows": 1,
      "format_text": true,
      "font_size": 9,
      "body_alignment": "preserve"
    },
    "1": {
      "mode": "preserve",
      "header_rows": 0,
      "format_text": false
    }
  },
  "options": {
    "normalize_heading_numbers": true,
    "apply_three_line_tables": true,
    "convert_caption_crossrefs": true,
    "deduplicate_identical_footnotes": false,
    "citation_mode": "ruc_page_footnote",
    "convert_manual_superscripts": true,
    "footnote_numbering": "eachPage",
    "footnote_number_format": "decimalEnclosedCircle",
    "footnote_marker_size_pt": 10.5,
    "footnote_text_size_pt": 9.0,
    "body_footnote_reference_size_pt": 9.0,
    "add_centered_page_numbers": true,
    "page_setup_mode": "normalize_portrait_except_landscape",
    "update_fields_on_open": false,
    "ruc_header": {
      "enabled": false,
      "scope": "all_pages",
      "logo_width_cm": 3.85,
      "header_distance_cm": 1.5,
      "replace_existing": true,
      "line_size_eighth_points": 6,
      "line_space_pt": 1,
      "line_color": "000000"
    },
    "section_overrides": {
      "0": {
        "top_margin_cm": 2.5,
        "bottom_margin_cm": 2.5,
        "left_margin_cm": 2.8,
        "right_margin_cm": 2.5
      }
    }
  }
}
```

## 本次对话覆盖项

`request_overrides` 记录用户在当前消息及同一对话中针对本次文档提出的明确格式要求。每项应包含：

- `value`：最终采用值；
- `source`：通常为 `current_user_request`，也可为 `conversation_requirement` 或 `uploaded_template`；
- `evidence`：用户原话或简洁释义，便于修改报告追溯。

规则合并采用局部覆盖：只覆盖明确指定项目，未指定项目继续使用模板或默认规范。同一项目有多次要求时，采用同一对话中最新且最具体的一条。若用户未提出额外要求，`request_overrides` 使用空对象 `{}`，完整执行默认规范。

修改报告必须列出 `request_overrides`，不得让用户无法判断哪些规则来自本次要求、模板或默认规范。

`request_overrides` 是追溯信息，不会单独改变文档。模型必须同步写入实际执行字段。常用映射：

- 字体、字号、对齐、段前段后、行距、首行缩进、悬挂缩进 → `style_overrides`；
- 页边距、纸张、页眉页脚距离 → `options.section_overrides`；
- 是否保留标题编号、脚注模式、页码 → `options`；
- 表格边框、表头行数和字体 → `tables`。

### 段落样式覆盖

`style_overrides` 按段落角色局部覆盖默认样式。支持字段：

- `east_asia_font`、`latin_font`、`font_size_pt`；
- `bold`、`italic`；
- `alignment`：`left`、`center`、`right`、`justify`；
- `line_spacing_pt`、`space_before_pt`、`space_after_pt`；
- `first_line_indent_chars` 或 `first_line_indent_pt`；
- `hanging_indent_chars` 或 `hanging_indent_pt`；
- `keep_with_next`、`keep_together`；
- 摘要/关键词标签可另设 `label_east_asia_font`、`label_latin_font`、`label_font_size_pt`、`label_bold`。

只写用户明确改变的属性，未写属性继续使用模板或默认值。

## 段落角色

`title`、`subtitle`、`author`、`author_info`、`abstract`、`keywords`、`heading1`、`heading2`、`heading3`、`heading4`、`body`、`figure_caption`、`table_caption`、`figure_or_table_note`、`references_heading`、`reference_item`、`appendix_heading`、`english_title`、`english_abstract`、`english_keywords`、`blank`、`no_change`。

## 表格配置

- `mode=three_line`：普通数据表；仅保留顶线、表头底线、底线。
- `mode=standard`：简单完整框线表。
- `mode=preserve`：不改边框、字号和对齐，适用于复杂表。
- `header_rows`：重复表头行数；多层表头可设为 2 或以上。
- `body_alignment`：`preserve`、`left`、`center` 或 `right`。

不得用一个全局开关强制处理所有表格。

## 摘要和关键词插入

- 仅在完全缺失时使用。
- `text` 必须使用行内格式：摘要为 `［摘要］正文`，关键词为 `［关键词］词1；词2；词3`；标签后不换行、不空格、不加冒号。
- `before_paragraph` 使用原稿顶层段落索引。
- 摘要必须提供 `evidence_paragraphs`，列出支撑核心信息的原稿段落。
- 生成摘要中出现的数字和明确方法名称必须能在原稿中找到。

## 脚注到参考文献链接

`reference_links` 由模型根据脚注和文末书目内容确认。`footnote_id` 是真实 Word 脚注 ID，`reference_paragraph` 是原稿中文末书目段落索引。脚本只建立内部超链接，不改变可见文字。候选项仅供参考，不能未经复核直接采用。

## 页面与分节

- `page_setup_mode=normalize_portrait_except_landscape`：普通纵向节统一，原有横向节保留。
- `page_setup_mode=preserve_all`：全部分节保持原样。
- `section_overrides`：只覆盖明确指定的节。


## 手工角标转真实脚注

`manual_citation_conversions` 用于把作者手工输入的上标数字或圈码转换成 Word 真实脚注。

- `paragraph`：原稿顶层段落索引。
- `marker_text`：原稿中可见的手工角标，如 `1`、`①`。
- `occurrence`：该标记在同一段中的第几次出现，1 起算。
- `reference_paragraph`：作为脚注出处文字来源的文末参考文献段落。也可直接提供 `footnote_text`。
- `confidence`：`high`、`medium` 或 `low`。低置信度允许转换，但必须在报告中提示人工复核。

严格学报模式下，默认 `citation_mode=ruc_page_footnote`、`footnote_numbering=eachPage`、`deduplicate_identical_footnotes=false`：每一处引用均转换为独立的真实脚注，正文显示右上角圈码，出处放在当页页底。默认页底脚注序号为 10.5 pt，脚注正文为 9 pt，正文中的上标引用号为 9 pt。文末参考文献表不是该模式的必需组成部分；原稿已有时保留，不擅自删除，并强制从“参考文献”标题处另起一页。


## 本地版式稳定性

- `update_fields_on_open` 默认必须为 `false`。排版器会保留真实 `SEQ`、`REF`、`PAGE` 和脚注字段，同时写入缓存显示结果；关闭打开时自动更新可避免 Word/WPS 下载后立即重排。
- 只有用户明确要求“打开文件时自动刷新全部字段”时，才设为 `true`，并必须在修改报告中提示可能发生重新分页。
- 字体使用宋体、黑体、仿宋和 Times New Roman 等 Windows 常见字体名，不使用仅部分机器存在的 `仿宋_GB2312`。

## 中国人民大学标志页眉

默认不添加。仅当用户明确要求“添加人大页眉”、上传模板明确包含该页眉，或本次对话将其设为格式要求时，才在 `options.ruc_header` 中启用。

- `enabled`：是否添加。
- `scope`：`all_pages`（全部页面）、`except_first_page`（首页不加）、`first_page_only`（仅首页）。默认 `all_pages`。
- `logo_width_cm`：标志图片显示宽度，默认 3.85 cm；保持原始纵横比。
- `header_distance_cm`：页眉距页面顶端，默认 1.5 cm。
- `replace_existing`：是否替换已有页眉。默认 `true`；若用户要求保留其他页眉内容，设为 `false` 并在报告中说明未覆盖。
- `line_size_eighth_points`：下划线粗细，Word 单位为八分之一磅；默认 6，即 0.75 pt。
- `line_space_pt`、`line_color`：线与内容间距及颜色。

实现必须使用居中的行内图片和页眉段落下边框，不使用制表符、浮动图片、文本框或绝对定位，以降低 WPS 与 Word 间的版式漂移。页眉素材来自用户提供的示例文档，存放于 `assets/ruc-header-logo.png`。


## WPS题名布局表

若 inventory 中某个表格标记 `frontmatter_layout=true`，必须设置为 `mode=preserve`。排版器会自动将其扩展至正文版心宽度、清除边框，并将其中的题名和作者段落重建为普通居中段落；不得把此类布局表转换为三线表。
