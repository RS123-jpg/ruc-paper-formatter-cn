# Gemini Gems 配置

Gemini 不能保证直接导入 OpenAI 风格的 `skill.zip` 并执行其中的 Python 脚本，因此本包提供可复制的 Gem 指令和本地执行器。

## 建议配置

1. 新建一个 Gem，名称设为“中文论文统一排版”；
2. 将 `GEM_INSTRUCTIONS.md` 的内容粘贴到 Gem 指令；
3. 将 `knowledge/` 中的四个 Markdown 文件上传为知识文件；
4. 将待处理论文先用本地命令准备：

```bash
python scripts/portable_workflow.py prepare input.docx --job-dir paper_job
```

5. 把 `paper_job/document_text.md`、`paper_job/inventory.json` 和 `paper_job/plan.json` 上传给 Gem；
6. 要求 Gem 返回修订后的完整 `plan.json`；
7. 本地执行：

```bash
python scripts/portable_workflow.py apply input.docx --job-dir paper_job --output output_formatted.docx
```

Gem 若具备可用的代码执行和文件写入工具，也可以尝试直接运行根目录工作流；否则不要让它声称已经生成最终 DOCX。
