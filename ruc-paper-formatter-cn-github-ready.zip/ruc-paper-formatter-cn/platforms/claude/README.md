# Claude 使用方式

## Claude Code 或具备终端能力的环境

将整个文件夹加入项目，安装依赖，然后要求 Claude 先读取根目录 `SKILL.md` 并执行完整工作流。

## Claude Projects / 普通对话

上传 `platforms/generic/MASTER_PROMPT.md` 和 `references/` 下的规范文件。若无法直接运行脚本，使用 `portable_workflow.py prepare/apply` 的两阶段模式。
