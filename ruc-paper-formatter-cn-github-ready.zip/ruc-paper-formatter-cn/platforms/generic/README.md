# 任意 AI 的通用使用方法

适用于不能原生安装 `SKILL.md` 的 AI。

1. 将 `MASTER_PROMPT.md` 设为系统指令、项目指令或首条固定提示词；
2. 本地运行：

```bash
python scripts/portable_workflow.py prepare input.docx --job-dir paper_job
```

3. 上传 `paper_job/document_text.md`、`inventory.json`、`plan.json`；
4. 要求 AI 返回完整、可解析的 `plan.json`，不要只给修改建议；
5. 覆盖本地 `paper_job/plan.json`；
6. 执行：

```bash
python scripts/portable_workflow.py apply input.docx --job-dir paper_job --output output_formatted.docx
```
