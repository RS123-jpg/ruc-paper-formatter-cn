# ChatGPT / OpenAI 使用方式

## ChatGPT Skills

直接上传整个 `skill.zip`。安装后上传 `.docx` 并输入：

> 使用中文论文统一排版处理这篇论文，全部按默认规范执行。

可选页眉：

> 按默认规范排版，并添加中国人民大学校名标志页眉。

局部覆盖：

> 正文改为小四号，其他项目按默认规范执行。

## Codex 或可运行本地命令的 OpenAI 智能体

将整个文件夹放入技能目录，安装 `scripts/requirements.txt`，然后让智能体读取根目录 `SKILL.md`。
