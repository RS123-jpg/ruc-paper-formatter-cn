# WorkBuddy 使用方式

WorkBuddy 的具体技能导入入口可能随版本变化。本包提供两种适配方式。

## 完整模式：可访问本地文件和终端

1. 将整个 `ruc-paper-formatter-cn` 文件夹放入 WorkBuddy 可访问的工作区或技能目录；
2. 安装：

```bash
python -m pip install -r scripts/requirements.txt
```

3. 在任务中明确要求它先读取根目录 `SKILL.md`；
4. 上传或指定待处理 `.docx`，让其执行检查、计划、排版、验证和报告。

## 兼容模式：只能对话或不能运行本地脚本

1. 将 `platforms/generic/MASTER_PROMPT.md` 作为长期指令或首条任务说明；
2. 本地运行 `portable_workflow.py prepare`；
3. 把生成的 `document_text.md`、`inventory.json`、`plan.json` 提供给 WorkBuddy；
4. 让它只完成 `plan.json`；
5. 本地运行 `portable_workflow.py apply`。

## 调用示例

> 读取 ruc-paper-formatter-cn/SKILL.md，按默认规范处理 input.docx，不添加人大页眉，输出排版稿和简明报告。
