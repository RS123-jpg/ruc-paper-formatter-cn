#!/usr/bin/env python3
"""Inspect a DOCX and emit a formatting inventory/plan scaffold as JSON.

This script never modifies the document. It is designed for use by the
academic-paper-formatter-cn skill before applying formatting.
"""
from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path
from typing import Any

from docx import Document
from lxml import etree

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W_NS}

CN = "一二三四五六七八九十百零〇"
CIRCLED = "①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳"


def suggest_role(text: str, index: int) -> str:
    s = text.strip()
    if not s:
        return "blank"
    if re.match(r"^[［\[]?\s*(?:摘\s*要|中文摘要|内容摘要)\s*[］\]]?\s*[:：]?", s):
        return "abstract"
    if re.match(r"^[［\[]?\s*(?:关键词|关键字|主题词)\s*[］\]]?\s*[:：]?", s):
        return "keywords"
    if re.fullmatch(r"(?:主要)?参考文献\s*[:：]?", s):
        return "references_heading"
    if re.match(r"^附录(?:[A-ZＡ-Ｚ一二三四五六七八九十0-9]+)?", s):
        return "appendix_heading"
    if re.match(rf"^[{CN}]+、", s):
        return "heading1"
    if re.match(rf"^（[{CN}]+）", s):
        return "heading2"
    if re.match(r"^\d+[\.．]\s*", s):
        return "heading3"
    if re.match(r"^（\d+）", s):
        return "heading4"
    if re.match(r"^图\s*\d+(?:[\.．]\d+)?\s*", s):
        return "figure_caption"
    if re.match(r"^表\s*\d+(?:[\.．]\d+)?\s*", s):
        return "table_caption"
    if re.match(r"^(注|数据来源|资料来源)[:：]", s):
        return "figure_or_table_note"
    if re.match(r"^Abstract[:：]?", s, re.I):
        return "english_abstract"
    if re.match(r"^Key\s*words?[:：]?", s, re.I):
        return "english_keywords"
    if index < 8 and re.search(r"(学号|课程|学院|学校|班级|专业|作者|姓名)[:：]", s):
        return "author_info"
    if index == 0:
        return "title"
    return "body"


def _looks_like_author_info(text: str) -> bool:
    value = re.sub(r"\s+", " ", text.strip())
    if not value:
        return False
    if re.search(r"(?:作者|姓名|学号|课程|班级|专业|学院|学校)\s*[:：]", value):
        return True
    return bool(
        re.fullmatch(r"\d{6,}\s*[\u4e00-\u9fff·]{2,12}", value)
        or re.fullmatch(r"[\u4e00-\u9fff·]{2,12}\s*\d{6,}", value)
    )


def _looks_like_author_name(text: str) -> bool:
    value = re.sub(r"\s+", "", text.strip())
    return bool(re.fullmatch(r"[\u4e00-\u9fff·]{2,8}(?:、[\u4e00-\u9fff·]{2,8}){0,4}", value))


def promote_frontmatter_roles(paragraphs: list[dict[str, Any]]) -> None:
    boundary = len(paragraphs)
    for item in paragraphs:
        if item["suggested_role"] in {"abstract", "keywords", "heading1", "references_heading", "english_abstract"}:
            boundary = item["index"]
            break
    visible = [x for x in paragraphs[:boundary] if x["text"].strip()]
    if not visible:
        return
    titles = [x for x in visible if x["suggested_role"] == "title"]
    title = titles[0] if titles else visible[0]
    title["suggested_role"] = "title"
    subtitle_seen = any(x["suggested_role"] == "subtitle" for x in visible)
    author_seen = any(x["suggested_role"] in {"author", "author_info"} for x in visible)
    after_title = False
    for item in visible:
        if item is title:
            after_title = True
            continue
        if not after_title or item["suggested_role"] not in {"body", "no_change"}:
            continue
        value = re.sub(r"\s+", " ", item["text"].strip())
        if re.match(r"^(?:——|—{2,}|--)", value):
            item["suggested_role"] = "subtitle"
            subtitle_seen = True
        elif _looks_like_author_info(value):
            item["suggested_role"] = "author_info"
            author_seen = True
        elif _looks_like_author_name(value):
            item["suggested_role"] = "author"
            author_seen = True
        else:
            sentence_like = value.endswith(("。", "！", "？", "；")) or len(value) > 90
            if not subtitle_seen and not sentence_like:
                item["suggested_role"] = "subtitle"
                subtitle_seen = True
            elif not author_seen and len(value) <= 50 and not sentence_like:
                item["suggested_role"] = "author_info"
                author_seen = True


def paragraph_has_drawing(paragraph) -> bool:
    return bool(paragraph._p.xpath(".//w:drawing|.//w:pict"))


def read_package_xml(docx_path: Path) -> dict[str, Any]:
    out: dict[str, Any] = {
        "footnotes": [],
        "field_counts": {"SEQ": 0, "REF": 0, "NOTEREF": 0, "PAGE": 0, "other": 0},
        "bookmarks": [],
    }
    parser = etree.XMLParser(remove_blank_text=False)
    with zipfile.ZipFile(docx_path, "r") as zf:
        names = set(zf.namelist())
        if "word/document.xml" in names:
            root = etree.fromstring(zf.read("word/document.xml"), parser)
            for instr in root.xpath(".//w:instrText", namespaces=NS):
                code = " ".join((instr.text or "").split()).upper()
                matched = False
                for key in ("NOTEREF", "SEQ", "REF", "PAGE"):
                    if re.search(rf"\b{key}\b", code):
                        out["field_counts"][key] += 1
                        matched = True
                        break
                if code and not matched:
                    out["field_counts"]["other"] += 1
            for bm in root.xpath(".//w:bookmarkStart", namespaces=NS):
                name = bm.get(f"{{{W_NS}}}name")
                if name:
                    out["bookmarks"].append(name)
        if "word/footnotes.xml" in names:
            root = etree.fromstring(zf.read("word/footnotes.xml"), parser)
            for fn in root.xpath("./w:footnote", namespaces=NS):
                fn_id = fn.get(f"{{{W_NS}}}id")
                if fn_id in {"-1", "0"}:
                    continue
                text = "".join(fn.xpath(".//w:t/text()", namespaces=NS)).strip()
                out["footnotes"].append({"id": fn_id, "text": text})
    return out



def marker_number(text: str) -> int | None:
    t = text.strip()
    if re.fullmatch(r"[0-9]+", t):
        return int(t)
    if len(t) == 1 and t in CIRCLED:
        return CIRCLED.index(t) + 1
    return None


def manual_citation_candidates(doc: Document, paragraphs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    refs = [x for x in paragraphs if x.get("suggested_role") == "reference_item" and x.get("text", "").strip()]
    out: list[dict[str, Any]] = []
    allowed = {"body", "abstract", "keywords", "heading1", "heading2", "heading3", "heading4"}
    for pidx, p in enumerate(doc.paragraphs):
        role = paragraphs[pidx]["suggested_role"] if pidx < len(paragraphs) else "body"
        if role not in allowed:
            continue
        seen: dict[str, int] = {}
        for ridx, run in enumerate(p.runs):
            raw = run.text or ""
            # A visible circled number is citation-like even when the author forgot to set superscript.
            markers = list(re.finditer(rf"[{CIRCLED}]", raw))
            if run.font.superscript is True:
                markers += list(re.finditer(rf"(?<!\d)\d{{1,3}}(?!\d)", raw))
            markers.sort(key=lambda m: m.start())
            for m in markers:
                marker = m.group(0)
                n = marker_number(marker)
                if n is None:
                    continue
                seen[marker] = seen.get(marker, 0) + 1
                item: dict[str, Any] = {
                    "paragraph": pidx,
                    "run_index": ridx,
                    "marker_text": marker,
                    "occurrence": seen[marker],
                    "marker_number": n,
                    "kind": "superscript" if run.font.superscript is True else "visible_circled",
                    "context": p.text[:180],
                }
                if 1 <= n <= len(refs):
                    ref = refs[n - 1]
                    item.update({
                        "suggested_reference_paragraph": ref["index"],
                        "suggested_reference_text": ref["text"][:220],
                        "confidence": "high" if marker == str(n) or marker == CIRCLED[n-1] else "medium",
                    })
                else:
                    item.update({"confidence": "low", "warning": "角标序号超出文末参考文献条目范围。"})
                out.append(item)
    return out


def normalize_reference_text(text: str) -> str:
    return re.sub(r"[^0-9A-Za-z\u4e00-\u9fff]", "", text).lower()


def reference_link_candidates(paragraphs, footnotes):
    refs = []
    in_refs = False
    for item in paragraphs:
        if item["suggested_role"] == "references_heading":
            in_refs = True
            continue
        if in_refs and item["text"].strip():
            refs.append(item)
    candidates = []
    for fn in footnotes:
        fkey = normalize_reference_text(fn.get("text", ""))
        scored = []
        for ref in refs:
            rkey = normalize_reference_text(ref["text"])
            if not fkey or not rkey:
                continue
            common = 0
            # Conservative title/author substring signal; model must review.
            for size in range(min(24, len(fkey), len(rkey)), 5, -1):
                if any(fkey[i:i+size] in rkey for i in range(0, max(1, len(fkey)-size+1))):
                    common = size
                    break
            if common:
                scored.append({"reference_paragraph": ref["index"], "score": common, "text": ref["text"][:160]})
        scored.sort(key=lambda x: x["score"], reverse=True)
        if scored:
            candidates.append({"footnote_id": fn.get("id"), "footnote_text": fn.get("text", "")[:160], "candidates": scored[:3]})
    return candidates

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_docx", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()

    doc = Document(args.input_docx)
    paragraphs = []
    in_references = False
    for i, p in enumerate(doc.paragraphs):
        text = p.text
        role = suggest_role(text, i)
        stripped = text.strip()
        if role == "references_heading":
            in_references = True
        elif in_references:
            if re.match(r"^(?:附录|致谢|作者简介|英文摘要|Abstract)\b", stripped, re.I):
                in_references = False
            elif stripped:
                role = "reference_item"
        paragraphs.append(
            {
                "index": i,
                "text": text,
                "style": p.style.name if p.style is not None else "",
                "suggested_role": role,
                "has_drawing": paragraph_has_drawing(p),
                "has_field": bool(p._p.xpath(".//w:instrText|.//w:fldSimple")),
                "run_count": len(p.runs),
            }
        )

    if not any(x["suggested_role"] == "title" and x["text"].strip() for x in paragraphs):
        for item in paragraphs[:20]:
            if not item["text"].strip():
                continue
            if item["suggested_role"] in {"abstract", "keywords", "heading1", "references_heading"}:
                break
            item["suggested_role"] = "title"
            break
    promote_frontmatter_roles(paragraphs)

    tables = []
    table_plan = {}
    for i, table in enumerate(doc.tables):
        tbl = table._tbl
        complex_features = {
            "merged_cells": bool(tbl.xpath(".//w:gridSpan[@w:val != '1']|.//w:vMerge")),
            "nested_tables": bool(tbl.xpath(".//w:tbl")),
            "drawings_or_objects": bool(tbl.xpath(".//w:drawing|.//w:object")),
            "many_columns": len(table.columns) > 10,
        }
        is_complex = any(complex_features.values())
        frontmatter_layout = False
        if i < 3 and len(table.rows) <= 8 and len(table.columns) <= 2:
            title_like = False
            for row in table.rows:
                for cell in row.cells:
                    for paragraph in cell.paragraphs:
                        value = paragraph.text.strip()
                        sizes = [run.font.size.pt for run in paragraph.runs if run.font.size is not None]
                        max_size = max(sizes, default=0)
                        if value and re.search(r"[\u4e00-\u9fff]", value) and len(value) <= 120 and max_size >= 16:
                            title_like = True
            frontmatter_layout = title_like
        suggested_mode = "preserve" if is_complex or frontmatter_layout else "three_line"
        tables.append(
            {
                "index": i,
                "rows": len(table.rows),
                "columns": len(table.columns),
                "complex_features": complex_features,
                "suggested_mode": suggested_mode,
                "frontmatter_layout": frontmatter_layout,
                "preview": [[cell.text[:80] for cell in row.cells] for row in table.rows[:3]],
            }
        )
        table_plan[str(i)] = {
            "mode": suggested_mode,
            "header_rows": 1 if table.rows and not is_complex else 0,
            "format_text": not is_complex,
            "font_size": 9,
            "body_alignment": "preserve",
        }

    pkg = read_package_xml(args.input_docx)
    roles = {str(p["index"]): p["suggested_role"] for p in paragraphs}
    role_values = set(roles.values())
    front_texts = [p["text"].strip() for p in paragraphs[:50]]
    for table in doc.tables[:8]:
        for row in table.rows:
            for cell in row.cells:
                front_texts.extend(p.text.strip() for p in cell.paragraphs)
    abstract_present = "abstract" in role_values or any(re.match(r"^[［\[]?\s*(?:摘\s*要|中文摘要|内容摘要)\s*[］\]]?\s*[:：]?", t) for t in front_texts if t)
    keywords_present = "keywords" in role_values or any(re.match(r"^[［\[]?\s*(?:关键词|关键字|主题词)\s*[］\]]?\s*[:：]?", t) for t in front_texts if t)

    # Prefer insertion before the first heading. If no heading exists, use the
    # first substantive paragraph after a short front-matter allowance. The
    # model must still review this suggestion because author lines are semantic.
    suggested_insert_before = len(paragraphs)
    for item in paragraphs:
        if item["suggested_role"] in {"heading1", "heading2", "heading3", "heading4"}:
            suggested_insert_before = item["index"]
            break
    if suggested_insert_before == len(paragraphs):
        for item in paragraphs:
            if item["index"] >= 3 and item["suggested_role"] == "body":
                suggested_insert_before = item["index"]
                break

    manual_candidates = manual_citation_candidates(doc, paragraphs)
    default_manual_conversions = [
        {
            "paragraph": x["paragraph"],
            "marker_text": x["marker_text"],
            "occurrence": x["occurrence"],
            "reference_paragraph": x["suggested_reference_paragraph"],
            "confidence": x.get("confidence", "medium"),
            "reason": "按手工角标序号匹配文末同序号参考文献；模型需结合上下文复核。",
        }
        for x in manual_candidates if "suggested_reference_paragraph" in x
    ]

    inventory = {
        "input": str(args.input_docx),
        "paragraphs": paragraphs,
        "tables": tables,
        "footnotes": pkg["footnotes"],
        "reference_link_candidates": reference_link_candidates(paragraphs, pkg["footnotes"]),
        "manual_citation_candidates": manual_candidates,
        "field_counts": pkg["field_counts"],
        "bookmarks": pkg["bookmarks"],
        "section_presence": {
            "chinese_abstract": abstract_present,
            "chinese_keywords": keywords_present,
            "suggested_insert_before_paragraph": suggested_insert_before,
        },
        "plan_scaffold": {
            "paragraph_roles": roles,
            "insertions": [],
            "reference_links": [],
            "manual_citation_conversions": default_manual_conversions,
            "tables": table_plan,
            "options": {
                "normalize_heading_numbers": True,
                "apply_three_line_tables": True,
                "convert_caption_crossrefs": True,
                "deduplicate_identical_footnotes": False,
                "citation_mode": "ruc_page_footnote",
                "convert_manual_superscripts": True,
                "footnote_numbering": "eachPage",
                "footnote_number_format": "decimalEnclosedCircle",
                "add_centered_page_numbers": True,
                "page_setup_mode": "normalize_portrait_except_landscape",
                "update_fields_on_open": False,
                "section_overrides": {},
            },
        },
    }
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(inventory, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] inventory written to {args.out}")


if __name__ == "__main__":
    main()
