#!/usr/bin/env python3
"""Regression test for citation, footnote, and bibliography handling."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

from docx import Document
from lxml import etree

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKGREL = "http://schemas.openxmlformats.org/package/2006/relationships"
CT = "http://schemas.openxmlformats.org/package/2006/content-types"
NS = {"w": W, "rel": PKGREL, "ct": CT}
HERE = Path(__file__).resolve().parent


def run(*args: str) -> None:
    proc = subprocess.run([sys.executable, *args], text=True, capture_output=True)
    if proc.returncode:
        raise RuntimeError(proc.stdout + "\n" + proc.stderr)


def xb(root: etree._Element) -> bytes:
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone="yes")


def insert_footnote(src: Path, dst: Path, marker: str, text: str) -> None:
    with zipfile.ZipFile(src) as zin:
        doc = etree.fromstring(zin.read("word/document.xml"))
        if "word/footnotes.xml" in zin.namelist():
            notes = etree.fromstring(zin.read("word/footnotes.xml"))
        else:
            notes = etree.Element(f"{{{W}}}footnotes", nsmap={"w": W, "r": R})
            for fid, tag in (("-1", "separator"), ("0", "continuationSeparator")):
                fn = etree.SubElement(notes, f"{{{W}}}footnote"); fn.set(f"{{{W}}}id", fid)
                p = etree.SubElement(fn, f"{{{W}}}p"); r = etree.SubElement(p, f"{{{W}}}r")
                etree.SubElement(r, f"{{{W}}}{tag}")
        ids = [int(x.get(f"{{{W}}}id")) for x in notes.findall(f"{{{W}}}footnote") if (x.get(f"{{{W}}}id") or "").isdigit()]
        fid = max(ids or [0]) + 1
        fn = etree.SubElement(notes, f"{{{W}}}footnote"); fn.set(f"{{{W}}}id", str(fid))
        p = etree.SubElement(fn, f"{{{W}}}p")
        r = etree.SubElement(p, f"{{{W}}}r"); etree.SubElement(r, f"{{{W}}}footnoteRef")
        r = etree.SubElement(p, f"{{{W}}}r"); t = etree.SubElement(r, f"{{{W}}}t"); t.text = " " + text
        inserted = False
        for t in doc.xpath(".//w:t", namespaces=NS):
            if t.text and marker in t.text:
                t.text = t.text.replace(marker, "")
                r = t.getparent(); parent = r.getparent(); pos = parent.index(r)
                nr = etree.Element(f"{{{W}}}r"); ref = etree.SubElement(nr, f"{{{W}}}footnoteReference"); ref.set(f"{{{W}}}id", str(fid))
                parent.insert(pos + 1, nr); inserted = True; break
        assert inserted
        rels = etree.fromstring(zin.read("word/_rels/document.xml.rels"))
        if not rels.xpath("./rel:Relationship[contains(@Type,'/footnotes')]", namespaces=NS):
            nums = []
            for x in rels.findall(f"{{{PKGREL}}}Relationship"):
                rid = x.get("Id") or ""
                if rid.startswith("rId") and rid[3:].isdigit(): nums.append(int(rid[3:]))
            rel = etree.SubElement(rels, f"{{{PKGREL}}}Relationship")
            rel.set("Id", f"rId{max(nums or [0])+1}"); rel.set("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes"); rel.set("Target", "footnotes.xml")
        cts = etree.fromstring(zin.read("[Content_Types].xml"))
        if not cts.xpath("./ct:Override[@PartName='/word/footnotes.xml']", namespaces=NS):
            ov = etree.SubElement(cts, f"{{{CT}}}Override"); ov.set("PartName", "/word/footnotes.xml"); ov.set("ContentType", "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml")
        overrides = {"word/document.xml": xb(doc), "word/footnotes.xml": xb(notes), "word/_rels/document.xml.rels": xb(rels), "[Content_Types].xml": xb(cts)}
        with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zout:
            names = {i.filename for i in zin.infolist()}
            for info in zin.infolist(): zout.writestr(info.filename, overrides.get(info.filename, zin.read(info.filename)))
            for name, data in overrides.items():
                if name not in names: zout.writestr(name, data)


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="paperfmt-citation-") as td:
        d = Path(td); base = d / "base.docx"
        doc = Document()
        doc.add_paragraph("测试论文")
        doc.add_paragraph("［摘要］本文用于验证脚注和参考文献处理。")
        doc.add_paragraph("［关键词］脚注；交叉引用；参考文献")
        doc.add_paragraph("一、问题提出")
        doc.add_paragraph("第一处引用。[[A]]")
        doc.add_paragraph("完全相同的重复引用。[[B]]")
        doc.add_paragraph("同一文献不同页码。[[C]]")
        doc.add_paragraph("手工方括号[1]、圈码①和著者—年份（张三，2024）用于转换与审计。")
        p = doc.add_paragraph("手工上标")
        r = p.add_run("2"); r.font.superscript = True
        doc.add_paragraph("参考文献")
        doc.add_paragraph("[1] 张三. 平台治理研究[J]. 经济研究, 2024, 59(3): 45-68.")
        doc.save(base)
        f1=d/'f1.docx'; f2=d/'f2.docx'; src=d/'input.docx'
        n1="张三：《平台治理研究》，载《经济研究》，2024年第3期，第45页。"
        n2="张三：《平台治理研究》，载《经济研究》，2024年第3期，第68页。"
        insert_footnote(base,f1,'[[A]]',n1); insert_footnote(f1,f2,'[[B]]',n1); insert_footnote(f2,src,'[[C]]',n2)
        inv=d/'inv.json'; plan=d/'plan.json'; out=d/'out.docx'; report=d/'report.md'
        run(str(HERE/'inspect_docx.py'), str(src), '--out', str(inv))
        data=json.loads(inv.read_text(encoding='utf-8'))
        assert data['paragraphs'][-1]['suggested_role'] == 'reference_item'
        assert len(data['reference_link_candidates']) == 3
        pl=data['plan_scaffold']; pl['options']['deduplicate_identical_footnotes']=True; pl['reference_links']=[
            {'footnote_id':'1','reference_paragraph':10},
            {'footnote_id':'3','reference_paragraph':10},
        ]
        plan.write_text(json.dumps(pl,ensure_ascii=False),encoding='utf-8')
        run(str(HERE/'format_academic_docx.py'), str(src), str(out), '--plan', str(plan), '--report', str(report))
        run(str(HERE/'verify_formatted_docx.py'), str(out))
        with zipfile.ZipFile(out) as zf:
            root=etree.fromstring(zf.read('word/document.xml'))
            notes=etree.fromstring(zf.read('word/footnotes.xml'))
            assert len(root.xpath(".//w:instrText[contains(text(),'NOTEREF')]",namespaces=NS)) == 1
            positive=[x for x in notes.xpath('./w:footnote',namespaces=NS) if int(x.get(f'{{{W}}}id')) > 0]
            assert len(positive) == 3
            marker_runs = notes.xpath('.//w:footnote[not(@w:id="-1") and not(@w:id="0")]//w:r[w:footnoteRef]', namespaces=NS)
            assert marker_runs
            for mr in marker_runs:
                sz = mr.find('w:rPr/w:sz', namespaces=NS)
                assert sz is not None and sz.get(f'{{{W}}}val') == '21'
            text_runs = notes.xpath('.//w:footnote[not(@w:id="-1") and not(@w:id="0")]//w:r[w:t]', namespaces=NS)
            for tr in text_runs:
                sz = tr.find('w:rPr/w:sz', namespaces=NS)
                assert sz is not None and sz.get(f'{{{W}}}val') == '18'
            links = notes.xpath('.//w:hyperlink',namespaces=NS)
            assert len(links) == 2
            for link in links:
                for note_run in link.xpath('.//w:r[w:t]', namespaces=NS):
                    color = note_run.find('w:rPr/w:color', namespaces=NS)
                    underline = note_run.find('w:rPr/w:u', namespaces=NS)
                    assert color is not None and color.get(f'{{{W}}}val') == '000000'
                    assert underline is not None and underline.get(f'{{{W}}}val') == 'none'
        rtext=report.read_text(encoding='utf-8')
        assert '修改状态：**已全部完成**' in rtext
        assert 'AI生成内容：**无**' in rtext
        assert '后续手动处理：**' in rtext
    print('[OK] citation regression test passed')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
