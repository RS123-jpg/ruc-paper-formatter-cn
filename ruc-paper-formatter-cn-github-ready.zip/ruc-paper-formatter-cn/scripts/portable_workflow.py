#!/usr/bin/env python3
"""Portable two-stage workflow for AI hosts that cannot execute this skill directly.

Commands:
  prepare INPUT.docx --job-dir DIR
  apply INPUT.docx --job-dir DIR --output OUTPUT.docx [--report REPORT.md]
  verify OUTPUT.docx [--out verify.json]
  render OUTPUT.docx --output-dir DIR [--engine auto]

The prepare step extracts a document map and a plan scaffold that can be sent to
Gemini, WorkBuddy, Claude, or any other model. The model edits plan.json. The
apply step writes and validates the final DOCX locally.
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent


def run_script(script: str, *args: str) -> None:
    cmd = [sys.executable, str(HERE / script), *args]
    proc = subprocess.run(cmd, text=True, capture_output=True)
    if proc.returncode:
        message = (proc.stdout + "\n" + proc.stderr).strip()
        raise SystemExit(message or f"Command failed: {' '.join(cmd)}")
    if proc.stdout.strip():
        print(proc.stdout.strip())


def write_document_text(inventory: dict[str, Any], out: Path) -> None:
    lines: list[str] = [
        "# 论文结构化文本",
        "",
        "此文件由本地准备工具生成，供 AI 复核段落角色和排版计划。段落编号必须与 inventory.json 保持一致。",
        "",
        "## 段落",
        "",
    ]
    for item in inventory.get("paragraphs", []):
        text = (item.get("text") or "").replace("\n", "\\n")
        lines.append(
            f"- `[P{item.get('index')}]` `role={item.get('suggested_role')}` "
            f"`style={item.get('style') or '-'}`: {text}"
        )
    lines.extend(["", "## 表格", ""])
    tables = inventory.get("tables", [])
    if not tables:
        lines.append("- 无")
    for table in tables:
        lines.append(
            f"### 表格 {table.get('index')}｜{table.get('rows')} 行 × {table.get('columns')} 列｜"
            f"建议模式：`{table.get('suggested_mode')}`"
        )
        if table.get("frontmatter_layout"):
            lines.append("- 检测为前置区布局表，必须保留并按前置区规则处理。")
        for row in table.get("preview", []):
            lines.append("- " + " | ".join(str(x).replace("\n", " ") for x in row))
        lines.append("")
    lines.extend(["## 脚注", ""])
    footnotes = inventory.get("footnotes", [])
    if not footnotes:
        lines.append("- 无")
    for note in footnotes:
        lines.append(f"- `[FN{note.get('id')}]` {note.get('text', '')}")
    lines.extend(["", "## 手工角标候选", ""])
    candidates = inventory.get("manual_citation_candidates", [])
    if not candidates:
        lines.append("- 无")
    for item in candidates:
        lines.append(
            f"- 段落 P{item.get('paragraph')}，标记 `{item.get('marker_text')}`，"
            f"置信度 `{item.get('confidence')}`，上下文：{item.get('context', '')}"
        )
        if item.get("suggested_reference_text"):
            lines.append(f"  - 建议出处：{item.get('suggested_reference_text')}")
    lines.extend(["", "## 现有章节检测", "", "```json"])
    lines.append(json.dumps(inventory.get("section_presence", {}), ensure_ascii=False, indent=2))
    lines.append("```")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_ai_task(job_dir: Path, out: Path) -> None:
    text = f"""# AI 任务说明

你需要依据本 Skill 的规范复核 `{job_dir.name}/plan.json`，并返回完整、可解析的 JSON 文件。

请同时读取：

- `document_text.md`
- `inventory.json`
- `plan.json`
- Skill 根目录 `references/format-standard.md`
- `references/content-completion.md`
- `references/cross-reference-logic.md`
- `references/plan-schema.md`

要求：

1. 不改写已有正文，只复核段落角色、表格模式、手工角标、脚注、参考文献和本次格式覆盖项；
2. 只有摘要或关键词完全缺失时才增加 `insertions`；
3. 本次用户要求优先于模板，模板优先于默认规范；
4. 无法确定时保留 `no_change`，不要猜测；
5. 返回完整 `plan.json`，不要只给建议或代码片段；
6. 不要声称已经生成最终 DOCX。本地用户还需要运行 `portable_workflow.py apply`。
"""
    out.write_text(text, encoding="utf-8")


def prepare(args: argparse.Namespace) -> None:
    input_docx = args.input.resolve()
    if input_docx.suffix.lower() != ".docx":
        raise SystemExit("Only .docx input is supported.")
    if not input_docx.exists():
        raise SystemExit(f"Input not found: {input_docx}")
    job_dir = args.job_dir.resolve()
    job_dir.mkdir(parents=True, exist_ok=True)
    inventory_path = job_dir / "inventory.json"
    run_script("inspect_docx.py", str(input_docx), "--out", str(inventory_path))
    inventory = json.loads(inventory_path.read_text(encoding="utf-8"))
    plan_path = job_dir / "plan.json"
    plan_path.write_text(
        json.dumps(inventory.get("plan_scaffold", {}), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    write_document_text(inventory, job_dir / "document_text.md")
    write_ai_task(job_dir, job_dir / "AI_TASK.md")
    metadata = {
        "input_docx": str(input_docx),
        "skill_root": str(ROOT.resolve()),
        "files_for_ai": ["AI_TASK.md", "document_text.md", "inventory.json", "plan.json"],
        "next_step": "Ask the AI to revise plan.json, then run portable_workflow.py apply.",
    }
    (job_dir / "job.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] Portable AI job created: {job_dir}")


def apply(args: argparse.Namespace) -> None:
    input_docx = args.input.resolve()
    job_dir = args.job_dir.resolve()
    plan = job_dir / "plan.json"
    if not input_docx.exists():
        raise SystemExit(f"Input not found: {input_docx}")
    if not plan.exists():
        raise SystemExit(f"Missing plan: {plan}")
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    report = args.report.resolve() if args.report else output.with_name(output.stem + "_format_report.md")
    run_script(
        "format_academic_docx.py",
        str(input_docx),
        str(output),
        "--plan",
        str(plan),
        "--report",
        str(report),
    )
    verify_path = job_dir / "verify.json"
    run_script("verify_formatted_docx.py", str(output), "--out", str(verify_path))
    if args.render:
        render_dir = job_dir / "rendered"
        render_args = [str(output), "--output_dir", str(render_dir), "--emit_pdf", "--engine", args.engine]
        run_script("render_docx_local.py", *render_args)
        run_script("qa_rendered_pages.py", str(render_dir), "--out", str(job_dir / "render_qa.json"))
    print(f"[OK] Formatted DOCX: {output}")
    print(f"[OK] Report: {report}")


def verify(args: argparse.Namespace) -> None:
    command = [str(args.input.resolve())]
    if args.out:
        command.extend(["--out", str(args.out.resolve())])
    run_script("verify_formatted_docx.py", *command)


def render(args: argparse.Namespace) -> None:
    run_script(
        "render_docx_local.py",
        str(args.input.resolve()),
        "--output_dir",
        str(args.output_dir.resolve()),
        "--emit_pdf",
        "--engine",
        args.engine,
    )
    run_script(
        "qa_rendered_pages.py",
        str(args.output_dir.resolve()),
        "--out",
        str(args.output_dir.resolve() / "render_qa.json"),
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Portable workflow for the Chinese academic paper formatter.")
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("prepare", help="Extract an AI-readable job package from a DOCX.")
    p.add_argument("input", type=Path)
    p.add_argument("--job-dir", type=Path, required=True)
    p.set_defaults(func=prepare)

    p = sub.add_parser("apply", help="Apply an AI-reviewed plan and validate the DOCX.")
    p.add_argument("input", type=Path)
    p.add_argument("--job-dir", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--report", type=Path)
    p.add_argument("--render", action="store_true")
    p.add_argument("--engine", default="auto", choices=["auto", "wps", "word", "libreoffice"])
    p.set_defaults(func=apply)

    p = sub.add_parser("verify", help="Validate an already formatted DOCX.")
    p.add_argument("input", type=Path)
    p.add_argument("--out", type=Path)
    p.set_defaults(func=verify)

    p = sub.add_parser("render", help="Render a DOCX and run page-level checks.")
    p.add_argument("input", type=Path)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--engine", default="auto", choices=["auto", "wps", "word", "libreoffice"])
    p.set_defaults(func=render)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    args.func(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
