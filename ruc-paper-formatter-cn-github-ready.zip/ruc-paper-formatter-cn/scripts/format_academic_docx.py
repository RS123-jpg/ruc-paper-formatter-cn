#!/usr/bin/env python3
"""Format a Chinese academic-paper DOCX while preserving existing prose.

The script applies the bundled course-paper/competition-paper format standard,
normalizes heading number prefixes, formats existing true footnotes, converts
identical repeated footnotes to NOTEREF cross-references, converts simple
Figure/Table caption numbers and in-text references to SEQ/REF fields, can
insert model-generated Chinese abstract/keywords supplied through the plan when
those sections are absent, and performs a final XML-level font and Chinese-quote
audit before packaging the output.

Ambiguous semantic problems are reported rather than guessed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import tempfile
import zipfile
from collections import Counter, defaultdict
from copy import deepcopy
from pathlib import Path
from typing import Any, Iterable

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_LINE_SPACING
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt
from docx.text.paragraph import Paragraph
from lxml import etree

W_NS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
R_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
XML_NS = "http://www.w3.org/XML/1998/namespace"
NS = {"w": W_NS, "r": R_NS}
PKGREL_NS = "http://schemas.openxmlformats.org/package/2006/relationships"
CT_NS = "http://schemas.openxmlformats.org/package/2006/content-types"
CIRCLED = "①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳"
STRAIGHT_DOUBLE_QUOTES = {'"', "＂"}

CN_DIGITS = "零一二三四五六七八九十百"
ROLE_NAMES = {
    "title", "subtitle", "author", "author_info", "abstract", "keywords",
    "heading1", "heading2", "heading3", "heading4", "body",
    "figure_caption", "table_caption", "figure_or_table_note",
    "references_heading", "reference_item", "appendix_heading",
    "english_title", "english_abstract", "english_keywords", "blank", "no_change",
}


def wq(local: str) -> str:
    return f"{{{W_NS}}}{local}"


def set_east_asia_font(run_or_style, east_asia: str, latin: str, size_pt: float) -> None:
    run_or_style.font.name = latin
    run_or_style.font.size = Pt(size_pt)
    rpr = run_or_style._element.get_or_add_rPr() if hasattr(run_or_style, "_element") else None
    if rpr is None:
        return
    rfonts = rpr.rFonts
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    rfonts.set(qn("w:eastAsia"), east_asia)
    rfonts.set(qn("w:ascii"), latin)
    rfonts.set(qn("w:hAnsi"), latin)
    rfonts.set(qn("w:cs"), latin)


def set_run_font(run, east_asia: str, latin: str, size_pt: float, bold: bool | None = None, italic: bool | None = None) -> None:
    run.font.name = latin
    run.font.size = Pt(size_pt)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    rpr = run._r.get_or_add_rPr()
    rfonts = rpr.rFonts
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts")
        rpr.insert(0, rfonts)
    for attr, val in (("eastAsia", east_asia), ("ascii", latin), ("hAnsi", latin), ("cs", latin)):
        rfonts.set(qn(f"w:{attr}"), val)
    lang = rpr.find(qn("w:lang"))
    if lang is None:
        lang = OxmlElement("w:lang")
        rpr.append(lang)
    lang.set(qn("w:val"), "en-US")
    lang.set(qn("w:eastAsia"), "zh-CN")
    # Clear legacy character scaling/position/spacing that often renders
    # differently in browser previews, LibreOffice, Word, and WPS.
    for tag in ("spacing", "position", "w", "kern"):
        el = rpr.find(qn(f"w:{tag}"))
        if el is not None:
            rpr.remove(el)


def set_paragraph_spacing(paragraph, *, before=0, after=0, line=20, first_line_pt: float | None = None, hanging_pt: float | None = None) -> None:
    fmt = paragraph.paragraph_format
    fmt.space_before = Pt(before)
    fmt.space_after = Pt(after)
    if line is not None:
        fmt.line_spacing_rule = WD_LINE_SPACING.EXACTLY
        fmt.line_spacing = Pt(line)
    if first_line_pt is not None:
        fmt.first_line_indent = Pt(first_line_pt)
    else:
        fmt.first_line_indent = None
    if hanging_pt is not None:
        fmt.left_indent = Pt(hanging_pt)
        fmt.first_line_indent = Pt(-hanging_pt)


def apply_runs(paragraph, east_asia: str, latin: str, size: float, bold: bool | None = None, italic: bool | None = None) -> None:
    for run in paragraph.runs:
        # Keep explicit superscript/subscript and meaningful emphasis unless an override explicitly changes it.
        set_run_font(run, east_asia, latin, size, bold=bold, italic=italic)


ALIGNMENT_MAP = {
    "left": WD_ALIGN_PARAGRAPH.LEFT,
    "center": WD_ALIGN_PARAGRAPH.CENTER,
    "right": WD_ALIGN_PARAGRAPH.RIGHT,
    "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
}


def _default_role_font(role: str) -> tuple[str, str, float]:
    spec = ROLE_XML_FONT.get(role, ("宋体", "Times New Roman", "21"))
    return spec[0], spec[1], float(spec[2]) / 2


def apply_style_override(paragraph, role: str, cfg: dict[str, Any] | None) -> None:
    """Apply only explicitly supplied per-role overrides after the default style.

    This implements partial override semantics: unspecified attributes keep the
    template/default result.  It intentionally preserves existing emphasis
    unless ``bold`` or ``italic`` is explicitly supplied.
    """
    if not isinstance(cfg, dict) or not cfg:
        return
    east_default, latin_default, size_default = _default_role_font(role)
    east = str(cfg.get("east_asia_font", east_default))
    latin = str(cfg.get("latin_font", latin_default))
    try:
        size = float(cfg.get("font_size_pt", size_default))
    except (TypeError, ValueError):
        size = size_default
    bold_raw = cfg.get("bold", None)
    bold = bold_raw if isinstance(bold_raw, bool) else None
    italic_raw = cfg.get("italic", None)
    italic = italic_raw if isinstance(italic_raw, bool) else None
    if any(k in cfg for k in ("east_asia_font", "latin_font", "font_size_pt", "bold", "italic")):
        apply_runs(paragraph, east, latin, size, bold=bold, italic=italic)

    alignment = str(cfg.get("alignment", "")).lower()
    if alignment in ALIGNMENT_MAP:
        paragraph.alignment = ALIGNMENT_MAP[alignment]

    fmt = paragraph.paragraph_format
    for key, attr in (("space_before_pt", "space_before"), ("space_after_pt", "space_after")):
        if key in cfg:
            try:
                setattr(fmt, attr, Pt(float(cfg[key])))
            except (TypeError, ValueError):
                pass
    if "line_spacing_pt" in cfg:
        try:
            fmt.line_spacing_rule = WD_LINE_SPACING.EXACTLY
            fmt.line_spacing = Pt(float(cfg["line_spacing_pt"]))
        except (TypeError, ValueError):
            pass
    if "first_line_indent_pt" in cfg:
        try:
            fmt.first_line_indent = Pt(float(cfg["first_line_indent_pt"]))
        except (TypeError, ValueError):
            pass
    elif "first_line_indent_chars" in cfg:
        try:
            fmt.first_line_indent = Pt(float(cfg["first_line_indent_chars"]) * size)
        except (TypeError, ValueError):
            pass
    if "hanging_indent_pt" in cfg:
        try:
            amount = float(cfg["hanging_indent_pt"])
            fmt.left_indent = Pt(amount)
            fmt.first_line_indent = Pt(-amount)
        except (TypeError, ValueError):
            pass
    elif "hanging_indent_chars" in cfg:
        try:
            amount = float(cfg["hanging_indent_chars"]) * size
            fmt.left_indent = Pt(amount)
            fmt.first_line_indent = Pt(-amount)
        except (TypeError, ValueError):
            pass
    if isinstance(cfg.get("keep_with_next"), bool):
        fmt.keep_with_next = cfg["keep_with_next"]
    if isinstance(cfg.get("keep_together"), bool):
        fmt.keep_together = cfg["keep_together"]


def clear_heading_list_numbering(paragraph) -> None:
    """Remove automatic list numbering from explicitly numbered headings.

    The formatter writes visible prefixes such as ``一、``.  If the source
    paragraph still carries ``w:numPr`` (or a numbered paragraph style), WPS
    renders both the automatic number and the visible prefix, producing
    ``一、一、引言``.  Force headings onto direct formatting only.
    """
    ppr = paragraph._p.get_or_add_pPr()
    for tag in (qn("w:numPr"), qn("w:pStyle")):
        node = ppr.find(tag)
        if node is not None:
            ppr.remove(node)


def apply_role(paragraph, role: str, style_overrides: dict[str, Any] | None = None) -> None:
    if role in {"blank", "no_change"}:
        return
    if role in {"heading1", "heading2", "heading3", "heading4"}:
        clear_heading_list_numbering(paragraph)
    if role == "title":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_paragraph_spacing(paragraph, after=12, line=28)
        apply_runs(paragraph, "黑体", "Times New Roman", 22, bold=False)
    elif role == "subtitle":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_paragraph_spacing(paragraph, after=12, line=22)
        apply_runs(paragraph, "宋体", "Times New Roman", 14, bold=None)
    elif role == "author":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_paragraph_spacing(paragraph, after=6, line=20)
        apply_runs(paragraph, "宋体", "Times New Roman", 14, bold=None)
    elif role == "author_info":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_paragraph_spacing(paragraph, after=12, line=20)
        apply_runs(paragraph, "宋体", "Times New Roman", 10.5, bold=None)
    elif role in {"abstract", "keywords"}:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        set_paragraph_spacing(paragraph, line=20)
        apply_runs(paragraph, "仿宋", "Times New Roman", 10.5, bold=None)
    elif role == "heading1":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_paragraph_spacing(paragraph, before=6, after=6, line=20)
        apply_runs(paragraph, "黑体", "Times New Roman", 12, bold=False)
        paragraph.paragraph_format.keep_with_next = True
    elif role == "heading2":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
        set_paragraph_spacing(paragraph, before=6, after=3, line=20)
        apply_runs(paragraph, "黑体", "Times New Roman", 10.5, bold=False)
        paragraph.paragraph_format.keep_with_next = True
    elif role == "heading3":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
        set_paragraph_spacing(paragraph, before=3, after=0, line=20)
        apply_runs(paragraph, "宋体", "Times New Roman", 10.5, bold=None)
        paragraph.paragraph_format.keep_with_next = True
    elif role == "heading4":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        set_paragraph_spacing(paragraph, line=20, first_line_pt=21)
        apply_runs(paragraph, "宋体", "Times New Roman", 10.5, bold=None)
    elif role == "body":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        set_paragraph_spacing(paragraph, line=20, first_line_pt=21)
        apply_runs(paragraph, "宋体", "Times New Roman", 10.5, bold=None)
    elif role in {"figure_caption", "table_caption"}:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_paragraph_spacing(paragraph, before=3, after=3, line=16)
        apply_runs(paragraph, "黑体", "Times New Roman", 9, bold=False)
        paragraph.paragraph_format.keep_with_next = role == "table_caption"
        paragraph.paragraph_format.keep_together = True
    elif role == "figure_or_table_note":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT
        set_paragraph_spacing(paragraph, line=12, first_line_pt=15)
        apply_runs(paragraph, "宋体", "Times New Roman", 7.5, bold=None)
    elif role in {"references_heading", "appendix_heading"}:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_paragraph_spacing(paragraph, before=12, after=6, line=20)
        apply_runs(paragraph, "黑体", "Times New Roman", 12, bold=False)
        paragraph.paragraph_format.keep_with_next = True
        if role == "references_heading":
            # Start the bibliography on a new page. page_break_before is more
            # stable in Word/WPS than inserting a literal break run.
            paragraph.paragraph_format.page_break_before = True
    elif role == "reference_item":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        set_paragraph_spacing(paragraph, line=16, hanging_pt=21)
        apply_runs(paragraph, "宋体", "Times New Roman", 10.5, bold=None)
    elif role == "english_title":
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_paragraph_spacing(paragraph, before=6, after=6, line=20)
        apply_runs(paragraph, "Times New Roman", "Times New Roman", 12, bold=True)
    elif role in {"english_abstract", "english_keywords"}:
        paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        set_paragraph_spacing(paragraph, line=20)
        apply_runs(paragraph, "Times New Roman", "Times New Roman", 10.5, bold=None)

    cfg = style_overrides.get(role, {}) if isinstance(style_overrides, dict) else {}
    apply_style_override(paragraph, role, cfg)
    if role in {"abstract", "keywords"}:
        try:
            label_size = float(cfg.get("label_font_size_pt", cfg.get("font_size_pt", 10.5))) if isinstance(cfg, dict) else 10.5
        except (TypeError, ValueError):
            label_size = 10.5
        style_inline_label(
            paragraph,
            "摘要" if role == "abstract" else "关键词",
            east_asia=str(cfg.get("label_east_asia_font", "黑体")) if isinstance(cfg, dict) else "黑体",
            latin=str(cfg.get("label_latin_font", "Times New Roman")) if isinstance(cfg, dict) else "Times New Roman",
            size_pt=label_size,
            bold=cfg.get("label_bold", False) if isinstance(cfg, dict) and isinstance(cfg.get("label_bold", False), bool) else False,
        )

def style_inline_label(paragraph, label: str, *, east_asia: str = "黑体", latin: str = "Times New Roman", size_pt: float = 10.5, bold: bool = False) -> None:
    """Format only the inline section label, preserving body text formatting.

    The visible form must already be ``［摘要］正文`` or ``［关键词］正文``.
    The label and body stay in the same paragraph with no intervening line break
    or space.  The label is blackface; the body remains FangSong.
    """
    full = "".join(run.text for run in paragraph.runs)
    pattern = re.compile(rf"^［{re.escape(label)}］")
    m = pattern.match(full)
    if not m:
        return
    remaining = m.end()
    for run in list(paragraph.runs):
        if remaining <= 0:
            break
        text = run.text or ""
        if not text:
            continue
        if len(text) <= remaining:
            set_run_font(run, east_asia, latin, size_pt, bold=bold)
            remaining -= len(text)
            continue
        # Copy the already-normalized FangSong run before styling the label
        # segment, otherwise the body segment would incorrectly inherit blackface.
        original_r = deepcopy(run._r)
        prefix, rest = text[:remaining], text[remaining:]
        run.text = prefix
        set_run_font(run, east_asia, latin, size_pt, bold=bold)
        for t in original_r.xpath(".//w:t"):
            t.text = rest
        run._r.addnext(original_r)
        remaining = 0



def _max_python_docx_bookmark_id(doc: Document) -> int:
    values = []
    for node in doc._element.xpath(".//w:bookmarkStart|.//w:bookmarkEnd"):
        value = node.get(qn("w:id"))
        if value and value.isdigit():
            values.append(int(value))
    return max(values, default=0)


def _add_hidden_paragraph_bookmark(paragraph, name: str, bookmark_id: int) -> None:
    if paragraph._p.xpath(f"./w:bookmarkStart[@w:name='{name}']"):
        return
    start = OxmlElement("w:bookmarkStart")
    start.set(qn("w:id"), str(bookmark_id))
    start.set(qn("w:name"), name[:40])
    end = OxmlElement("w:bookmarkEnd")
    end.set(qn("w:id"), str(bookmark_id))
    ppr = paragraph._p.pPr
    insert_at = 1 if ppr is not None and len(paragraph._p) and paragraph._p[0] is ppr else 0
    paragraph._p.insert(insert_at, start)
    paragraph._p.append(end)


def _remove_hidden_bookmarks(paragraph, prefix: str) -> None:
    starts = list(paragraph._p.xpath(f"./w:bookmarkStart[starts-with(@w:name, '{prefix}') ]"))
    for start in starts:
        bid = start.get(qn("w:id"))
        parent = start.getparent()
        if parent is not None:
            parent.remove(start)
        if bid is not None:
            for end in list(paragraph._p.xpath(f"./w:bookmarkEnd[@w:id='{bid}']")):
                eparent = end.getparent()
                if eparent is not None:
                    eparent.remove(end)


def tag_original_paragraphs(doc: Document) -> None:
    for paragraph in doc.paragraphs:
        _remove_hidden_bookmarks(paragraph, "_PaperOrig_")
    next_id = _max_python_docx_bookmark_id(doc) + 1
    for idx, paragraph in enumerate(doc.paragraphs):
        _add_hidden_paragraph_bookmark(paragraph, f"_PaperOrig_{idx}", next_id)
        next_id += 1


def tag_paragraph_roles(doc: Document, roles: dict[int, str]) -> None:
    for paragraph in doc.paragraphs:
        _remove_hidden_bookmarks(paragraph, "_PaperRole_")
    next_id = _max_python_docx_bookmark_id(doc) + 1
    for idx, paragraph in enumerate(doc.paragraphs):
        role = roles.get(idx, "body")
        safe_role = re.sub(r"[^A-Za-z0-9_]", "_", role)
        _add_hidden_paragraph_bookmark(paragraph, f"_PaperRole_{safe_role}_{idx}", next_id)
        next_id += 1


def role_from_bookmarks(p: etree._Element, fallback: str = "body") -> str:
    for bm in p.xpath("./w:bookmarkStart", namespaces=NS):
        name = bm.get(wq("name")) or ""
        m = re.match(r"_PaperRole_([A-Za-z0-9_]+)_\d+$", name)
        if m and m.group(1) in ROLE_NAMES:
            return m.group(1)
    return fallback


def original_index_from_bookmark(p: etree._Element) -> int | None:
    for bm in p.xpath("./w:bookmarkStart", namespaces=NS):
        name = bm.get(wq("name")) or ""
        m = re.match(r"_PaperOrig_(\d+)$", name)
        if m:
            return int(m.group(1))
    return None

def chinese_number(n: int) -> str:
    if n <= 0:
        return str(n)
    if n < 10:
        return CN_DIGITS[n]
    if n == 10:
        return "十"
    if n < 20:
        return "十" + CN_DIGITS[n - 10]
    if n < 100:
        tens, ones = divmod(n, 10)
        return CN_DIGITS[tens] + "十" + (CN_DIGITS[ones] if ones else "")
    return str(n)


PREFIX_RE = re.compile(
    r"^\s*(?:"
    r"第[一二三四五六七八九十百0-9]+[章节篇]|"
    r"[一二三四五六七八九十百]+[、\.．]|"
    r"（[一二三四五六七八九十百]+）|"
    r"\([一二三四五六七八九十百]+\)|"
    r"（\d+）|\(\d+\)|"
    r"\d+(?:[\.．]\d+){0,4}[、\.．]?"
    r")\s*"
)


def replace_leading_text(paragraph, new_prefix: str) -> bool:
    """Replace every existing heading prefix with one canonical prefix.

    WPS/Word list numbering may previously have been materialized into visible
    text, so a paragraph can arrive as ``一、一、引言`` or ``1. 1. 背景``.
    Strip all consecutive heading-like prefixes before inserting the canonical
    one.  This makes repeated Skill runs idempotent.
    """
    texts = paragraph._p.xpath(".//w:t")
    if not texts:
        return False
    full = "".join(t.text or "" for t in texts)
    cut = 0
    rest = full
    for _ in range(8):
        m = PREFIX_RE.match(rest)
        if not m or m.end() <= 0:
            break
        cut += m.end()
        rest = rest[m.end():]
    remaining_to_cut = cut
    for t in texts:
        txt = t.text or ""
        if remaining_to_cut >= len(txt):
            t.text = ""
            remaining_to_cut -= len(txt)
        else:
            t.text = txt[remaining_to_cut:]
            remaining_to_cut = 0
            break
    first = texts[0]
    first.text = new_prefix + (first.text or "")
    if first.text.startswith(" ") or first.text.endswith(" "):
        first.set(f"{{{XML_NS}}}space", "preserve")
    return True


def normalize_headings(doc: Document, roles: dict[int, str]) -> int:
    counters = {"heading1": 0, "heading2": 0, "heading3": 0, "heading4": 0}
    changed = 0
    for idx, p in enumerate(doc.paragraphs):
        role = roles.get(idx)
        if role == "heading1":
            counters["heading1"] += 1
            counters["heading2"] = counters["heading3"] = counters["heading4"] = 0
            changed += replace_leading_text(p, f"{chinese_number(counters['heading1'])}、")
        elif role == "heading2":
            counters["heading2"] += 1
            counters["heading3"] = counters["heading4"] = 0
            changed += replace_leading_text(p, f"（{chinese_number(counters['heading2'])}）")
        elif role == "heading3":
            counters["heading3"] += 1
            counters["heading4"] = 0
            changed += replace_leading_text(p, f"{counters['heading3']}. ")
        elif role == "heading4":
            counters["heading4"] += 1
            changed += replace_leading_text(p, f"（{counters['heading4']}）")
    return changed


def set_cell_margins(cell, top=60, start=80, bottom=60, end=80) -> None:
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcMar = tcPr.first_child_found_in("w:tcMar")
    if tcMar is None:
        tcMar = OxmlElement("w:tcMar")
        tcPr.append(tcMar)
    for m, v in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tcMar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tcMar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")


def set_table_borders(table, three_line: bool) -> None:
    tblPr = table._tbl.tblPr
    borders = tblPr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tblPr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = borders.find(qn(f"w:{edge}"))
        if el is None:
            el = OxmlElement(f"w:{edge}")
            borders.append(el)
        if three_line:
            if edge in {"top", "bottom"}:
                el.set(qn("w:val"), "single")
                el.set(qn("w:sz"), "12")
                el.set(qn("w:color"), "000000")
            else:
                el.set(qn("w:val"), "nil")
        else:
            el.set(qn("w:val"), "single")
            el.set(qn("w:sz"), "4")
            el.set(qn("w:color"), "000000")
    if three_line and table.rows:
        for cell in table.rows[0].cells:
            tcPr = cell._tc.get_or_add_tcPr()
            tcBorders = tcPr.first_child_found_in("w:tcBorders")
            if tcBorders is None:
                tcBorders = OxmlElement("w:tcBorders")
                tcPr.append(tcBorders)
            bottom = tcBorders.find(qn("w:bottom"))
            if bottom is None:
                bottom = OxmlElement("w:bottom")
                tcBorders.append(bottom)
            bottom.set(qn("w:val"), "single")
            bottom.set(qn("w:sz"), "8")
            bottom.set(qn("w:color"), "000000")


def table_is_complex(table) -> bool:
    tbl = table._tbl
    if tbl.xpath(".//w:gridSpan[@w:val != '1']|.//w:vMerge|.//w:tbl|.//w:drawing|.//w:object"):
        return True
    if table.rows and max((len(row.cells) for row in table.rows), default=0) > 10:
        return True
    return False


def _table_config_for(index: int, table, table_configs: dict[str, Any], default_three_line: bool) -> dict[str, Any]:
    raw = table_configs.get(str(index), table_configs.get(index, {})) if isinstance(table_configs, dict) else {}
    cfg = dict(raw) if isinstance(raw, dict) else {}
    mode = str(cfg.get("mode", "auto"))
    if _frontmatter_table_candidate(table):
        mode = "preserve"
        cfg["frontmatter_layout"] = True
    if mode == "auto":
        mode = "preserve" if table_is_complex(table) else ("three_line" if default_three_line else "standard")
    if mode not in {"three_line", "standard", "preserve"}:
        mode = "preserve"
    cfg["mode"] = mode
    cfg.setdefault("header_rows", 1 if mode != "preserve" else 0)
    cfg.setdefault("format_text", mode != "preserve")
    cfg.setdefault("font_size", 9)
    cfg.setdefault("body_alignment", "preserve")
    return cfg


def _paragraph_max_font_pt(paragraph: Paragraph) -> float:
    sizes = [float(run.font.size.pt) for run in paragraph.runs if run.font.size is not None]
    return max(sizes, default=0.0)


def _frontmatter_table_candidate(table) -> bool:
    """Return True for a small early layout table that contains a title block."""
    if len(table.rows) > 8 or len(table.columns) > 2:
        return False
    # Do not treat a table occurring after an abstract or numbered heading as
    # front matter.  This avoids touching ordinary data tables later in a paper.
    body_child = table._tbl
    preceding_nonblank = 0
    for sibling in body_child.itersiblings(preceding=True):
        if sibling.tag not in {qn("w:p"), qn("w:tbl"), qn("w:sdt")}:
            continue
        visible = "".join(sibling.xpath(".//w:t/text()"))
        if not visible.strip():
            continue
        preceding_nonblank += 1
        if re.match(r"^\s*(?:［?摘要］?|［?关键词］?|[一二三四五六七八九十百]+、)", visible.strip()):
            return False
        if preceding_nonblank > 8:
            return False
    candidates = []
    for row in table.rows:
        for cell in row.cells:
            for paragraph in cell.paragraphs:
                value = paragraph.text.strip()
                if not value or not contains_cjk(value) or len(value) > 120:
                    continue
                size = _paragraph_max_font_pt(paragraph)
                centered = paragraph.alignment == WD_ALIGN_PARAGRAPH.CENTER
                if size >= 16 or centered:
                    candidates.append((size, value))
    return bool(candidates and max(x[0] for x in candidates) >= 16)


def _remove_all_table_borders(table) -> None:
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        el = borders.find(qn(f"w:{edge}"))
        if el is None:
            el = OxmlElement(f"w:{edge}")
            borders.append(el)
        el.set(qn("w:val"), "nil")


def stabilize_frontmatter_layout_tables(doc: Document) -> tuple[int, list[tuple[Paragraph, str]]]:
    """Stabilize title blocks stored in legacy one-cell/two-cell layout tables.

    Old DOC/DOCX files and WPS templates often keep the title in a narrow layout
    table.  The browser preview may expand that table while desktop WPS honors
    its stale width, causing the title to jump into multiple lines.  This pass
    widens such tables to the printable width, removes table borders, and tags
    the contained title/author paragraphs for the same direct formatting used
    by ordinary body paragraphs.
    """
    if not doc.sections:
        usable_twips = Cm(15.7).twips
    else:
        sec = doc.sections[0]
        try:
            usable_twips = int((sec.page_width - sec.left_margin - sec.right_margin) / 635)
        except Exception:
            usable_twips = Cm(15.7).twips
    changed = 0
    nested_roles: list[tuple[Paragraph, str]] = []
    for table in doc.tables[:3]:
        if not _frontmatter_table_candidate(table):
            continue
        changed += 1
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        table.autofit = False
        tbl_pr = table._tbl.tblPr
        tbl_w = tbl_pr.first_child_found_in("w:tblW")
        if tbl_w is None:
            tbl_w = OxmlElement("w:tblW")
            tbl_pr.append(tbl_w)
        tbl_w.set(qn("w:w"), str(max(1, usable_twips)))
        tbl_w.set(qn("w:type"), "dxa")
        tbl_ind = tbl_pr.first_child_found_in("w:tblInd")
        if tbl_ind is None:
            tbl_ind = OxmlElement("w:tblInd")
            tbl_pr.append(tbl_ind)
        tbl_ind.set(qn("w:w"), "0")
        tbl_ind.set(qn("w:type"), "dxa")
        _remove_all_table_borders(table)
        if len(table.columns) == 1:
            grid_col = table._tbl.find("w:tblGrid/w:gridCol", namespaces={"w": W_NS})
            if grid_col is not None:
                grid_col.set(qn("w:w"), str(max(1, usable_twips)))
        paras: list[Paragraph] = []
        for row in table.rows:
            for cell in row.cells:
                tc_pr = cell._tc.get_or_add_tcPr()
                tc_w = tc_pr.first_child_found_in("w:tcW")
                if tc_w is None:
                    tc_w = OxmlElement("w:tcW")
                    tc_pr.append(tc_w)
                if len(table.columns) == 1:
                    tc_w.set(qn("w:w"), str(max(1, usable_twips)))
                    tc_w.set(qn("w:type"), "dxa")
                set_cell_margins(cell, top=0, start=0, bottom=0, end=0)
                paras.extend([p for p in cell.paragraphs if p.text.strip()])
        if not paras:
            continue
        title = max(paras, key=lambda p: (_paragraph_max_font_pt(p), len(p.text.strip())))
        normalize_centered_frontmatter(title, "title")
        apply_role(title, "title")
        nested_roles.append((title, "title"))
        for p in paras:
            if p is title:
                continue
            value = p.text.strip()
            size = _paragraph_max_font_pt(p)
            role = None
            if re.search(r"(?:学号|作者|姓名|课程|班级|专业)[:：]", value) or re.match(r"^\d{6,}\s*[\u4e00-\u9fff·]{2,8}$", value):
                role = "author_info"
            elif size >= 13 and len(value) <= 80:
                role = "subtitle"
            elif len(value) <= 50 and p.alignment == WD_ALIGN_PARAGRAPH.CENTER:
                role = "author_info"
            if role:
                normalize_centered_frontmatter(p, role)
                apply_role(p, role)
                nested_roles.append((p, role))
    return changed, nested_roles


def tag_nested_frontmatter_roles(doc: Document, records: list[tuple[Paragraph, str]]) -> None:
    if not records:
        return
    next_id = _max_python_docx_bookmark_id(doc) + 1
    for idx, (paragraph, role) in enumerate(records):
        _remove_hidden_bookmarks(paragraph, "_PaperRole_")
        _add_hidden_paragraph_bookmark(paragraph, f"_PaperRole_{role}_{9000000 + idx}", next_id)
        next_id += 1


def format_tables(doc: Document, table_configs: dict[str, Any], default_three_line: bool) -> dict[str, int]:
    stats = {"total": len(doc.tables), "three_line": 0, "standard": 0, "preserved": 0, "frontmatter_preserved": 0, "text_formatted": 0}
    for t_idx, table in enumerate(doc.tables):
        cfg = _table_config_for(t_idx, table, table_configs, default_three_line)
        mode = cfg["mode"]
        if isinstance(table_configs, dict):
            table_configs[str(t_idx)] = cfg
        if mode == "preserve":
            stats["preserved"] += 1
            if cfg.get("frontmatter_layout"):
                stats["frontmatter_preserved"] += 1
            continue
        stats[mode] += 1
        table.alignment = WD_TABLE_ALIGNMENT.CENTER
        set_table_borders(table, mode == "three_line")
        header_rows = max(0, min(int(cfg.get("header_rows", 1)), len(table.rows)))
        for r_idx in range(header_rows):
            trPr = table.rows[r_idx]._tr.get_or_add_trPr()
            tblHeader = trPr.find(qn("w:tblHeader"))
            if tblHeader is None:
                tblHeader = OxmlElement("w:tblHeader")
                trPr.append(tblHeader)
        if not cfg.get("format_text", True):
            continue
        size = float(cfg.get("font_size", 9))
        body_alignment = str(cfg.get("body_alignment", "preserve"))
        align_map = {"left": WD_ALIGN_PARAGRAPH.LEFT, "center": WD_ALIGN_PARAGRAPH.CENTER, "right": WD_ALIGN_PARAGRAPH.RIGHT}
        for r_idx, row in enumerate(table.rows):
            for cell in row.cells:
                cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                set_cell_margins(cell)
                for p in cell.paragraphs:
                    if r_idx < header_rows:
                        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    elif body_alignment in align_map:
                        p.alignment = align_map[body_alignment]
                    set_paragraph_spacing(p, line=12)
                    apply_runs(p, "宋体", "Times New Roman", size, bold=None)
                    stats["text_formatted"] += 1
    return stats

def configure_page(doc: Document, options: dict[str, Any]) -> dict[str, int]:
    mode = str(options.get("page_setup_mode", "normalize_portrait_except_landscape"))
    overrides = options.get("section_overrides", {}) if isinstance(options.get("section_overrides", {}), dict) else {}
    stats = {"normalized": 0, "landscape_preserved": 0, "overridden": 0}
    for idx, section in enumerate(doc.sections):
        override = overrides.get(str(idx), overrides.get(idx, {}))
        if not isinstance(override, dict):
            override = {}
        is_landscape = bool(section.page_width and section.page_height and section.page_width > section.page_height)
        if mode == "preserve_all" and not override:
            continue
        if is_landscape and mode == "normalize_portrait_except_landscape" and not override:
            stats["landscape_preserved"] += 1
            continue
        width_cm = float(override.get("page_width_cm", 21))
        height_cm = float(override.get("page_height_cm", 29.7))
        section.page_width = Cm(width_cm)
        section.page_height = Cm(height_cm)
        section.top_margin = Cm(float(override.get("top_margin_cm", 2.5)))
        section.bottom_margin = Cm(float(override.get("bottom_margin_cm", 2.5)))
        section.left_margin = Cm(float(override.get("left_margin_cm", 2.8)))
        section.right_margin = Cm(float(override.get("right_margin_cm", 2.5)))
        if "header_distance_cm" in override:
            section.header_distance = Cm(float(override["header_distance_cm"]))
        if "footer_distance_cm" in override:
            section.footer_distance = Cm(float(override["footer_distance_cm"]))
        stats["overridden" if override else "normalized"] += 1
    return stats

ASSET_ROOT = Path(__file__).resolve().parent.parent / "assets"


def _clear_header_content(header) -> None:
    """Remove existing header paragraphs/tables while keeping the header part."""
    root = header._element
    for child in list(root):
        root.remove(child)


def _set_paragraph_bottom_border(paragraph, *, size_eighth_points: int = 6, space_pt: int = 1, color: str = "000000") -> None:
    ppr = paragraph._p.get_or_add_pPr()
    pbdr = ppr.find(qn("w:pBdr"))
    if pbdr is None:
        pbdr = OxmlElement("w:pBdr")
        ppr.append(pbdr)
    bottom = pbdr.find(qn("w:bottom"))
    if bottom is None:
        bottom = OxmlElement("w:bottom")
        pbdr.append(bottom)
    bottom.set(qn("w:val"), "single")
    bottom.set(qn("w:sz"), str(max(2, int(size_eighth_points))))
    bottom.set(qn("w:space"), str(max(0, int(space_pt))))
    bottom.set(qn("w:color"), color)


def _header_has_visible_content(header) -> bool:
    if any((p.text or "").strip() for p in header.paragraphs):
        return True
    return bool(header._element.xpath(".//w:drawing|.//w:pict|.//w:tbl"))


def configure_ruc_header(doc: Document, options: dict[str, Any]) -> dict[str, Any]:
    """Add the bundled Renmin University logo header in a WPS-stable layout.

    The header uses one centered inline image and a paragraph bottom border.
    It deliberately avoids tabs, floating shapes, text boxes, and absolute
    positioning because those are common sources of Word/WPS reflow.
    """
    raw = options.get("ruc_header", {})
    if isinstance(raw, bool):
        cfg = {"enabled": raw}
    elif isinstance(raw, dict):
        cfg = dict(raw)
    else:
        cfg = {}
    if not bool(cfg.get("enabled", False)):
        return {"enabled": False, "headers_written": 0, "headers_skipped": 0}

    asset_name = str(cfg.get("asset", "ruc-header-logo.png"))
    asset = ASSET_ROOT / Path(asset_name).name
    if not asset.exists():
        raise FileNotFoundError(f"RUC header asset not found: {asset}")

    scope = str(cfg.get("scope", "all_pages")).lower()
    replace_existing = bool(cfg.get("replace_existing", True))
    logo_width_cm = float(cfg.get("logo_width_cm", 3.85))
    header_distance_cm = float(cfg.get("header_distance_cm", 1.5))
    line_size = int(cfg.get("line_size_eighth_points", 6))
    line_space = int(cfg.get("line_space_pt", 1))
    line_color = str(cfg.get("line_color", "000000"))

    if scope not in {"all_pages", "except_first_page", "first_page_only"}:
        scope = "all_pages"

    # Avoid odd/even variants unless explicitly present in a user template.
    if scope == "all_pages":
        doc.settings.odd_and_even_pages_header_footer = False

    seen_parts: set[int] = set()
    written = 0
    skipped = 0
    for section in doc.sections:
        section.header_distance = Cm(header_distance_cm)
        if scope == "all_pages":
            section.different_first_page_header_footer = False
            targets = [section.header]
        elif scope == "except_first_page":
            section.different_first_page_header_footer = True
            targets = [section.header]
            if replace_existing:
                _clear_header_content(section.first_page_header)
                section.first_page_header.add_paragraph()
        else:  # first_page_only
            section.different_first_page_header_footer = True
            targets = [section.first_page_header]
            if replace_existing:
                _clear_header_content(section.header)
                section.header.add_paragraph()

        for header in targets:
            key = id(header._element)
            if key in seen_parts:
                continue
            seen_parts.add(key)
            if _header_has_visible_content(header) and not replace_existing:
                skipped += 1
                continue
            _clear_header_content(header)
            p = header.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            fmt = p.paragraph_format
            fmt.left_indent = Cm(0)
            fmt.right_indent = Cm(0)
            fmt.first_line_indent = Cm(0)
            fmt.space_before = Pt(0)
            fmt.space_after = Pt(0)
            fmt.line_spacing_rule = WD_LINE_SPACING.SINGLE
            fmt.line_spacing = 1
            ppr = p._p.get_or_add_pPr()
            tabs = ppr.find(qn("w:tabs"))
            if tabs is not None:
                ppr.remove(tabs)
            snap = ppr.find(qn("w:snapToGrid"))
            if snap is None:
                snap = OxmlElement("w:snapToGrid")
                ppr.append(snap)
            snap.set(qn("w:val"), "0")
            _set_paragraph_bottom_border(
                p, size_eighth_points=line_size, space_pt=line_space, color=line_color
            )
            run = p.add_run()
            run.add_picture(str(asset), width=Cm(logo_width_cm))
            written += 1
    return {
        "enabled": True,
        "scope": scope,
        "headers_written": written,
        "headers_skipped": skipped,
        "logo_width_cm": logo_width_cm,
        "header_distance_cm": header_distance_cm,
        "replace_existing": replace_existing,
    }


def add_page_field(paragraph) -> None:
    r = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    begin.set(qn("w:dirty"), "false")
    instr = OxmlElement("w:instrText")
    instr.set(f"{{{XML_NS}}}space", "preserve")
    instr.text = " PAGE "
    sep = OxmlElement("w:fldChar")
    sep.set(qn("w:fldCharType"), "separate")
    txt = OxmlElement("w:t")
    txt.text = "1"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    r._r.extend([begin, instr, sep, txt, end])
    set_run_font(r, "Times New Roman", "Times New Roman", 10.5, bold=False)


def ensure_centered_page_numbers(doc: Document) -> int:
    added = 0
    seen_footer_parts: set[int] = set()
    for section in doc.sections:
        footer = section.footer
        key = id(footer._element)
        if key in seen_footer_parts:
            continue
        seen_footer_parts.add(key)
        page_paragraphs = [p for p in footer.paragraphs if p._p.xpath(".//w:instrText[contains(translate(text(),'page','PAGE'),'PAGE')]")]
        if page_paragraphs:
            for p in page_paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for run in p.runs:
                    set_run_font(run, "Times New Roman", "Times New Roman", 10.5, bold=None)
            continue
        p = footer.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        add_page_field(p)
        added += 1
    return added

def _canonical_section_label(role: str) -> str:
    return "［摘要］" if role == "abstract" else "［关键词］"


def _section_prefix_pattern(role: str) -> re.Pattern[str]:
    if role == "abstract":
        return re.compile(r"^[\s［\[]*(?:摘\s*要|中文摘要|内容摘要)[］\]]?\s*[:：]?\s*")
    return re.compile(r"^[\s［\[]*(?:关键词|关键字|主题词)[］\]]?\s*[:：]?\s*")


def _replace_section_prefix_in_paragraph(paragraph: Paragraph, role: str) -> bool:
    """Normalize a section prefix without rebuilding the paragraph runs."""
    texts = paragraph._p.xpath(".//w:t")
    if not texts:
        return False
    full = "".join(t.text or "" for t in texts)
    m = _section_prefix_pattern(role).match(full)
    if not m:
        return False
    cut = m.end()
    remaining = cut
    for t in texts:
        original = t.text or ""
        take = min(remaining, len(original))
        t.text = original[take:]
        remaining -= take
    # Remove whitespace directly after the label.
    for t in texts:
        if t.text:
            t.text = t.text.lstrip()
            break
    texts[0].text = _canonical_section_label(role) + (texts[0].text or "")
    return True


def _remove_paragraph_element(paragraph: Paragraph) -> None:
    parent = paragraph._p.getparent()
    if parent is not None:
        parent.remove(paragraph._p)


def normalize_inline_summary_layout(
    doc: Document,
    roles: dict[int, str],
    insertions: list[dict[str, Any]],
) -> tuple[dict[int, str], list[dict[str, Any]], dict[str, Any]]:
    """Put abstract/keyword labels and their content in one paragraph.

    Existing layouts such as a standalone ``摘要`` paragraph followed by the
    abstract body are merged into ``［摘要］正文``.  The same rule applies to
    keywords.  This runs before the preservation snapshot so the merge is
    treated as an intentional layout normalization rather than content loss.
    """
    paragraphs = list(doc.paragraphs)
    removed: set[int] = set()
    merged: list[dict[str, int | str]] = []
    normalized_inline = 0

    for i, paragraph in enumerate(paragraphs):
        if i in removed:
            continue
        role = roles.get(i)
        text = paragraph.text.strip()
        detected_role = None
        for candidate in ("abstract", "keywords"):
            pattern = _section_prefix_pattern(candidate)
            if pattern.match(text):
                detected_role = candidate
                break
        if detected_role is None:
            continue
        role = detected_role
        remainder = _section_prefix_pattern(role).sub("", text, count=1).strip()
        roles[i] = role

        if remainder:
            if _replace_section_prefix_in_paragraph(paragraph, role):
                normalized_inline += 1
            continue

        # Label-only paragraph: merge with the next nonblank ordinary paragraph.
        j = i + 1
        blank_between: list[int] = []
        while j < len(paragraphs) and not paragraphs[j].text.strip():
            blank_between.append(j)
            j += 1
        if j >= len(paragraphs):
            continue
        next_text = paragraphs[j].text.strip()
        next_role = roles.get(j, "body")
        if any(_section_prefix_pattern(r).match(next_text) for r in ("abstract", "keywords")):
            continue
        if next_role in {"title", "subtitle", "author", "author_info", "heading1", "heading2", "heading3", "heading4", "references_heading", "reference_item", "figure_caption", "table_caption"}:
            continue

        # Normalize the label paragraph, then move all visible/field content from
        # the following paragraph so hyperlinks and inline emphasis are preserved.
        for child in list(paragraph._p):
            if child.tag != qn("w:pPr"):
                paragraph._p.remove(child)
        paragraph.add_run(_canonical_section_label(role))
        source_p = paragraphs[j]._p
        for child in list(source_p):
            if child.tag == qn("w:pPr"):
                continue
            source_p.remove(child)
            paragraph._p.append(child)
        # Strip leading whitespace from the first content text node after label.
        text_nodes = paragraph._p.xpath(".//w:t")
        for t in text_nodes[1:]:
            if t.text:
                t.text = t.text.lstrip()
                break
        for idx in blank_between + [j]:
            _remove_paragraph_element(paragraphs[idx])
            removed.add(idx)
        merged.append({"role": role, "label_paragraph": i, "content_paragraph": j})

    if not removed:
        return roles, insertions, {"merged": merged, "normalized_inline": normalized_inline}

    kept = [idx for idx in range(len(paragraphs)) if idx not in removed]
    old_to_new = {old: new for new, old in enumerate(kept)}
    new_roles = {old_to_new[old]: roles.get(old, "body") for old in kept}

    def remap_before(value: Any) -> int:
        try:
            old = int(value)
        except (TypeError, ValueError):
            old = len(paragraphs)
        old = max(0, min(old, len(paragraphs)))
        return sum(1 for idx in range(old) if idx not in removed)

    new_insertions = []
    for item in insertions:
        copied = dict(item)
        copied["before_paragraph"] = remap_before(item.get("before_paragraph", len(paragraphs)))
        if isinstance(item.get("evidence_paragraphs"), list):
            copied["evidence_paragraphs"] = [old_to_new[x] for x in item["evidence_paragraphs"] if isinstance(x, int) and x in old_to_new]
        new_insertions.append(copied)
    return new_roles, new_insertions, {"merged": merged, "normalized_inline": normalized_inline}


def _looks_like_author_info(text: str) -> bool:
    value = re.sub(r"\s+", " ", text.strip())
    if not value:
        return False
    if re.search(r"(?:作者|姓名|学号|课程|班级|专业|学院|学校)\s*[:：]", value):
        return True
    return bool(
        re.fullmatch(r"\d{6,}\s*[\u4e00-\u9fff·]{2,12}", value)
        or re.fullmatch(r"[\u4e00-\u9fff·]{2,12}\s*\d{6,}", value)
    )


def _looks_like_author_name(text: str) -> bool:
    value = re.sub(r"\s+", "", text.strip())
    return bool(re.fullmatch(r"[\u4e00-\u9fff·]{2,8}(?:、[\u4e00-\u9fff·]{2,8}){0,4}", value))


def promote_frontmatter_roles(doc: Document, roles: dict[int, str]) -> dict[int, str]:
    """Recover subtitle and author roles before the abstract/first heading.

    Inspectors may conservatively label these short front-matter lines as body.
    Reclassify only body/no_change paragraphs in the title block, so later
    formatting and WPS validation can force explicit centering.
    """
    if not doc.paragraphs:
        return roles
    boundary = len(doc.paragraphs)
    for i in range(len(doc.paragraphs)):
        if roles.get(i) in {"abstract", "keywords", "heading1", "references_heading", "english_abstract"}:
            boundary = i
            break
    visible = [i for i in range(boundary) if doc.paragraphs[i].text.strip()]
    if not visible:
        return roles
    title_indices = [i for i in visible if roles.get(i) == "title"]
    title_idx = title_indices[0] if title_indices else visible[0]
    roles[title_idx] = "title"
    subtitle_seen = any(roles.get(i) == "subtitle" for i in visible)
    author_seen = any(roles.get(i) in {"author", "author_info"} for i in visible)
    after_title = False
    for i in visible:
        if i == title_idx:
            after_title = True
            continue
        if not after_title or roles.get(i) not in {"body", "no_change", None}:
            continue
        value = re.sub(r"\s+", " ", doc.paragraphs[i].text.strip())
        if re.match(r"^(?:——|—{2,}|--)", value):
            roles[i] = "subtitle"
            subtitle_seen = True
            continue
        if _looks_like_author_info(value):
            roles[i] = "author_info"
            author_seen = True
            continue
        if _looks_like_author_name(value):
            roles[i] = "author"
            author_seen = True
            continue
        sentence_like = value.endswith(("。", "！", "？", "；")) or len(value) > 90
        if not subtitle_seen and not sentence_like:
            roles[i] = "subtitle"
            subtitle_seen = True
        elif not author_seen and len(value) <= 50 and not sentence_like:
            roles[i] = "author_info"
            author_seen = True
    return roles


def infer_roles(doc: Document) -> dict[int, str]:
    roles: dict[int, str] = {}
    in_refs = False
    for i, p in enumerate(doc.paragraphs):
        s = p.text.strip()
        if not s:
            roles[i] = "blank"
        elif re.fullmatch(r"参考文献", s):
            roles[i] = "references_heading"; in_refs = True
        elif in_refs:
            roles[i] = "reference_item"
        elif re.match(r"^[［\[]?摘要[］\]]?[:：]?", s): roles[i] = "abstract"
        elif re.match(r"^[［\[]?关键词[］\]]?[:：]?", s): roles[i] = "keywords"
        elif re.match(r"^[一二三四五六七八九十百]+、", s): roles[i] = "heading1"
        elif re.match(r"^（[一二三四五六七八九十百]+）", s): roles[i] = "heading2"
        elif re.match(r"^\d+[\.．]\s*", s): roles[i] = "heading3"
        elif re.match(r"^（\d+）", s): roles[i] = "heading4"
        elif re.match(r"^图\s*\d+", s): roles[i] = "figure_caption"
        elif re.match(r"^表\s*\d+", s): roles[i] = "table_caption"
        elif re.match(r"^(注|数据来源|资料来源)[:：]", s): roles[i] = "figure_or_table_note"
        elif i == 0: roles[i] = "title"
        else: roles[i] = "body"
    # Leading blank paragraphs are common in old DOC/WPS files.  If no visible
    # title was assigned, promote the first nonblank paragraph before the
    # abstract/first heading instead of treating it as body text.
    visible_titles = [i for i, r in roles.items() if r == "title" and doc.paragraphs[i].text.strip()]
    if not visible_titles:
        for i, p in enumerate(doc.paragraphs[:20]):
            value = p.text.strip()
            if not value:
                continue
            if roles.get(i) in {"abstract", "keywords", "heading1", "references_heading"}:
                break
            roles[i] = "title"
            break
    return promote_frontmatter_roles(doc, roles)


def load_plan(path: Path | None, doc: Document) -> tuple[dict[int, str], dict[str, Any], list[dict[str, Any]], dict[str, Any]]:
    if path is None:
        return infer_roles(doc), {}, [], {}
    data = json.loads(path.read_text(encoding="utf-8"))
    raw_roles = data.get("paragraph_roles", {})
    roles = {int(k): v for k, v in raw_roles.items() if v in ROLE_NAMES}
    for i, p in enumerate(doc.paragraphs):
        roles.setdefault(i, "blank" if not p.text.strip() else "body")
    raw_insertions = data.get("insertions", [])
    insertions = [x for x in raw_insertions if isinstance(x, dict)]
    table_configs = data.get("tables", {}) if isinstance(data.get("tables", {}), dict) else {}
    options = data.get("options", {}) if isinstance(data.get("options", {}), dict) else {}
    if isinstance(data.get("request_overrides"), dict):
        options["_request_overrides"] = data["request_overrides"]
    if isinstance(data.get("template_requirements"), dict):
        options["_template_requirements"] = data["template_requirements"]
    if isinstance(data.get("style_overrides"), dict):
        options["style_overrides"] = data["style_overrides"]
    roles = promote_frontmatter_roles(doc, roles)
    if isinstance(data.get("reference_links"), list):
        options["reference_links"] = data["reference_links"]
    if isinstance(data.get("manual_citation_conversions"), list):
        options["manual_citation_conversions"] = data["manual_citation_conversions"]
    return roles, options, insertions, table_configs

def normalize_generated_prose_quotes(text: str) -> str:
    """Normalize straight double quotes in model-generated Chinese prose.

    Generated abstracts and keywords are natural-language sections, so they
    must not depend on a later role-detection pass to receive Chinese quotes.
    Both ASCII and full-width straight double quotation marks are handled.
    """
    chars = list(str(text))
    positions = [i for i, ch in enumerate(chars) if ch in STRAIGHT_DOUBLE_QUOTES]
    pairable = len(positions) - (len(positions) % 2)
    for idx, pos in enumerate(positions[:pairable]):
        chars[pos] = "“" if idx % 2 == 0 else "”"
    return "".join(chars)


def normalize_centered_frontmatter(paragraph: Paragraph, role: str) -> int:
    """Rebuild title-area paragraphs into renderer-neutral plain paragraphs.

    WPS is highly sensitive to inherited list numbering, tab leaders, paragraph
    borders, frame positioning, manual breaks, non-breaking spaces, and run-level
    leftovers.  For title/subtitle/author blocks these properties carry no
    semantic value, so the paragraph is rebuilt from its visible text and all
    layout-affecting inherited properties are removed.
    """
    if role not in {"title", "subtitle", "author", "author_info"}:
        return 0
    changed = 0
    fmt = paragraph.paragraph_format
    fmt.left_indent = Pt(0)
    fmt.right_indent = Pt(0)
    fmt.first_line_indent = Pt(0)
    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    ppr = paragraph._p.get_or_add_pPr()
    # Remove properties that commonly create bullets, leaders, dotted rules,
    # narrow text frames, or renderer-specific offsets in WPS.
    for tag in ("tabs", "numPr", "pBdr", "framePr", "shd", "contextualSpacing", "textAlignment"):
        el = ppr.find(qn(f"w:{tag}"))
        if el is not None:
            ppr.remove(el)
            changed += 1
    pstyle = ppr.find(qn("w:pStyle"))
    if pstyle is not None:
        ppr.remove(pstyle)
        changed += 1
    ind = ppr.find(qn("w:ind"))
    if ind is None:
        ind = OxmlElement("w:ind")
        ppr.append(ind)
        changed += 1
    for attr in ("left", "right", "firstLine", "hanging", "start", "end"):
        q = qn(f"w:{attr}")
        if ind.get(q) not in {None, "0"}:
            changed += 1
        ind.set(q, "0")
    for tag in ("autoSpaceDE", "autoSpaceDN", "adjustRightInd", "snapToGrid"):
        el = ppr.find(qn(f"w:{tag}"))
        if el is None:
            el = OxmlElement(f"w:{tag}")
            ppr.append(el)
            changed += 1
        el.set(qn("w:val"), "0")

    original = paragraph.text
    normalized = re.sub(r"[\t\r\n\v\f]+", "", original)
    normalized = re.sub(r"[\u00a0\u2000-\u200f\u202f\u205f\u3000\ufeff\u00ad]+", " ", normalized)
    normalized = re.sub(r"[ ]+", " ", normalized).strip()
    if contains_cjk(normalized):
        normalized = re.sub(r"\s*([“”‘’《》〈〉（）()【】\[\]])\s*", r"\1", normalized)
        normalized = re.sub(r"(?<=[\u3400-\u4dbf\u4e00-\u9fff])\s+(?=[\u3400-\u4dbf\u4e00-\u9fff])", "", normalized)
        normalized = re.sub(r"(?<=[\u3400-\u4dbf\u4e00-\u9fff])\s+(?=[“‘《〈（【])", "", normalized)
        normalized = re.sub(r"(?<=[”’》〉）】])\s+(?=[\u3400-\u4dbf\u4e00-\u9fff])", "", normalized)

    # Always rebuild these short front-matter paragraphs.  This removes hidden
    # run-level tabs/breaks/fields and prevents WPS from reusing stale run widths.
    for child in list(paragraph._p):
        if child.tag != qn("w:pPr"):
            paragraph._p.remove(child)
    paragraph.add_run(normalized)
    if normalized != original or paragraph._p.xpath(".//w:tab|.//w:br|.//w:cr"):
        changed += 1
    return changed


def normalize_generated_text(role: str, text: str) -> str:
    text = re.sub(r"[\r\n]+", " ", str(text)).strip()
    text = normalize_generated_prose_quotes(text)
    if role == "abstract":
        text = re.sub(r"^[［\[]?摘要[］\]]?[:：]?\s*", "", text)
        return f"［摘要］{text}"
    if role == "keywords":
        text = re.sub(r"^[［\[]?关键词[］\]]?[:：]?\s*", "", text)
        text = text.rstrip("。.;； ")
        return f"［关键词］{text}"
    return text


def _section_label_regex(role: str) -> re.Pattern[str]:
    if role == "abstract":
        return re.compile(r"^(?:[［\[]?\s*(?:摘\s*要|中文摘要|内容摘要)\s*[］\]]?\s*[:：]?)")
    return re.compile(r"^(?:[［\[]?\s*(?:关键词|关键字|主题词)\s*[］\]]?\s*[:：]?)")


def document_has_section(doc: Document, role: str) -> bool:
    pattern = _section_label_regex(role)
    texts = [p.text.strip() for p in doc.paragraphs[:50]]
    for table in doc.tables[:8]:
        for row in table.rows:
            for cell in row.cells:
                texts.extend(p.text.strip() for p in cell.paragraphs)
    return any(pattern.match(text) for text in texts if text)


def _generated_claim_warnings(text: str, source_text: str) -> list[str]:
    warnings: list[str] = []
    for number in sorted(set(re.findall(r"\d+(?:\.\d+)?%?", text))):
        if number not in source_text:
            warnings.append(f"生成内容中的数字“{number}”未在原稿中出现。")
    method_terms = ["双重差分", "DID", "断点回归", "工具变量", "固定效应", "问卷调查", "访谈法", "案例研究", "文本分析", "回归分析"]
    for term in method_terms:
        if term in text and term not in source_text:
            warnings.append(f"生成内容提到“{term}”，但原稿中未检出该方法名称。")
    return warnings


def insert_generated_sections(
    doc: Document,
    roles: dict[int, str],
    insertions: list[dict[str, Any]],
) -> tuple[dict[int, str], dict[str, Any]]:
    original_paragraphs = list(doc.paragraphs)
    n = len(original_paragraphs)
    source_text = "\n".join(p.text for p in original_paragraphs)
    existing_roles = set(roles.values())
    accepted: list[dict[str, Any]] = []
    skipped: list[str] = []
    warnings: list[str] = []
    allowed = {"abstract", "keywords"}

    for order, item in enumerate(insertions):
        role = str(item.get("role", "")).strip()
        if role not in allowed:
            skipped.append(f"插入项{order + 1}的角色无效：{role or '空'}")
            continue
        if role in existing_roles or document_has_section(doc, role) or any(x["role"] == role for x in accepted):
            skipped.append(f"原稿已存在{('摘要' if role == 'abstract' else '关键词')}，未覆盖。")
            continue
        try:
            before = int(item.get("before_paragraph", n))
        except (TypeError, ValueError):
            before = n
        if before < 0 or before > n:
            skipped.append(f"{role}的插入位置{before}超出范围0—{n}。")
            continue
        text = normalize_generated_text(role, item.get("text", ""))
        visible = _section_label_regex(role).sub("", text).strip()
        if not visible:
            skipped.append(f"{role}插入文本为空。")
            continue
        claim_warnings = _generated_claim_warnings(visible, source_text) if role == "abstract" else []
        if claim_warnings:
            skipped.append(f"{role}因事实一致性检查未通过而未插入：" + "；".join(claim_warnings))
            continue
        evidence = item.get("evidence_paragraphs", [])
        if role == "abstract" and not evidence:
            warnings.append("自动生成摘要未提供 evidence_paragraphs 证据段落索引，需人工复核。")
        accepted.append({
            "before": before,
            "role": role,
            "text": text,
            "source": str(item.get("source", "model_generated")),
            "evidence_paragraphs": evidence,
            "order": order,
        })

    accepted.sort(key=lambda x: (x["before"], x["order"]))
    grouped: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for item in accepted:
        grouped[item["before"]].append(item)

    body = doc._body._element
    for before in sorted(grouped):
        target = original_paragraphs[before]._p if before < n else body.sectPr
        for item in grouped[before]:
            new_p = OxmlElement("w:p")
            if target is not None:
                target.addprevious(new_p)
            else:
                body.append(new_p)
            para = Paragraph(new_p, doc._body)
            para.add_run(item["text"])

    new_roles: dict[int, str] = {}
    new_idx = 0
    inserted_details: list[dict[str, Any]] = []
    for original_idx in range(n + 1):
        for item in grouped.get(original_idx, []):
            new_roles[new_idx] = item["role"]
            content_only = _section_label_regex(item["role"]).sub("", item["text"]).strip()
            char_count = len(content_only)
            keyword_count = len([x for x in re.split(r"[；;]", content_only) if x.strip()]) if item["role"] == "keywords" else None
            if item["role"] == "abstract" and not 250 <= char_count <= 400:
                warnings.append(f"自动生成摘要长度为{char_count}字，未落在建议的250—400字范围内。")
            if item["role"] == "keywords" and keyword_count is not None and not 3 <= keyword_count <= 5:
                warnings.append(f"自动生成关键词数量为{keyword_count}个，未落在要求的3—5个范围内。")
            inserted_details.append({
                "role": item["role"], "paragraph_index": new_idx, "characters": char_count,
                "keyword_count": keyword_count, "source": item["source"],
                "evidence_paragraphs": item.get("evidence_paragraphs", []),
            })
            new_idx += 1
        if original_idx < n:
            new_roles[new_idx] = roles.get(original_idx, "blank" if not original_paragraphs[original_idx].text.strip() else "body")
            new_idx += 1

    return new_roles, {"inserted": inserted_details, "skipped": skipped, "warnings": warnings}

def unzip_docx(src: Path, dst: Path) -> None:
    with zipfile.ZipFile(src, "r") as zf:
        zf.extractall(dst)


def zip_docx(src_dir: Path, dst: Path) -> None:
    if dst.exists():
        dst.unlink()
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, _, files in os.walk(src_dir):
            for name in files:
                p = Path(root) / name
                zf.write(p, p.relative_to(src_dir).as_posix())


def load_xml(path: Path) -> etree._ElementTree:
    return etree.parse(str(path), etree.XMLParser(remove_blank_text=False))


def save_xml(tree: etree._ElementTree, path: Path) -> None:
    tree.write(str(path), xml_declaration=True, encoding="UTF-8", standalone="yes")


def ensure_child(parent: etree._Element, tag: str) -> etree._Element:
    child = parent.find(f"w:{tag}", namespaces=NS)
    if child is None:
        child = etree.SubElement(parent, wq(tag))
    return child


def normalize_rpr_portability(r: etree._Element) -> int:
    """Remove run-level metrics that commonly cause local reflow or overlap."""
    rpr = r.find("w:rPr", namespaces=NS)
    if rpr is None:
        return 0
    changed = 0
    for tag in ("spacing", "position", "w", "kern"):
        el = rpr.find(f"w:{tag}", namespaces=NS)
        if el is not None:
            rpr.remove(el)
            changed += 1
    lang = rpr.find("w:lang", namespaces=NS)
    if lang is None:
        lang = etree.SubElement(rpr, wq("lang"))
        changed += 1
    if lang.get(wq("val")) != "en-US":
        lang.set(wq("val"), "en-US"); changed += 1
    if lang.get(wq("eastAsia")) != "zh-CN":
        lang.set(wq("eastAsia"), "zh-CN"); changed += 1
    return changed


def set_rpr_font(r: etree._Element, east="宋体", latin="Times New Roman", size_half_points="18", superscript=False) -> None:
    rpr = r.find("w:rPr", namespaces=NS)
    if rpr is None:
        rpr = etree.Element(wq("rPr")); r.insert(0, rpr)
    rfonts = rpr.find("w:rFonts", namespaces=NS)
    if rfonts is None:
        rfonts = etree.SubElement(rpr, wq("rFonts"))
    rfonts.set(wq("eastAsia"), east); rfonts.set(wq("ascii"), latin); rfonts.set(wq("hAnsi"), latin); rfonts.set(wq("cs"), latin)
    sz = rpr.find("w:sz", namespaces=NS)
    if sz is None: sz = etree.SubElement(rpr, wq("sz"))
    sz.set(wq("val"), size_half_points)
    szcs = rpr.find("w:szCs", namespaces=NS)
    if szcs is None: szcs = etree.SubElement(rpr, wq("szCs"))
    szcs.set(wq("val"), size_half_points)
    normalize_rpr_portability(r)
    if superscript:
        va = rpr.find("w:vertAlign", namespaces=NS)
        if va is None: va = etree.SubElement(rpr, wq("vertAlign"))
        va.set(wq("val"), "superscript")
        rs = rpr.find("w:rStyle", namespaces=NS)
        if rs is None: rs = etree.SubElement(rpr, wq("rStyle"))
        rs.set(wq("val"), "FootnoteReference")


def normalize_paragraph_portability(p: etree._Element) -> int:
    """Disable document-grid and contextual-spacing behavior for stable local layout."""
    ppr = p.find("w:pPr", namespaces=NS)
    if ppr is None:
        ppr = etree.Element(wq("pPr")); p.insert(0, ppr)
    changed = 0
    for tag, val in (("snapToGrid", "0"), ("contextualSpacing", "0"), ("adjustRightInd", "0")):
        el = ppr.find(f"w:{tag}", namespaces=NS)
        if el is None:
            el = etree.SubElement(ppr, wq(tag)); changed += 1
        if el.get(wq("val")) != val:
            el.set(wq("val"), val); changed += 1
    mirror = ppr.find("w:mirrorIndents", namespaces=NS)
    if mirror is not None:
        ppr.remove(mirror); changed += 1
    return changed




ROLE_XML_FONT: dict[str, tuple[str, str, str]] = {
    "title": ("黑体", "Times New Roman", "44"),
    "subtitle": ("宋体", "Times New Roman", "28"),
    "author": ("宋体", "Times New Roman", "28"),
    "author_info": ("宋体", "Times New Roman", "21"),
    "abstract": ("仿宋", "Times New Roman", "21"),
    "keywords": ("仿宋", "Times New Roman", "21"),
    "heading1": ("黑体", "Times New Roman", "24"),
    "heading2": ("黑体", "Times New Roman", "21"),
    "heading3": ("宋体", "Times New Roman", "21"),
    "heading4": ("宋体", "Times New Roman", "21"),
    "body": ("宋体", "Times New Roman", "21"),
    "figure_caption": ("黑体", "Times New Roman", "18"),
    "table_caption": ("黑体", "Times New Roman", "18"),
    "figure_or_table_note": ("宋体", "Times New Roman", "15"),
    "references_heading": ("黑体", "Times New Roman", "24"),
    "reference_item": ("宋体", "Times New Roman", "21"),
    "appendix_heading": ("黑体", "Times New Roman", "24"),
    "english_title": ("Times New Roman", "Times New Roman", "24"),
    "english_abstract": ("Times New Roman", "Times New Roman", "21"),
    "english_keywords": ("Times New Roman", "Times New Roman", "21"),
}

CHINESE_QUOTE_ROLES = {
    "title", "subtitle", "abstract", "keywords", "heading1", "heading2",
    "heading3", "heading4", "body", "figure_caption", "table_caption",
    "figure_or_table_note", "appendix_heading",
}


def run_visible_text(r: etree._Element) -> str:
    return "".join(r.xpath(".//w:t/text()", namespaces=NS))


def is_footnote_marker_run(r: etree._Element) -> bool:
    if r.find("w:footnoteReference", namespaces=NS) is not None:
        return True
    style = r.find("w:rPr/w:rStyle", namespaces=NS)
    return bool(style is not None and style.get(wq("val")) == "FootnoteReference")


def expected_font_for_run(role: str, r: etree._Element, style_overrides: dict[str, Any] | None = None) -> tuple[str, str, str] | None:
    spec = ROLE_XML_FONT.get(role)
    if spec is None:
        return None
    cfg = style_overrides.get(role, {}) if isinstance(style_overrides, dict) else {}
    east = str(cfg.get("east_asia_font", spec[0])) if isinstance(cfg, dict) else spec[0]
    latin = str(cfg.get("latin_font", spec[1])) if isinstance(cfg, dict) else spec[1]
    try:
        size_half = str(int(round(float(cfg.get("font_size_pt", float(spec[2]) / 2)) * 2))) if isinstance(cfg, dict) else spec[2]
    except (TypeError, ValueError):
        size_half = spec[2]
    text = run_visible_text(r).strip()
    if role == "abstract" and re.match(r"^[［\[]?摘要[］\]]?[:：]?", text):
        label_east = str(cfg.get("label_east_asia_font", "黑体")) if isinstance(cfg, dict) else "黑体"
        label_latin = str(cfg.get("label_latin_font", "Times New Roman")) if isinstance(cfg, dict) else "Times New Roman"
        try:
            label_size = str(int(round(float(cfg.get("label_font_size_pt", float(size_half) / 2)) * 2))) if isinstance(cfg, dict) else size_half
        except (TypeError, ValueError):
            label_size = size_half
        return (label_east, label_latin, label_size)
    if role == "keywords" and re.match(r"^[［\[]?关键词[］\]]?[:：]?", text):
        label_east = str(cfg.get("label_east_asia_font", "黑体")) if isinstance(cfg, dict) else "黑体"
        label_latin = str(cfg.get("label_latin_font", "Times New Roman")) if isinstance(cfg, dict) else "Times New Roman"
        try:
            label_size = str(int(round(float(cfg.get("label_font_size_pt", float(size_half) / 2)) * 2))) if isinstance(cfg, dict) else size_half
        except (TypeError, ValueError):
            label_size = size_half
        return (label_east, label_latin, label_size)
    return (east, latin, size_half)


def font_signature_matches(r: etree._Element, east: str, latin: str, size_half_points: str) -> bool:
    rpr = r.find("w:rPr", namespaces=NS)
    if rpr is None:
        return False
    rfonts = rpr.find("w:rFonts", namespaces=NS)
    if rfonts is None:
        return False
    if rfonts.get(wq("eastAsia")) != east:
        return False
    for attr in ("ascii", "hAnsi", "cs"):
        if rfonts.get(wq(attr)) != latin:
            return False
    sz = rpr.find("w:sz", namespaces=NS)
    szcs = rpr.find("w:szCs", namespaces=NS)
    return bool(sz is not None and szcs is not None and sz.get(wq("val")) == size_half_points and szcs.get(wq("val")) == size_half_points)


def quote_text_nodes(p: etree._Element) -> list[etree._Element]:
    """Return text nodes whose nearest paragraph ancestor is ``p``.

    Word may nest paragraphs inside text boxes, content controls, hyperlinks,
    and table cells.  Iterating every paragraph and using the nearest ancestor
    prevents both missed text and duplicate processing.
    """
    nodes: list[etree._Element] = []
    for t in p.xpath(".//w:t", namespaces=NS):
        nearest = next((a for a in t.iterancestors() if a.tag == wq("p")), None)
        if nearest is p:
            nodes.append(t)
    return nodes


def contains_cjk(text: str) -> bool:
    return bool(re.search(r"[\u3400-\u4dbf\u4e00-\u9fff]", text))


def paragraph_is_code_like(text: str) -> bool:
    """Identify paragraphs that are predominantly code/structured data.

    Mixed Chinese prose containing a short JSON or command example is *not*
    treated as a code paragraph; protected spans are handled separately.
    """
    stripped = text.strip()
    if not stripped:
        return False
    if re.fullmatch(r"https?://\S+|www\.\S+|\S+@\S+\.\S+", stripped, re.I):
        return True
    if stripped.startswith("```") or stripped.endswith("```"):
        return True
    if (stripped.startswith("{") and stripped.endswith("}") and re.search(r'"[^"\n]+"\s*:', stripped)):
        return True
    if re.match(r"^(?:SELECT|INSERT|UPDATE|DELETE|CREATE|DROP|def\s|class\s|import\s|from\s|print\(|console\.log\(|<\?xml|<!DOCTYPE|<html)(?:\b|$)", stripped, re.I):
        return True
    code_marks = len(re.findall(r"[{}<>:=;]|\\[A-Za-z]|\b(?:NULL|TRUE|FALSE|SELECT|WHERE|VALUES)\b", stripped, re.I))
    cjk = len(re.findall(r"[\u3400-\u4dbf\u4e00-\u9fff]", stripped))
    return code_marks >= 6 and cjk <= 2


def _protected_quote_positions(text: str) -> set[int]:
    positions: set[int] = set()
    quote_positions = {i for i, ch in enumerate(text) if ch in STRAIGHT_DOUBLE_QUOTES}
    if not quote_positions:
        return positions
    if paragraph_is_code_like(text):
        return quote_positions

    protected_patterns = [
        r"https?://\S+|www\.\S+|\b[\w.+-]+@[\w.-]+\.\w+",
        r"`[^`\n]*`",
        r"\{[^{}\n]{0,800}\}",
        r"\[[^\[\]\n]{0,800}\]",
        r"\b[\w:.-]+\s*=\s*\"(?:\\.|[^\"\\])*\"",
        r"(?:\b[A-Za-z_][A-Za-z0-9_.]*\s*\(|=\s*)\"(?:\\.|[^\"\\])*\"",
    ]
    for pat in protected_patterns:
        for m in re.finditer(pat, text, re.I):
            segment = m.group(0)
            # Braces/brackets are protected only when they are actually
            # structured data, not an ordinary Chinese parenthetical example.
            if segment.startswith(("{", "[")) and not re.search(r'"(?:\\.|[^"\\])*"\s*:', segment):
                continue
            positions.update(i for i in quote_positions if m.start() <= i < m.end())

    # Escaped quotes are not quotation marks.
    for i in quote_positions:
        if i > 0 and text[i - 1] == "\\":
            positions.add(i)
    # Common inch/second/unit marks: 5"英寸、27"显示器、3"单位符号。
    for m in re.finditer(r'\d+(?:\.\d+)?(?P<q>")(?=\s*(?:英寸|寸|秒|单位|显示器|屏幕|口径|长度|宽度|高度))', text):
        positions.add(m.start("q"))
    return positions


def paragraph_should_normalize_quotes(role: str, text: str) -> bool:
    if not contains_cjk(text):
        return False
    if role in {"english_title", "english_abstract", "english_keywords", "reference_item"}:
        return False
    return not paragraph_is_code_like(text)


def count_unprotected_ascii_quotes(text: str) -> int:
    protected = _protected_quote_positions(text)
    return sum(1 for i, ch in enumerate(text) if ch in STRAIGHT_DOUBLE_QUOTES and i not in protected)


def convert_ascii_double_quotes(nodes: list[etree._Element]) -> tuple[int, int, bool, str]:
    """Convert all natural-language straight double quotes across run boundaries.

    Code/URL/JSON spans are protected at pair level rather than exempting an
    entire mixed prose paragraph.  If an odd natural-language quote remains,
    complete pairs are still converted and the unmatched quote is reported.
    """
    if not nodes:
        return 0, 0, False, ""
    parts = [n.text or "" for n in nodes]
    full = "".join(parts)
    if not any(ch in STRAIGHT_DOUBLE_QUOTES for ch in full):
        return 0, 0, False, full
    protected_positions = _protected_quote_positions(full)
    natural_positions = [i for i, ch in enumerate(full) if ch in STRAIGHT_DOUBLE_QUOTES and i not in protected_positions]
    chars = list(full)
    pairable = len(natural_positions) - (len(natural_positions) % 2)
    for j, pos in enumerate(natural_positions[:pairable]):
        chars[pos] = "“" if j % 2 == 0 else "”"
    changed = "".join(chars)
    offset = 0
    for node, original in zip(nodes, parts):
        node.text = changed[offset:offset + len(original)]
        offset += len(original)
    return pairable, len(protected_positions), len(natural_positions) % 2 == 1, full

def semantic_role_from_visible_text(role: str, text: str) -> str:
    """Recover summary roles even if paragraph indices/bookmarks drift."""
    stripped = text.lstrip()
    if re.match(r"^［摘要］", stripped):
        return "abstract"
    if re.match(r"^［关键词］", stripped):
        return "keywords"
    return role


def stabilize_wps_paragraph_xml(p: etree._Element, role: str) -> int:
    """Apply strict WPS-safe properties to title-area paragraphs."""
    if role not in {"title", "subtitle", "author", "author_info"}:
        return 0
    changed = 0
    ppr = p.find("w:pPr", namespaces=NS)
    if ppr is None:
        ppr = etree.Element(wq("pPr")); p.insert(0, ppr); changed += 1
    for tag in ("tabs", "numPr", "pBdr", "framePr", "shd", "contextualSpacing", "textAlignment", "pStyle"):
        el = ppr.find(f"w:{tag}", namespaces=NS)
        if el is not None:
            ppr.remove(el); changed += 1
    jc = ppr.find("w:jc", namespaces=NS)
    if jc is None:
        jc = etree.SubElement(ppr, wq("jc")); changed += 1
    if jc.get(wq("val")) != "center":
        jc.set(wq("val"), "center"); changed += 1
    ind = ppr.find("w:ind", namespaces=NS)
    if ind is None:
        ind = etree.SubElement(ppr, wq("ind")); changed += 1
    for attr in ("left", "right", "firstLine", "hanging", "start", "end"):
        key = wq(attr)
        if ind.get(key) != "0":
            ind.set(key, "0"); changed += 1
    for tag in ("autoSpaceDE", "autoSpaceDN", "adjustRightInd", "snapToGrid"):
        el = ppr.find(f"w:{tag}", namespaces=NS)
        if el is None:
            el = etree.SubElement(ppr, wq(tag)); changed += 1
        if el.get(wq("val")) != "0":
            el.set(wq("val"), "0"); changed += 1
    for tag in ("keepLines", "keepNext"):
        el = ppr.find(f"w:{tag}", namespaces=NS)
        if el is None:
            el = etree.SubElement(ppr, wq(tag)); changed += 1
        if el.get(wq("val")) not in {"1", "true", "on"}:
            el.set(wq("val"), "1"); changed += 1
    return changed


def final_quality_pass(unz: Path, roles: dict[int, str], table_configs: dict[str, Any], report: dict[str, Any], style_overrides: dict[str, Any] | None = None, options: dict[str, Any] | None = None) -> None:
    options = options or {}
    bottom_marker_hp = str(int(round(float(options.get("footnote_marker_size_pt", 10.5)) * 2)))
    footnote_text_hp = str(int(round(float(options.get("footnote_text_size_pt", 9.0)) * 2)))
    path = unz / "word" / "document.xml"
    tree = load_xml(path); root = tree.getroot()
    body = root.find("w:body", namespaces=NS)
    if body is None:
        report["final_quality"] = {"font_runs_corrected": 0, "remaining_font_mismatches": 0, "ascii_double_quotes_replaced": 0, "remaining_unprotected_ascii_double_quotes": 0, "protected_ascii_double_quotes": 0, "quote_balance_errors": 0, "quote_warnings": [], "portable_run_properties_removed": 0, "paragraphs_stabilized": 0}
        return
    corrected = 0; portable_props = 0; paragraphs_stabilized = 0
    quote_replaced = 0; protected_quotes = 0; quote_warnings: list[str] = []
    top_paras = body.findall("w:p", namespaces=NS)
    top_index = {id(p): idx for idx, p in enumerate(top_paras)}

    # Font and paragraph stabilization for top-level semantic paragraphs.
    wps_paragraphs_stabilized = 0
    for idx, p in enumerate(top_paras):
        visible_text = "".join(t.text or "" for t in quote_text_nodes(p))
        role = semantic_role_from_visible_text(role_from_bookmarks(p, roles.get(idx, "body")), visible_text)
        paragraphs_stabilized += normalize_paragraph_portability(p)
        wps_paragraphs_stabilized += stabilize_wps_paragraph_xml(p, role)
        for r in p.xpath(".//w:r", namespaces=NS):
            if is_footnote_marker_run(r) or not r.xpath(".//w:t|.//w:instrText|.//w:fldChar", namespaces=NS):
                continue
            portable_props += normalize_rpr_portability(r)
            spec = expected_font_for_run(role, r, style_overrides)
            if spec is not None and not font_signature_matches(r, *spec):
                set_rpr_font(r, east=spec[0], latin=spec[1], size_half_points=spec[2], superscript=False)
                corrected += 1

    # Normalize quotes in every Chinese prose paragraph, including paragraphs
    # nested in tables, text boxes, hyperlinks, and content controls.  Role
    # bookmarks override position-based role guesses, so no_change paragraphs
    # cannot silently bypass the quote requirement.
    for serial, p in enumerate(root.xpath(".//w:p", namespaces=NS), start=1):
        paragraphs_stabilized += normalize_paragraph_portability(p)
        idx = top_index.get(id(p))
        role = role_from_bookmarks(p, roles.get(idx, "body") if idx is not None else "body")
        nodes = quote_text_nodes(p)
        role = semantic_role_from_visible_text(role, "".join(t.text or "" for t in nodes))
        full = "".join(t.text or "" for t in nodes)
        if not paragraph_should_normalize_quotes(role, full):
            continue
        replaced, protected, odd, original = convert_ascii_double_quotes(nodes)
        quote_replaced += replaced; protected_quotes += protected
        if odd:
            quote_warnings.append(f"中文段落{serial}含无法成对的英文直双引号；已转换完整配对，剩余单个引号需人工复核：{re.sub(r'\\s+', ' ', original).strip()[:100]}")
        elif protected:
            quote_warnings.append(f"中文段落{serial}有{protected}个代码、URL、JSON或单位中的直双引号被保护。")

    # Tables still need explicit font normalization, but preserve-mode tables
    # retain their author-specified text formatting.
    top_tables = body.findall("w:tbl", namespaces=NS)
    for t_idx, tbl in enumerate(top_tables):
        cfg_raw = table_configs.get(str(t_idx), table_configs.get(t_idx, {})) if isinstance(table_configs, dict) else {}
        mode = str(cfg_raw.get("mode", "auto")) if isinstance(cfg_raw, dict) else "auto"
        for p in tbl.xpath(".//w:p", namespaces=NS):
            paragraphs_stabilized += normalize_paragraph_portability(p)
        if mode == "preserve":
            continue
        size_half = str(int(round(float(cfg_raw.get("font_size", 9)) * 2))) if isinstance(cfg_raw, dict) else "18"
        for r in tbl.xpath(".//w:r", namespaces=NS):
            if is_footnote_marker_run(r) or not r.xpath(".//w:t|.//w:instrText|.//w:fldChar", namespaces=NS):
                continue
            portable_props += normalize_rpr_portability(r)
            if not font_signature_matches(r, "宋体", "Times New Roman", size_half):
                set_rpr_font(r, east="宋体", latin="Times New Roman", size_half_points=size_half, superscript=False)
                corrected += 1
    save_xml(tree, path)

    # Footnotes are a separate XML part and need their own quote/font/layout pass.
    foot_path = unz / "word" / "footnotes.xml"
    foot_corrected = 0
    if foot_path.exists():
        ftree = load_xml(foot_path); froot = ftree.getroot()
        for p in froot.xpath(".//w:footnote[not(@w:id='-1') and not(@w:id='0')]//w:p", namespaces=NS):
            paragraphs_stabilized += normalize_paragraph_portability(p)
            nodes = quote_text_nodes(p); full = "".join(t.text or "" for t in nodes)
            if paragraph_should_normalize_quotes("footnote", full):
                replaced, protected, odd, original = convert_ascii_double_quotes(nodes)
                quote_replaced += replaced; protected_quotes += protected
                if odd:
                    quote_warnings.append(f"脚注含无法成对的英文直双引号；已转换完整配对，剩余单个引号需人工复核：{re.sub(r'\\s+', ' ', original).strip()[:100]}")
        for r in froot.xpath(".//w:footnote[not(@w:id='-1') and not(@w:id='0')]//w:r", namespaces=NS):
            is_mark = r.find("w:footnoteRef", namespaces=NS) is not None
            portable_props += normalize_rpr_portability(r)
            expected_half = bottom_marker_hp if is_mark else footnote_text_hp
            if not font_signature_matches(r, "宋体", "Times New Roman", expected_half):
                set_rpr_font(r, east="宋体", latin="Times New Roman", size_half_points=expected_half, superscript=is_mark)
                foot_corrected += 1
        save_xml(ftree, foot_path)

    verify_tree = load_xml(path); verify_root = verify_tree.getroot(); verify_body = verify_root.find("w:body", namespaces=NS)
    remaining_fonts = 0; remaining_unprotected = 0; quote_balance_errors = 0
    wps_frontmatter_issues: list[str] = []
    if verify_body is not None:
        verify_top = verify_body.findall("w:p", namespaces=NS)
        verify_top_index = {id(p): idx for idx, p in enumerate(verify_top)}
        for idx, p in enumerate(verify_top):
            visible_text = "".join(t.text or "" for t in quote_text_nodes(p))
            role = semantic_role_from_visible_text(role_from_bookmarks(p, roles.get(idx, "body")), visible_text)
            if role in {"title", "subtitle", "author", "author_info"}:
                if p.xpath(".//w:tab|.//w:br|.//w:cr", namespaces=NS):
                    wps_frontmatter_issues.append(f"{role}仍含制表符或手工换行")
                for bad_tag, label in (("tabs", "自定义制表位"), ("numPr", "列表编号"), ("pBdr", "段落边框"), ("framePr", "文本框定位"), ("pStyle", "继承段落样式")):
                    if p.find(f"w:pPr/w:{bad_tag}", namespaces=NS) is not None:
                        wps_frontmatter_issues.append(f"{role}仍含{label}")
                jc = p.find("w:pPr/w:jc", namespaces=NS)
                if jc is None or jc.get(wq("val")) != "center":
                    wps_frontmatter_issues.append(f"{role}未显式居中")
                ind = p.find("w:pPr/w:ind", namespaces=NS)
                if ind is None or any(ind.get(wq(a), "0") not in {"0", None} for a in ("left", "right", "firstLine", "hanging", "start", "end")):
                    wps_frontmatter_issues.append(f"{role}仍含非零缩进")
            if role == "references_heading":
                pb = p.find("w:pPr/w:pageBreakBefore", namespaces=NS)
                if pb is None or pb.get(wq("val"), "1") in {"0", "false", "off"}:
                    wps_frontmatter_issues.append("参考文献标题未设置另起一页")
            for r in p.xpath(".//w:r", namespaces=NS):
                if is_footnote_marker_run(r) or not r.xpath(".//w:t|.//w:instrText|.//w:fldChar", namespaces=NS):
                    continue
                spec = expected_font_for_run(role, r, style_overrides)
                if spec is not None and not font_signature_matches(r, *spec):
                    remaining_fonts += 1
        for p in verify_root.xpath(".//w:p", namespaces=NS):
            idx = verify_top_index.get(id(p))
            full = "".join(t.text or "" for t in quote_text_nodes(p))
            role = semantic_role_from_visible_text(role_from_bookmarks(p, roles.get(idx, "body") if idx is not None else "body"), full)
            if not paragraph_should_normalize_quotes(role, full):
                continue
            remaining_unprotected += count_unprotected_ascii_quotes(full)
            if full.count("“") != full.count("”"):
                quote_balance_errors += 1
    if foot_path.exists():
        froot = load_xml(foot_path).getroot()
        for p in froot.xpath(".//w:footnote[not(@w:id='-1') and not(@w:id='0')]//w:p", namespaces=NS):
            full = "".join(t.text or "" for t in quote_text_nodes(p))
            if paragraph_should_normalize_quotes("footnote", full):
                remaining_unprotected += count_unprotected_ascii_quotes(full)
                if full.count("“") != full.count("”"):
                    quote_balance_errors += 1
    report["final_quality"] = {
        "font_runs_corrected": corrected + foot_corrected,
        "remaining_font_mismatches": remaining_fonts,
        "ascii_double_quotes_replaced": quote_replaced,
        "remaining_unprotected_ascii_double_quotes": remaining_unprotected,
        "protected_ascii_double_quotes": protected_quotes,
        "quote_balance_errors": quote_balance_errors,
        "quote_warnings": quote_warnings,
        "portable_run_properties_removed": portable_props,
        "paragraphs_stabilized": paragraphs_stabilized,
        "wps_frontmatter_paragraphs_stabilized": wps_paragraphs_stabilized,
        "wps_frontmatter_issues": wps_frontmatter_issues,
    }

def normalize_note_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip().rstrip("。.;； ")


def footnote_fingerprint(fn: etree._Element) -> str | None:
    if fn.xpath(".//w:hyperlink|.//w:fldChar|.//w:instrText|.//m:oMath|.//w:drawing|.//w:object", namespaces={**NS, "m": "http://schemas.openxmlformats.org/officeDocument/2006/math"}):
        return None
    text = normalize_note_text("".join(fn.xpath(".//w:t/text()", namespaces=NS)))
    if not text:
        return None
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def footnote_result_text(n: int, number_format: str) -> str:
    if number_format == "decimalEnclosedCircle" and 1 <= n <= 20:
        return "①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳"[n - 1]
    return str(n)


def field_runs(field_type: str, target: str, result: str, rpr_source: etree._Element | None = None, superscript=False, superscript_size_half_points: str = "18") -> list[etree._Element]:
    runs = []
    def make_run() -> etree._Element:
        r = etree.Element(wq("r"))
        if rpr_source is not None:
            r.append(deepcopy(rpr_source))
        if superscript:
            set_rpr_font(r, size_half_points=superscript_size_half_points, superscript=True)
        return r
    rb = make_run(); f = etree.SubElement(rb, wq("fldChar")); f.set(wq("fldCharType"), "begin"); f.set(wq("dirty"), "false"); runs.append(rb)
    ri = make_run(); ins = etree.SubElement(ri, wq("instrText")); ins.set(f"{{{XML_NS}}}space", "preserve"); ins.text = f" {field_type} {target} \\h "; runs.append(ri)
    rs = make_run(); f = etree.SubElement(rs, wq("fldChar")); f.set(wq("fldCharType"), "separate"); runs.append(rs)
    rr = make_run(); t = etree.SubElement(rr, wq("t")); t.text = result; runs.append(rr)
    re_ = make_run(); f = etree.SubElement(re_, wq("fldChar")); f.set(wq("fldCharType"), "end"); runs.append(re_)
    return runs


def materialize_noteref_results(root: etree._Element, number_format: str) -> int:
    open_bookmarks: list[tuple[str, str]] = []
    bookmark_ordinals: dict[str, int] = {}
    real_ordinal = 0
    for el in root.iter():
        if el.tag == wq("bookmarkStart"):
            bid = el.get(wq("id")) or ""
            name = el.get(wq("name")) or ""
            open_bookmarks.append((bid, name))
        elif el.tag == wq("bookmarkEnd"):
            bid = el.get(wq("id")) or ""
            for i in range(len(open_bookmarks) - 1, -1, -1):
                if open_bookmarks[i][0] == bid:
                    open_bookmarks.pop(i)
                    break
        elif el.tag == wq("footnoteReference"):
            real_ordinal += 1
            for _, name in open_bookmarks:
                if name:
                    bookmark_ordinals[name] = real_ordinal

    updated = 0
    for para in root.xpath(".//w:p", namespaces=NS):
        in_field = False; separated = False; instr = ""; result_nodes: list[etree._Element] = []
        for run in para.xpath(".//w:r", namespaces=NS):
            fld = run.find("w:fldChar", namespaces=NS)
            if fld is not None:
                typ = fld.get(wq("fldCharType"))
                if typ == "begin":
                    in_field = True; separated = False; instr = ""; result_nodes = []
                    continue
                if in_field and typ == "separate":
                    separated = True; continue
                if in_field and typ == "end":
                    m = re.search(r"\bNOTEREF\s+([A-Za-z0-9_:\-.]+)", " ".join(instr.split()), re.I)
                    if m and result_nodes and m.group(1) in bookmark_ordinals:
                        value = footnote_result_text(bookmark_ordinals[m.group(1)], number_format)
                        result_nodes[0].text = value
                        for extra in result_nodes[1:]: extra.text = ""
                        updated += 1
                    in_field = False; separated = False; instr = ""; result_nodes = []
                    continue
            if not in_field: continue
            ins = run.find("w:instrText", namespaces=NS)
            if ins is not None and not separated: instr += ins.text or ""
            if separated: result_nodes.extend(run.findall(".//w:t", namespaces=NS))
    return updated


def _xml_bytes(root: etree._Element) -> bytes:
    return etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone="yes")


def ensure_footnotes_part(unz: Path) -> tuple[etree._ElementTree, etree._Element]:
    fn_path = unz / "word" / "footnotes.xml"
    if fn_path.exists():
        tree = load_xml(fn_path)
        return tree, tree.getroot()
    root = etree.Element(wq("footnotes"), nsmap={"w": W_NS, "r": R_NS})
    for fid, tag in (("-1", "separator"), ("0", "continuationSeparator")):
        fn = etree.SubElement(root, wq("footnote")); fn.set(wq("id"), fid)
        p = etree.SubElement(fn, wq("p")); r = etree.SubElement(p, wq("r")); etree.SubElement(r, wq(tag))
    tree = etree.ElementTree(root)
    save_xml(tree, fn_path)

    rels_path = unz / "word" / "_rels" / "document.xml.rels"
    rels_tree = etree.parse(str(rels_path), etree.XMLParser(remove_blank_text=False))
    rels_root = rels_tree.getroot()
    ns = {"rel": PKGREL_NS}
    if not rels_root.xpath("./rel:Relationship[contains(@Type,'/footnotes')]", namespaces=ns):
        nums = []
        for rel in rels_root.findall(f"{{{PKGREL_NS}}}Relationship"):
            rid = rel.get("Id") or ""
            if rid.startswith("rId") and rid[3:].isdigit():
                nums.append(int(rid[3:]))
        rel = etree.SubElement(rels_root, f"{{{PKGREL_NS}}}Relationship")
        rel.set("Id", f"rId{max(nums or [0]) + 1}")
        rel.set("Type", "http://schemas.openxmlformats.org/officeDocument/2006/relationships/footnotes")
        rel.set("Target", "footnotes.xml")
        rels_tree.write(str(rels_path), xml_declaration=True, encoding="UTF-8", standalone="yes")

    ct_path = unz / "[Content_Types].xml"
    ct_tree = etree.parse(str(ct_path), etree.XMLParser(remove_blank_text=False))
    ct_root = ct_tree.getroot()
    if not ct_root.xpath("./ct:Override[@PartName='/word/footnotes.xml']", namespaces={"ct": CT_NS}):
        ov = etree.SubElement(ct_root, f"{{{CT_NS}}}Override")
        ov.set("PartName", "/word/footnotes.xml")
        ov.set("ContentType", "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml")
        ct_tree.write(str(ct_path), xml_declaration=True, encoding="UTF-8", standalone="yes")
    return tree, root


def _paragraph_by_original_index(root: etree._Element, index: int) -> etree._Element | None:
    name = f"_PaperOrig_{index}"
    matches = root.xpath(f".//w:p[w:bookmarkStart[@w:name='{name}']]", namespaces=NS)
    return matches[0] if matches else None


def _strip_reference_prefix(text: str) -> str:
    return re.sub(r"^\\s*(?:\\[\\s*\\d+\\s*\\]|[（(]?\\d+[）)]?[.、．]?)\\s*", "", text).strip()


def _replace_simple_marker_with_footnote(p: etree._Element, marker: str, occurrence: int, fid: str, body_marker_half_points: str = "18") -> bool:
    remaining = max(1, occurrence)
    for t in p.xpath(".//w:t", namespaces=NS):
        text = t.text or ""
        starts = [m.start() for m in re.finditer(re.escape(marker), text)]
        if remaining > len(starts):
            remaining -= len(starts)
            continue
        start = starts[remaining - 1]; end = start + len(marker)
        r = t.getparent()
        if r is None or r.tag != wq("r"):
            return False
        # Avoid corrupting complex field/object runs. Manual citation markers in
        # ordinary papers are normally isolated in a simple text run.
        if r.xpath("./w:fldChar|./w:instrText|./w:drawing|./w:object|./w:footnoteReference", namespaces=NS):
            return False
        if len(r.findall("w:t", namespaces=NS)) != 1:
            return False
        parent = r.getparent()
        if parent is None:
            return False
        pos = parent.index(r)
        before, after = text[:start], text[end:]
        t.text = before
        if before.startswith(" ") or before.endswith(" "):
            t.set(f"{{{XML_NS}}}space", "preserve")
        nr = etree.Element(wq("r"))
        rpr = r.find("w:rPr", namespaces=NS)
        if rpr is not None:
            nr.append(deepcopy(rpr))
        set_rpr_font(nr, size_half_points=body_marker_half_points, superscript=True)
        ref = etree.SubElement(nr, wq("footnoteReference")); ref.set(wq("id"), fid)
        parent.insert(pos + 1, nr)
        if after:
            ar = etree.Element(wq("r"))
            if rpr is not None:
                ar.append(deepcopy(rpr))
            at = etree.SubElement(ar, wq("t")); at.text = after
            if after.startswith(" ") or after.endswith(" "):
                at.set(f"{{{XML_NS}}}space", "preserve")
            parent.insert(pos + 2, ar)
        return True
    return False


def _append_footnote(fn_root: etree._Element, fid: str, text: str, marker_half_points: str = "21", text_half_points: str = "18") -> None:
    fn = etree.SubElement(fn_root, wq("footnote")); fn.set(wq("id"), fid)
    p = etree.SubElement(fn, wq("p"))
    ppr = etree.SubElement(p, wq("pPr")); pstyle = etree.SubElement(ppr, wq("pStyle")); pstyle.set(wq("val"), "FootnoteText")
    spacing = etree.SubElement(ppr, wq("spacing")); spacing.set(wq("line"), "240"); spacing.set(wq("lineRule"), "auto")
    r0 = etree.SubElement(p, wq("r")); set_rpr_font(r0, size_half_points=marker_half_points, superscript=True); etree.SubElement(r0, wq("footnoteRef"))
    r1 = etree.SubElement(p, wq("r")); set_rpr_font(r1, size_half_points=text_half_points, superscript=False)
    t = etree.SubElement(r1, wq("t")); t.set(f"{{{XML_NS}}}space", "preserve"); t.text = " " + text


def convert_manual_citations_to_footnotes(unz: Path, options: dict[str, Any], report: dict[str, Any]) -> None:
    items = options.get("manual_citation_conversions", [])
    if options.get("citation_mode", "ruc_page_footnote") != "ruc_page_footnote" or not options.get("convert_manual_superscripts", True):
        report["manual_citation_conversions"] = {"created": 0, "unresolved": [], "warnings": [], "details": []}
        return
    if not isinstance(items, list) or not items:
        report["manual_citation_conversions"] = {"created": 0, "unresolved": [], "warnings": [], "details": []}
        return
    doc_path = unz / "word" / "document.xml"
    doc_tree = load_xml(doc_path); doc_root = doc_tree.getroot()
    fn_tree, fn_root = ensure_footnotes_part(unz)
    ids = [int(x.get(wq("id"))) for x in fn_root.xpath("./w:footnote", namespaces=NS) if (x.get(wq("id")) or "").isdigit()]
    next_id = max(ids or [0]) + 1
    created = 0; unresolved: list[str] = []; warnings: list[str] = []; details: list[dict[str, Any]] = []
    body_marker_hp = str(int(round(float(options.get("body_footnote_reference_size_pt", 9.0)) * 2)))
    bottom_marker_hp = str(int(round(float(options.get("footnote_marker_size_pt", 10.5)) * 2)))
    footnote_text_hp = str(int(round(float(options.get("footnote_text_size_pt", 9.0)) * 2)))
    for item in items:
        if not isinstance(item, dict):
            continue
        try:
            pidx = int(item.get("paragraph")); occurrence = int(item.get("occurrence", 1))
        except (TypeError, ValueError):
            unresolved.append("存在段落索引或出现序号无效的手工角标映射。")
            continue
        marker = str(item.get("marker_text", "")).strip()
        if not marker:
            unresolved.append(f"段落{pidx}的手工角标文本为空。")
            continue
        text = str(item.get("footnote_text", "")).strip()
        ref_idx = item.get("reference_paragraph")
        if not text and ref_idx is not None:
            try:
                rp = _paragraph_by_original_index(doc_root, int(ref_idx))
            except (TypeError, ValueError):
                rp = None
            if rp is not None:
                text = _strip_reference_prefix(paragraph_text(rp))
        if not text:
            unresolved.append(f"段落{pidx}的角标“{marker}”没有可用的脚注出处文字，未转换。")
            continue
        para = _paragraph_by_original_index(doc_root, pidx)
        if para is None:
            unresolved.append(f"找不到原段落{pidx}，角标“{marker}”未转换。")
            continue
        fid = str(next_id)
        if not _replace_simple_marker_with_footnote(para, marker, occurrence, fid, body_marker_hp):
            unresolved.append(f"段落{pidx}的角标“{marker}”位于复杂文本结构中，未自动转换。")
            continue
        _append_footnote(fn_root, fid, text, bottom_marker_hp, footnote_text_hp)
        confidence = str(item.get("confidence", "medium")).lower()
        detail = {"paragraph": pidx, "marker": marker, "footnote_id": fid, "reference_paragraph": ref_idx, "confidence": confidence}
        details.append(detail)
        if confidence not in {"high", "certain"}:
            warnings.append(f"段落{pidx}的角标“{marker}”已按候选出处转换为真实脚注，但匹配置信度为{confidence}，需人工复核。")
        created += 1; next_id += 1
    save_xml(doc_tree, doc_path); save_xml(fn_tree, unz / "word" / "footnotes.xml")
    report["manual_citation_conversions"] = {"created": created, "unresolved": unresolved, "warnings": warnings, "details": details}


def patch_footnotes(unz: Path, options: dict[str, Any], report: dict[str, Any]) -> None:
    doc_path = unz / "word" / "document.xml"
    fn_path = unz / "word" / "footnotes.xml"
    if not fn_path.exists() or not doc_path.exists():
        report["footnotes"] = {"true_footnotes": 0, "crossrefs_created": 0}
        return
    doc_tree = load_xml(doc_path); root = doc_tree.getroot()
    fn_tree = load_xml(fn_path); fn_root = fn_tree.getroot()
    notes: dict[str, str] = {}
    note_nodes: dict[str, etree._Element] = {}
    bottom_marker_hp = str(int(round(float(options.get("footnote_marker_size_pt", 10.5)) * 2)))
    footnote_text_hp = str(int(round(float(options.get("footnote_text_size_pt", 9.0)) * 2)))
    body_marker_hp = str(int(round(float(options.get("body_footnote_reference_size_pt", 9.0)) * 2)))
    for fn in fn_root.xpath("./w:footnote", namespaces=NS):
        fid = fn.get(wq("id"))
        if fid == "-1":
            fn.set(wq("type"), "separator")
            continue
        if fid == "0":
            fn.set(wq("type"), "continuationSeparator")
            continue
        if fid is None:
            continue
        text = "".join(fn.xpath(".//w:t/text()", namespaces=NS))
        notes[fid] = text; note_nodes[fid] = fn
        for p in fn.xpath(".//w:p", namespaces=NS):
            ppr = p.find("w:pPr", namespaces=NS)
            if ppr is None: ppr = etree.Element(wq("pPr")); p.insert(0, ppr)
            pstyle = ppr.find("w:pStyle", namespaces=NS)
            if pstyle is None:
                pstyle = etree.Element(wq("pStyle")); ppr.insert(0, pstyle)
            pstyle.set(wq("val"), "FootnoteText")
            spacing = ensure_child(ppr, "spacing"); spacing.set(wq("line"), "240"); spacing.set(wq("lineRule"), "auto")
        for r in fn.xpath(".//w:r", namespaces=NS):
            is_marker = r.find("w:footnoteRef", namespaces=NS) is not None
            set_rpr_font(r, size_half_points=bottom_marker_hp if is_marker else footnote_text_hp, superscript=is_marker)
            for t in r.findall(".//w:t", namespaces=NS):
                if t.text and (t.text.startswith(" ") or t.text.endswith(" ")):
                    t.set(f"{{{XML_NS}}}space", "preserve")
    refs = root.xpath(".//w:footnoteReference", namespaces=NS)
    ref_records = []
    for ordinal, ref in enumerate(refs, start=1):
        r = ref.getparent(); p = r.getparent() if r is not None else None
        fid = ref.get(wq("id"))
        if r is None or p is None or fid is None: continue
        set_rpr_font(r, size_half_points="18", superscript=True)
        ref_records.append({"ordinal": ordinal, "id": fid, "r": r, "p": p, "text": notes.get(fid, "")})
    crossrefs = 0
    unresolved = []
    if options.get("deduplicate_identical_footnotes", True):
        groups: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for rec in ref_records:
            node = note_nodes.get(rec["id"])
            fp = footnote_fingerprint(node) if node is not None else None
            if fp:
                groups[fp].append(rec)
        max_bm_id = 0
        for bm in root.xpath(".//w:bookmarkStart|.//w:bookmarkEnd", namespaces=NS):
            val = bm.get(wq("id"))
            if val and val.isdigit(): max_bm_id = max(max_bm_id, int(val))
        removed_ids: set[str] = set()
        for _, group in groups.items():
            if len(group) < 2: continue
            first = group[0]
            max_bm_id += 1
            bm_name = f"_PaperFootnote{first['ordinal']}"
            r = first["r"]; p = first["p"]; pos = p.index(r)
            bs = etree.Element(wq("bookmarkStart")); bs.set(wq("id"), str(max_bm_id)); bs.set(wq("name"), bm_name)
            be = etree.Element(wq("bookmarkEnd")); be.set(wq("id"), str(max_bm_id))
            p.insert(pos, bs); p.insert(pos + 2, be)
            for dup in group[1:]:
                r2 = dup["r"]; p2 = dup["p"]; pos2 = p2.index(r2)
                rpr = r2.find("w:rPr", namespaces=NS)
                p2.remove(r2)
                cached_mark = footnote_result_text(first["ordinal"], options.get("footnote_number_format", "decimalEnclosedCircle"))
                for j, nr in enumerate(field_runs("NOTEREF", bm_name, cached_mark, rpr, superscript=True, superscript_size_half_points=body_marker_hp)):
                    p2.insert(pos2 + j, nr)
                removed_ids.add(dup["id"]); crossrefs += 1
        for fid in removed_ids:
            node = note_nodes.get(fid)
            if node is not None and node.getparent() is not None:
                node.getparent().remove(node)
    # Footnote numbering settings in every section.
    for sect in root.xpath(".//w:sectPr", namespaces=NS):
        fnpr = sect.find("w:footnotePr", namespaces=NS)
        if fnpr is None:
            fnpr = etree.Element(wq("footnotePr")); sect.insert(0, fnpr)
        numfmt = fnpr.find("w:numFmt", namespaces=NS)
        if numfmt is None: numfmt = etree.SubElement(fnpr, wq("numFmt"))
        numfmt.set(wq("val"), options.get("footnote_number_format", "decimalEnclosedCircle"))
        restart = fnpr.find("w:numRestart", namespaces=NS)
        if restart is None: restart = etree.SubElement(fnpr, wq("numRestart"))
        restart.set(wq("val"), options.get("footnote_numbering", "continuous"))
    materialize_noteref_results(root, options.get("footnote_number_format", "decimalEnclosedCircle"))
    save_xml(doc_tree, doc_path); save_xml(fn_tree, fn_path)
    report["footnotes"] = {"true_footnotes": len(ref_records), "crossrefs_created": crossrefs, "unresolved": unresolved}


def paragraph_text(p: etree._Element) -> str:
    return "".join(p.xpath(".//w:t/text()", namespaces=NS))


def paragraph_text_for_integrity(p: etree._Element) -> str:
    """Return visible paragraph text while ignoring generated NOTEREF marks.

    python-docx omits true footnote markers from ``Paragraph.text``. After an
    identical repeated footnote is replaced by a NOTEREF field, however, the
    cached circled-number result is stored as ordinary ``w:t`` text. Excluding
    only NOTEREF result text keeps the before/after integrity comparison fair
    while preserving visible REF/SEQ results that existed in the source text.
    """
    pieces: list[str] = []
    in_field = False
    separated = False
    instr = ""
    field_type = ""
    for r in p.xpath(".//w:r", namespaces=NS):
        fld = r.find("w:fldChar", namespaces=NS)
        if fld is not None:
            typ = fld.get(wq("fldCharType"))
            if typ == "begin":
                in_field = True
                separated = False
                instr = ""
                field_type = ""
                continue
            if in_field and typ == "separate":
                separated = True
                m = re.search(r"\b([A-Z]+)\b", " ".join(instr.split()).upper())
                field_type = m.group(1) if m else ""
                continue
            if in_field and typ == "end":
                in_field = False
                separated = False
                instr = ""
                field_type = ""
                continue
        ins = r.find("w:instrText", namespaces=NS)
        if in_field and ins is not None and not separated:
            instr += ins.text or ""
            continue
        texts = r.xpath(".//w:t/text()", namespaces=NS)
        if not texts:
            continue
        if in_field:
            if not separated or field_type == "NOTEREF":
                continue
        pieces.extend(texts)
    return "".join(pieces)


def max_bookmark_id(root: etree._Element) -> int:
    vals = []
    for x in root.xpath(".//w:bookmarkStart|.//w:bookmarkEnd", namespaces=NS):
        v = x.get(wq("id"))
        if v and v.isdigit(): vals.append(int(v))
    return max(vals, default=0)


def create_seq_runs(seq_name: str, result: str, rpr: etree._Element | None) -> list[etree._Element]:
    runs = field_runs("SEQ", seq_name, result, rpr, superscript=False)
    # SEQ has no hyperlink switch; remove it from instr text.
    for ins in [r.find("w:instrText", namespaces=NS) for r in runs]:
        if ins is not None: ins.text = f" SEQ {seq_name} \\* ARABIC "
    return runs


def _plain_run_text(r: etree._Element) -> str | None:
    if r.xpath("./w:drawing|./w:object|./w:br|./w:tab|./w:fldChar|./w:instrText", namespaces=NS):
        return None
    return "".join(r.xpath("./w:t/text()", namespaces=NS))


def _paragraph_run_ranges(p: etree._Element) -> tuple[str, list[tuple[int, int, etree._Element, str]]]:
    ranges: list[tuple[int, int, etree._Element, str]] = []
    full = ""; offset = 0
    for r in p.xpath("./w:r", namespaces=NS):
        text = _plain_run_text(r)
        if text is None:
            if run_visible_text(r):
                return "", []
            continue
        start = offset; offset += len(text); full += text
        ranges.append((start, offset, r, text))
    return full, ranges


def _replace_paragraph_span(p: etree._Element, start: int, end: int, new_nodes: list[etree._Element]) -> bool:
    full, ranges = _paragraph_run_ranges(p)
    if not ranges or start < 0 or end > len(full) or start >= end:
        return False
    involved = [item for item in ranges if item[0] < end and item[1] > start]
    if not involved:
        return False
    parent = involved[0][2].getparent()
    if any(item[2].getparent() is not parent for item in involved):
        return False
    first_start, _, first_run, first_text = involved[0]
    last_start, _, last_run, last_text = involved[-1]
    prefix = first_text[:max(0, start - first_start)]
    suffix = last_text[max(0, end - last_start):]
    insert_pos = parent.index(first_run)
    first_rpr = first_run.find("w:rPr", namespaces=NS)
    last_rpr = last_run.find("w:rPr", namespaces=NS)
    for _, _, run, _ in involved:
        parent.remove(run)
    inserts: list[etree._Element] = []
    if prefix:
        r = etree.Element(wq("r"));
        if first_rpr is not None: r.append(deepcopy(first_rpr))
        t = etree.SubElement(r, wq("t")); t.text = prefix; inserts.append(r)
    inserts.extend(new_nodes)
    if suffix:
        r = etree.Element(wq("r"));
        if last_rpr is not None: r.append(deepcopy(last_rpr))
        t = etree.SubElement(r, wq("t")); t.text = suffix; inserts.append(r)
    for i, node in enumerate(inserts):
        parent.insert(insert_pos + i, node)
    return True


def replace_number_in_caption(p: etree._Element, label: str, old_num: str, seq_name: str, new_num: str, bm_name: str, bm_id: int) -> bool:
    full, ranges = _paragraph_run_ranges(p)
    if not ranges:
        return False
    m = re.match(rf"^{re.escape(label)}\s*({re.escape(old_num)})(?![\d.．])", full)
    if not m:
        return False
    start, end = m.start(1), m.end(1)
    rpr = None
    for a, b, r, _ in ranges:
        if a <= start < b:
            rpr = r.find("w:rPr", namespaces=NS); break
    bs = etree.Element(wq("bookmarkStart")); bs.set(wq("id"), str(bm_id)); bs.set(wq("name"), bm_name)
    be = etree.Element(wq("bookmarkEnd")); be.set(wq("id"), str(bm_id))
    return _replace_paragraph_span(p, start, end, [bs, *create_seq_runs(seq_name, new_num, rpr), be])

def replace_ref_spans_in_paragraph(p: etree._Element, replacements: list[tuple[int, int, str, str]]) -> int:
    count = 0
    for start, end, bookmark, result in sorted(replacements, key=lambda x: x[0], reverse=True):
        full, ranges = _paragraph_run_ranges(p)
        if not ranges or end > len(full):
            continue
        rpr = None
        for a, b, r, _ in ranges:
            if a <= start < b:
                rpr = r.find("w:rPr", namespaces=NS); break
        if _replace_paragraph_span(p, start, end, field_runs("REF", bookmark, result, rpr, superscript=False)):
            count += 1
    return count

def _unique_bookmark_name(base: str, existing: set[str]) -> str:
    name = base[:40]
    if name not in existing:
        existing.add(name); return name
    i = 2
    while True:
        suffix = f"_{i}"
        candidate = (base[:40-len(suffix)] + suffix)
        if candidate not in existing:
            existing.add(candidate); return candidate
        i += 1


def patch_caption_crossrefs(unz: Path, roles: dict[int, str], options: dict[str, Any], report: dict[str, Any]) -> None:
    if not options.get("convert_caption_crossrefs", True):
        report["caption_crossrefs"] = {"captions_converted": 0, "references_converted": 0, "unresolved": []}
        return
    path = unz / "word" / "document.xml"
    tree = load_xml(path); root = tree.getroot(); body = root.find("w:body", namespaces=NS)
    if body is None:
        report["caption_crossrefs"] = {"captions_converted": 0, "references_converted": 0, "unresolved": ["文档正文缺失。"]}; return
    top_paras = body.findall("w:p", namespaces=NS)
    bm_id = max_bookmark_id(root)
    existing_names = {x.get(wq("name")) or "" for x in root.xpath(".//w:bookmarkStart", namespaces=NS)}
    mappings: dict[tuple[str, str], tuple[str, str]] = {}
    captions_converted = 0; unresolved: list[str] = []; counters = {"图": 0, "表": 0}
    for idx, p in enumerate(top_paras):
        role = role_from_bookmarks(p, roles.get(idx, "body"))
        if role not in {"figure_caption", "table_caption"}:
            continue
        label = "图" if role == "figure_caption" else "表"
        text = paragraph_text(p).strip()
        if p.xpath(f".//w:instrText[contains(text(),'SEQ Paper{'Figure' if label == '图' else 'Table'}')]", namespaces=NS):
            continue
        m = re.match(rf"^{label}\s*(\d+(?:[.．]\d+)*)", text)
        if not m:
            unresolved.append(f"段落{idx}的{label}题无法识别编号：{text[:50]}"); continue
        old = m.group(1)
        if "." in old or "．" in old:
            unresolved.append(f"段落{idx}使用章节式编号{label}{old}，为避免改变编号逻辑未自动转换SEQ。")
            continue
        counters[label] += 1; new = str(counters[label]); bm_id += 1
        base = f"_Paper{'Fig' if label == '图' else 'Tbl'}{new}"
        bm = _unique_bookmark_name(base, existing_names)
        if replace_number_in_caption(p, label, old, "PaperFigure" if label == "图" else "PaperTable", new, bm, bm_id):
            if (label, old) in mappings:
                unresolved.append(f"存在重复{label}号{old}，正文引用未自动判别全部目标。")
            else:
                mappings[(label, old)] = (bm, new)
            captions_converted += 1
        else:
            unresolved.append(f"段落{idx}的题注包含复杂域或容器，未自动转换：{text[:50]}")
    refs_converted = 0
    allowed_roles = {"body", "heading1", "heading2", "heading3", "heading4", "abstract", "keywords"}
    ordered_mappings = sorted(mappings.items(), key=lambda item: len(item[0][1]), reverse=True)
    for idx, p in enumerate(top_paras):
        role = role_from_bookmarks(p, roles.get(idx, "body"))
        if role not in allowed_roles or p.xpath(".//w:instrText[contains(text(),'REF ')]", namespaces=NS):
            continue
        full, ranges = _paragraph_run_ranges(p)
        if not ranges:
            continue
        spans: list[tuple[int, int, str, str]] = []
        for (label, old), (bm, new) in ordered_mappings:
            pat = re.compile(rf"{label}\s*(?P<num>{re.escape(old)})(?![\d.．])")
            for m in pat.finditer(full):
                spans.append((m.start("num"), m.end("num"), bm, new))
        spans.sort(key=lambda x: (x[0], -(x[1]-x[0])))
        clean: list[tuple[int, int, str, str]] = []
        for span in spans:
            if not clean or span[0] >= clean[-1][1]:
                clean.append(span)
        refs_converted += replace_ref_spans_in_paragraph(p, clean)
    save_xml(tree, path)
    report["caption_crossrefs"] = {"captions_converted": captions_converted, "references_converted": refs_converted, "unresolved": unresolved}

def reposition_figures_and_tables(unz: Path, report: dict[str, Any]) -> None:
    path = unz / "word" / "document.xml"
    tree = load_xml(path); root = tree.getroot()
    body = root.find("w:body", namespaces=NS)
    if body is None:
        report["objects_repositioned"] = 0
        return
    moved = 0
    # Repeat because moving changes sibling positions.
    changed = True
    while changed:
        changed = False
        children = list(body)
        for i, el in enumerate(children):
            if el.tag != wq("p"):
                continue
            text = paragraph_text(el).strip()
            is_fig_caption = bool(re.match(r"^图\s*\d+", text) or el.xpath(".//w:instrText[contains(text(),'SEQ PaperFigure')]", namespaces=NS))
            is_tbl_caption = bool(re.match(r"^表\s*\d+", text) or el.xpath(".//w:instrText[contains(text(),'SEQ PaperTable')]", namespaces=NS))
            if is_fig_caption and i + 1 < len(children):
                nxt = children[i + 1]
                if nxt.tag == wq("p") and nxt.xpath(".//w:drawing|.//w:pict", namespaces=NS):
                    body.remove(el)
                    pos = list(body).index(nxt)
                    body.insert(pos + 1, el)
                    moved += 1; changed = True; break
            if is_tbl_caption and i > 0:
                prev = children[i - 1]
                if prev.tag == wq("tbl"):
                    body.remove(el)
                    pos = list(body).index(prev)
                    body.insert(pos, el)
                    moved += 1; changed = True; break
    save_xml(tree, path)
    report["objects_repositioned"] = moved



def patch_footnote_reference_links(unz: Path, options: dict[str, Any], report: dict[str, Any]) -> None:
    """Create invisible-text-change internal hyperlinks from footnotes to bibliography.

    The model must provide a reviewed mapping in plan.json:
    reference_links: [{"footnote_id": "3", "reference_paragraph": 42}]
    where reference_paragraph is the original top-level paragraph index. The
    target paragraph already carries the hidden _PaperOrig_<index> bookmark.
    """
    mappings = options.get("reference_links", [])
    if not isinstance(mappings, list) or not mappings:
        report["footnote_reference_links"] = {"created": 0, "unresolved": []}
        return
    doc_path = unz / "word" / "document.xml"; fn_path = unz / "word" / "footnotes.xml"
    if not doc_path.exists() or not fn_path.exists():
        report["footnote_reference_links"] = {"created": 0, "unresolved": ["正文或脚注XML缺失。"]}
        return
    doc_root = load_xml(doc_path).getroot()
    bookmarks = {x.get(wq("name")) for x in doc_root.xpath(".//w:bookmarkStart", namespaces=NS) if x.get(wq("name"))}
    ftree = load_xml(fn_path); froot = ftree.getroot()
    by_id = {fn.get(wq("id")): fn for fn in froot.xpath("./w:footnote", namespaces=NS)}
    created = 0; unresolved = []
    for item in mappings:
        if not isinstance(item, dict):
            continue
        fid = str(item.get("footnote_id", ""))
        try:
            ref_idx = int(item.get("reference_paragraph"))
        except (TypeError, ValueError):
            unresolved.append(f"脚注{fid or '?'}的参考文献段落索引无效。")
            continue
        target = f"_PaperOrig_{ref_idx}"
        fn = by_id.get(fid)
        if fn is None:
            unresolved.append(f"脚注ID {fid}不存在。")
            continue
        if target not in bookmarks:
            unresolved.append(f"脚注{fid}的目标书目书签{target}不存在。")
            continue
        if fn.xpath(f".//w:hyperlink[@w:anchor='{target}']", namespaces=NS):
            continue
        paragraphs = fn.findall("w:p", namespaces=NS)
        if not paragraphs:
            unresolved.append(f"脚注{fid}无可链接段落。")
            continue
        p = paragraphs[0]
        if p.xpath("./w:hyperlink|./w:fldSimple|.//w:fldChar|.//w:drawing|.//w:object", namespaces=NS):
            unresolved.append(f"脚注{fid}含复杂字段或对象，未自动建立书目链接。")
            continue
        runs = [r for r in p.findall("w:r", namespaces=NS) if r.find("w:footnoteRef", namespaces=NS) is None]
        if not runs:
            unresolved.append(f"脚注{fid}没有可见正文运行。")
            continue
        first_pos = p.index(runs[0])
        hyperlink = etree.Element(wq("hyperlink"))
        hyperlink.set(wq("anchor"), target)
        hyperlink.set(wq("history"), "1")
        for run in runs:
            # Keep the internal jump invisible in print/PDF: Word's default
            # Hyperlink style is blue and underlined unless direct formatting
            # overrides it. Preserve all existing note formatting while forcing
            # black text and no underline.
            rpr = run.find("w:rPr", namespaces=NS)
            if rpr is None:
                rpr = etree.Element(wq("rPr")); run.insert(0, rpr)
            color = rpr.find("w:color", namespaces=NS)
            if color is None:
                color = etree.SubElement(rpr, wq("color"))
            color.set(wq("val"), "000000")
            underline = rpr.find("w:u", namespaces=NS)
            if underline is None:
                underline = etree.SubElement(rpr, wq("u"))
            underline.set(wq("val"), "none")
            p.remove(run); hyperlink.append(run)
        p.insert(first_pos, hyperlink)
        created += 1
    save_xml(ftree, fn_path)
    report["footnote_reference_links"] = {"created": created, "unresolved": unresolved}

def _ensure_style_rpr(style_or_default: etree._Element, east: str, latin: str, size_half: str) -> None:
    rpr = style_or_default.find("w:rPr", namespaces=NS)
    if rpr is None:
        rpr = etree.SubElement(style_or_default, wq("rPr"))
    rfonts = rpr.find("w:rFonts", namespaces=NS)
    if rfonts is None:
        rfonts = etree.SubElement(rpr, wq("rFonts"))
    for attr, value in (("eastAsia", east), ("ascii", latin), ("hAnsi", latin), ("cs", latin)):
        rfonts.set(wq(attr), value)
    for tag in ("sz", "szCs"):
        el = rpr.find(f"w:{tag}", namespaces=NS)
        if el is None:
            el = etree.SubElement(rpr, wq(tag))
        el.set(wq("val"), size_half)
    lang = rpr.find("w:lang", namespaces=NS)
    if lang is None:
        lang = etree.SubElement(rpr, wq("lang"))
    lang.set(wq("val"), "en-US"); lang.set(wq("eastAsia"), "zh-CN")


def patch_styles_for_portability(unz: Path, report: dict[str, Any]) -> None:
    path = unz / "word" / "styles.xml"
    if not path.exists():
        report.setdefault("local_layout_stability", {})["styles_patched"] = False
        return
    tree = load_xml(path); root = tree.getroot()
    doc_defaults = root.find("w:docDefaults", namespaces=NS)
    if doc_defaults is None:
        doc_defaults = etree.Element(wq("docDefaults")); root.insert(0, doc_defaults)
    rpr_default = doc_defaults.find("w:rPrDefault", namespaces=NS)
    if rpr_default is None:
        rpr_default = etree.SubElement(doc_defaults, wq("rPrDefault"))
    _ensure_style_rpr(rpr_default, "宋体", "Times New Roman", "21")
    ppr_default = doc_defaults.find("w:pPrDefault", namespaces=NS)
    if ppr_default is None:
        ppr_default = etree.SubElement(doc_defaults, wq("pPrDefault"))
    ppr = ppr_default.find("w:pPr", namespaces=NS)
    if ppr is None:
        ppr = etree.SubElement(ppr_default, wq("pPr"))
    for tag, val in (("snapToGrid", "0"), ("contextualSpacing", "0"), ("adjustRightInd", "0")):
        el = ppr.find(f"w:{tag}", namespaces=NS)
        if el is None: el = etree.SubElement(ppr, wq(tag))
        el.set(wq("val"), val)

    styles = {
        "Normal": ("宋体", "Times New Roman", "21"),
        "DefaultParagraphFont": ("宋体", "Times New Roman", "21"),
        "FootnoteText": ("宋体", "Times New Roman", "18"),
        "FootnoteReference": ("宋体", "Times New Roman", "18"),
    }
    patched = 0
    for style_id, spec in styles.items():
        style = root.find(f"w:style[@w:styleId='{style_id}']", namespaces=NS)
        if style is None:
            continue
        _ensure_style_rpr(style, *spec); patched += 1
        if style_id == "FootnoteReference":
            rpr = style.find("w:rPr", namespaces=NS)
            va = rpr.find("w:vertAlign", namespaces=NS)
            if va is None: va = etree.SubElement(rpr, wq("vertAlign"))
            va.set(wq("val"), "superscript")
    save_xml(tree, path)
    report.setdefault("local_layout_stability", {}).update({"styles_patched": True, "named_styles_patched": patched, "default_east_asia_font": "宋体", "default_latin_font": "Times New Roman"})


def patch_settings(unz: Path, options: dict[str, Any], report: dict[str, Any]) -> None:
    path = unz / "word" / "settings.xml"
    if not path.exists(): return
    tree = load_xml(path); root = tree.getroot()
    footnote_pr = root.find("w:footnotePr", namespaces=NS)
    if footnote_pr is None:
        footnote_pr = etree.SubElement(root, wq("footnotePr"))
    existing_ids = {x.get(wq("id")) for x in footnote_pr.findall("w:footnote", namespaces=NS)}
    for fid in ("-1", "0"):
        if fid not in existing_ids:
            el = etree.SubElement(footnote_pr, wq("footnote")); el.set(wq("id"), fid)
    update_on_open = bool(options.get("update_fields_on_open", False))
    update = root.find("w:updateFields", namespaces=NS)
    if update is None: update = etree.SubElement(root, wq("updateFields"))
    update.set(wq("val"), "true" if update_on_open else "false")

    compat = root.find("w:compat", namespaces=NS)
    if compat is None: compat = etree.SubElement(root, wq("compat"))
    target = None
    for item in compat.findall("w:compatSetting", namespaces=NS):
        if item.get(wq("name")) == "compatibilityMode": target = item; break
    if target is None: target = etree.SubElement(compat, wq("compatSetting"))
    target.set(wq("name"), "compatibilityMode")
    target.set(wq("uri"), "http://schemas.microsoft.com/office/word")
    target.set(wq("val"), "15")

    char_spacing = root.find("w:characterSpacingControl", namespaces=NS)
    if char_spacing is None: char_spacing = etree.SubElement(root, wq("characterSpacingControl"))
    char_spacing.set(wq("val"), "doNotCompress")
    theme_lang = root.find("w:themeFontLang", namespaces=NS)
    if theme_lang is None: theme_lang = etree.SubElement(root, wq("themeFontLang"))
    theme_lang.set(wq("val"), "en-US"); theme_lang.set(wq("eastAsia"), "zh-CN")
    save_xml(tree, path)
    report.setdefault("local_layout_stability", {}).update({"compatibility_mode": 15, "update_fields_on_open": update_on_open, "character_spacing_control": "doNotCompress"})


def audit_manual_citations(unz: Path, roles: dict[int, str]) -> dict[str, Any]:
    """Audit citation-like markers that are not reliable Word note fields.

    This function deliberately reports rather than converts ambiguous markers.
    It distinguishes true footnote references from hand-typed brackets, circled
    numbers, superscript digits, and author-year citations.
    """
    path = unz / "word" / "document.xml"
    tree = load_xml(path); root = tree.getroot()
    body = root.find("w:body", namespaces=NS)
    empty = {
        "manual_bracket_citations": 0,
        "visible_circled_numbers": 0,
        "manual_superscript_citations": 0,
        "author_year_citations": 0,
        "manual_formula_references": 0,
    }
    if body is None:
        return empty
    paras = body.findall("w:p", namespaces=NS)
    allowed = {"body", "abstract", "keywords", "heading1", "heading2", "heading3", "heading4"}
    selected_paras = [p for idx, p in enumerate(paras) if role_from_bookmarks(p, roles.get(idx, "body")) in allowed]
    text = "\n".join(paragraph_text(p) for p in selected_paras)
    bracket = re.findall(r"\[(?:\d+(?:\s*[-–—,，]\s*\d+)*)\]", text)
    circled = re.findall(r"[①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳]", text)
    formula_refs = re.findall(r"式\s*[（(]\d+[）)]", text)
    author_year = []
    author_year += re.findall(r"[（(][^（）()\n]{1,45}[,，]\s*(?:19|20)\d{2}[a-z]?[）)]", text)
    author_year += re.findall(r"(?:[\u4e00-\u9fff·]{2,12}|[A-Z][A-Za-z-]+)\s*[（(](?:19|20)\d{2}[a-z]?[）)]", text)

    superscript = 0
    for p in selected_paras:
        for r in p.xpath(".//w:r", namespaces=NS):
            if r.find("w:footnoteReference", namespaces=NS) is not None:
                continue
            if r.find("w:fldChar", namespaces=NS) is not None or r.find("w:instrText", namespaces=NS) is not None:
                continue
            va = r.find("w:rPr/w:vertAlign", namespaces=NS)
            if va is None or va.get(wq("val")) != "superscript":
                continue
            rtext = "".join(r.xpath(".//w:t/text()", namespaces=NS)).strip()
            if re.fullmatch(r"(?:\d+|[①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳])", rtext):
                superscript += 1

    return {
        "manual_bracket_citations": len(bracket),
        "visible_circled_numbers": len(circled),
        "manual_superscript_citations": superscript,
        "author_year_citations": len(author_year),
        "manual_formula_references": len(formula_refs),
    }



def canonical_visible_text(text: str, role: str) -> str:
    text = text.replace("“", '"').replace("”", '"')
    text = re.sub(r"\s+", " ", text).strip()
    if role in {"heading1", "heading2", "heading3", "heading4"}:
        for _ in range(8):
            updated = PREFIX_RE.sub("", text, count=1).strip()
            if updated == text:
                break
            text = updated
    if role in {"figure_caption", "table_caption"}:
        text = re.sub(r"^(图|表)\s*[A-Za-z]?\d+(?:[.．]\d+)*", r"\1#", text)
    return text


def package_structure_counts(unz: Path) -> dict[str, int]:
    result = {"tables": 0, "drawings": 0, "formulas": 0, "hyperlinks": 0, "comments": 0, "insertions": 0, "deletions": 0}
    doc_path = unz / "word" / "document.xml"
    if doc_path.exists():
        root = load_xml(doc_path).getroot()
        result.update({
            "tables": len(root.xpath(".//w:tbl", namespaces=NS)),
            "drawings": len(root.xpath(".//w:drawing|.//w:pict", namespaces=NS)),
            "formulas": len(root.xpath(".//m:oMath|.//m:oMathPara", namespaces={**NS, "m": "http://schemas.openxmlformats.org/officeDocument/2006/math"})),
            "hyperlinks": len(root.xpath(".//w:hyperlink", namespaces=NS)),
            "insertions": len(root.xpath(".//w:ins", namespaces=NS)),
            "deletions": len(root.xpath(".//w:del", namespaces=NS)),
        })
    comments = unz / "word" / "comments.xml"
    if comments.exists():
        result["comments"] = len(load_xml(comments).getroot().xpath(".//w:comment", namespaces=NS))
    return result


def snapshot_document(doc: Document, roles: dict[int, str]) -> dict[str, Any]:
    """Snapshot visible content from OOXML, including hyperlinks and controls.

    ``python-docx``'s ``Paragraph.text`` can omit text inside hyperlinks,
    content controls, and some nested containers.  The integrity baseline must
    therefore be built from the serialized OOXML that will actually be edited.
    """
    with tempfile.TemporaryDirectory(prefix="papersnap_") as td:
        temp_docx = Path(td) / "snapshot.docx"
        doc.save(temp_docx)
        unz = Path(td) / "unz"
        unzip_docx(temp_docx, unz)
        doc_root = load_xml(unz / "word" / "document.xml").getroot()
        body = doc_root.find("w:body", namespaces=NS)
        top_paras = body.findall("w:p", namespaces=NS) if body is not None else []
        para_text = {idx: paragraph_text_for_integrity(p) for idx, p in enumerate(top_paras)}
        table_text = []
        if body is not None:
            for tbl in body.findall("w:tbl", namespaces=NS):
                for tr in tbl.findall("w:tr", namespaces=NS):
                    row = []
                    for tc in tr.findall("w:tc", namespaces=NS):
                        row.append(["".join(tc.xpath(".//w:p//w:t/text()", namespaces=NS))])
                    table_text.append(row)
        counts = package_structure_counts(unz)
    return {"paragraphs": para_text, "roles": dict(roles), "table_text": table_text, "structure": counts}


def snapshot_input_docx(path: Path, roles: dict[int, str]) -> dict[str, Any]:
    return snapshot_document(Document(path), roles)


def verify_content_integrity(unz: Path, snapshot: dict[str, Any], report: dict[str, Any]) -> None:
    path = unz / "word" / "document.xml"
    root = load_xml(path).getroot(); body = root.find("w:body", namespaces=NS)
    final_by_orig: dict[int, str] = {}
    if body is not None:
        for p in body.findall("w:p", namespaces=NS):
            idx = original_index_from_bookmark(p)
            if idx is not None:
                final_by_orig[idx] = paragraph_text_for_integrity(p)
    mismatches = []
    for idx, original in snapshot["paragraphs"].items():
        role = snapshot["roles"].get(idx, "body")
        final = final_by_orig.get(idx)
        if final is None:
            mismatches.append(f"原段落{idx}在输出中缺失。")
            continue
        adjusted_original = original
        conversions = [x for x in snapshot.get("manual_citation_conversions", []) if isinstance(x, dict) and str(x.get("paragraph")) == str(idx)]
        by_marker: dict[str, list[int]] = defaultdict(list)
        for item in conversions:
            marker = str(item.get("marker_text", ""))
            try:
                occ = int(item.get("occurrence", 1))
            except (TypeError, ValueError):
                occ = 1
            if marker:
                by_marker[marker].append(occ)
        for marker, occs in by_marker.items():
            positions = [m.span() for m in re.finditer(re.escape(marker), adjusted_original)]
            remove = {o - 1 for o in occs if o > 0}
            if positions and remove:
                pieces = []
                last = 0
                for j, (a, b) in enumerate(positions):
                    pieces.append(adjusted_original[last:a])
                    if j not in remove:
                        pieces.append(adjusted_original[a:b])
                    last = b
                pieces.append(adjusted_original[last:])
                adjusted_original = "".join(pieces)
        if canonical_visible_text(adjusted_original, role) != canonical_visible_text(final, role):
            mismatches.append(f"原段落{idx}可见文字发生非允许变化。")
    final_doc = Document(unz / ".." / "placeholder.docx") if False else None
    # Compare table cell text directly from OOXML because formatting must never alter it.
    final_tables = []
    if body is not None:
        for tbl in body.findall("w:tbl", namespaces=NS):
            for tr in tbl.findall("w:tr", namespaces=NS):
                final_tables.append([["".join(tc.xpath(".//w:p//w:t/text()", namespaces=NS))] for tc in tr.findall("w:tc", namespaces=NS)])
    # Flatten both representations to robust cell strings.
    original_cells = [canonical_visible_text("\n".join(cell), "body") for row in snapshot["table_text"] for cell in row]
    final_cells = [canonical_visible_text(cell[0], "body") for row in final_tables for cell in row]
    if original_cells != final_cells:
        mismatches.append("表格单元格可见文字或顺序发生变化。")
    final_counts = package_structure_counts(unz)
    structure_mismatches = []
    for key in ("tables", "drawings", "formulas", "hyperlinks", "comments", "insertions", "deletions"):
        if snapshot["structure"].get(key, 0) != final_counts.get(key, 0):
            structure_mismatches.append(f"{key}: {snapshot['structure'].get(key,0)}→{final_counts.get(key,0)}")
    report["content_integrity"] = {"passed": not mismatches and not structure_mismatches, "text_mismatches": mismatches, "structure_mismatches": structure_mismatches}
    if mismatches or structure_mismatches:
        raise RuntimeError("内容完整性检查失败：" + "；".join((mismatches + structure_mismatches)[:8]))


def validate_cross_reference_fields(unz: Path, report: dict[str, Any]) -> None:
    path = unz / "word" / "document.xml"
    root = load_xml(path).getroot()
    bookmarks = {x.get(wq("name")) for x in root.xpath(".//w:bookmarkStart", namespaces=NS) if x.get(wq("name"))}
    broken = []
    field_counts = Counter()
    for instr in root.xpath(".//w:instrText/text()", namespaces=NS):
        clean = " ".join(instr.split())
        m = re.search(r"\b(REF|NOTEREF|SEQ)\s+([A-Za-z0-9_:\-.]+)", clean, re.I)
        if not m:
            continue
        typ, target = m.group(1).upper(), m.group(2)
        field_counts[typ] += 1
        if typ in {"REF", "NOTEREF"} and target not in bookmarks:
            broken.append(f"{typ}→{target}")
    visible_errors = []
    for t in root.xpath(".//w:t/text()", namespaces=NS):
        if "错误！未找到引用源" in t or "Error! Reference source not found" in t:
            visible_errors.append(t)
    report["field_validation"] = {"counts": dict(field_counts), "broken_targets": broken, "visible_errors": visible_errors, "passed": not broken and not visible_errors}
    if broken or visible_errors:
        raise RuntimeError("交叉引用字段校验失败。")


def audit_reference_entries(unz: Path, roles: dict[int, str]) -> dict[str, Any]:
    root = load_xml(unz / "word" / "document.xml").getroot(); body = root.find("w:body", namespaces=NS)
    issues = []; count = 0; seen = set(); duplicates = 0
    if body is None:
        return {"count": 0, "issues": [], "duplicates": 0}
    for idx, p in enumerate(body.findall("w:p", namespaces=NS)):
        role = role_from_bookmarks(p, roles.get(idx, "body"))
        if role != "reference_item":
            continue
        text = paragraph_text(p).strip(); count += 1
        key = re.sub(r"\s+", "", text)
        if key in seen: duplicates += 1
        seen.add(key)
        local = []
        if not re.search(r"(?:19|20)\d{2}", text): local.append("未检出年份")
        if not re.search(r"\[[A-Z]+(?:/[A-Z]+)?\]", text): local.append("未检出文献类型标识")
        if re.search(r"https?://", text) and not re.search(r"\[(?:19|20)\d{2}-\d{2}-\d{2}\]", text): local.append("网络文献未检出引用日期")
        if local: issues.append(f"参考文献段落{idx}：" + "、".join(local))
    return {"count": count, "issues": issues, "duplicates": duplicates}

def write_report(path: Path, report: dict[str, Any]) -> None:
    """Write a concise user-facing report instead of an internal debug log."""
    completion = report.get("content_completion", {})
    inserted = completion.get("inserted", []) if isinstance(completion, dict) else []
    refs = report.get("reference_audit", {}) if isinstance(report.get("reference_audit", {}), dict) else {}
    fq = report.get("final_quality", {}) if isinstance(report.get("final_quality", {}), dict) else {}
    integrity = report.get("content_integrity", {}) if isinstance(report.get("content_integrity", {}), dict) else {}
    fields = report.get("field_validation", {}) if isinstance(report.get("field_validation", {}), dict) else {}

    unresolved: list[str] = []
    for section, key in (("caption_crossrefs", "unresolved"), ("footnotes", "unresolved"), ("manual_citation_conversions", "unresolved"), ("manual_citation_conversions", "warnings"), ("footnote_reference_links", "unresolved")):
        value = report.get(section, {})
        if isinstance(value, dict) and isinstance(value.get(key), list):
            unresolved.extend(str(x) for x in value.get(key, []) if str(x).strip())
    unresolved.extend(str(x) for x in fq.get("quote_warnings", []) if str(x).strip())
    unresolved.extend(str(x) for x in fq.get("wps_frontmatter_issues", []) if str(x).strip())
    unresolved.extend(str(x) for x in refs.get("issues", []) if str(x).strip())
    if refs.get("duplicates", 0):
        unresolved.append(f"参考文献存在{refs.get('duplicates', 0)}条疑似重复项。")
    if inserted:
        unresolved.append("请人工核对模型补全的摘要或关键词是否准确反映全文。")

    hard_ok = (
        report.get("status") == "passed"
        and integrity.get("passed", False)
        and fields.get("passed", False)
        and fq.get("remaining_font_mismatches", 0) == 0
        and fq.get("remaining_unprotected_ascii_double_quotes", 0) == 0
        and fq.get("quote_balance_errors", 0) == 0
        and not fq.get("wps_frontmatter_issues")
    )
    completion_label = "已全部完成" if hard_ok else ("已完成自动修改，但存在需人工处理的问题" if report.get("status") == "passed" else "未完成")
    ai_label = "无"
    if inserted:
        labels = ["中文摘要" if x.get("role") == "abstract" else "中文关键词" for x in inserted]
        ai_label = "、".join(dict.fromkeys(labels))
    manual_label = "无" if not unresolved else f"有，共{len(unresolved)}项"

    lines = [
        "# 论文排版结果",
        "",
        f"- 修改状态：**{completion_label}**",
        f"- AI生成内容：**{ai_label}**",
        f"- 后续手动处理：**{manual_label}**",
    ]
    if report.get("failure_reason"):
        lines += ["", "## 未完成原因", f"- {report['failure_reason']}"]
    if inserted:
        lines += ["", "## AI生成内容"]
        for item in inserted:
            label = "中文摘要" if item.get("role") == "abstract" else "中文关键词"
            lines.append(f"- 已生成并插入{label}。")
    if unresolved:
        lines += ["", "## 需要人工处理"] + [f"- {item}" for item in unresolved[:40]]
    else:
        lines += ["", "## 结论", "- 未发现需要继续手动修改的格式问题。"]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_docx", type=Path)
    ap.add_argument("output_docx", type=Path)
    ap.add_argument("--plan", type=Path)
    ap.add_argument("--report", type=Path, required=True)
    args = ap.parse_args()

    doc = Document(args.input_docx)
    roles, plan_options, insertions, table_configs = load_plan(args.plan, doc)
    roles, insertions, summary_layout = normalize_inline_summary_layout(doc, roles, insertions)
    original_roles = dict(roles)
    # Stabilize legacy WPS/Word layout tables used for title blocks before the
    # preservation snapshot, so the repair is treated as formatting only.
    frontmatter_tables_stabilized, nested_frontmatter_roles = stabilize_frontmatter_layout_tables(doc)
    # Normalize title/subtitle hidden tabs, manual breaks and inherited indents
    # before taking the preservation snapshot. This is an intentional layout
    # repair required for stable WPS display, not substantive text editing.
    frontmatter_normalized = 0
    for idx, paragraph in enumerate(doc.paragraphs):
        frontmatter_normalized += normalize_centered_frontmatter(paragraph, roles.get(idx, "body"))
    # Snapshot the normalized in-memory document so joining a standalone label
    # and WPS title cleanup are treated as intentional formatting operations.
    original_snapshot = snapshot_document(doc, original_roles)
    original_snapshot["manual_citation_conversions"] = list(plan_options.get("manual_citation_conversions", [])) if isinstance(plan_options.get("manual_citation_conversions", []), list) else []
    tag_original_paragraphs(doc)
    options = {
        "normalize_heading_numbers": True,
        "apply_three_line_tables": True,
        "convert_caption_crossrefs": True,
        "deduplicate_identical_footnotes": False,
        "citation_mode": "ruc_page_footnote",
        "convert_manual_superscripts": True,
        "footnote_numbering": "eachPage",
        "footnote_number_format": "decimalEnclosedCircle",
        "footnote_marker_size_pt": 10.5,
        "footnote_text_size_pt": 9.0,
        "body_footnote_reference_size_pt": 9.0,
        "add_centered_page_numbers": True,
        "page_setup_mode": "normalize_portrait_except_landscape",
        "update_fields_on_open": False,
        "ruc_header": {"enabled": False},
    }
    options.update(plan_options)
    style_overrides = options.get("style_overrides", {}) if isinstance(options.get("style_overrides", {}), dict) else {}
    roles, completion_report = insert_generated_sections(doc, roles, insertions)
    tag_paragraph_roles(doc, roles)
    tag_nested_frontmatter_roles(doc, nested_frontmatter_roles)
    page_stats = configure_page(doc, options)
    header_stats = configure_ruc_header(doc, options)
    heading_changed = normalize_headings(doc, roles) if options["normalize_heading_numbers"] else 0
    for idx, p in enumerate(doc.paragraphs):
        role = roles.get(idx, "body")
        apply_role(p, role, style_overrides)
        if p._p.xpath(".//w:drawing|.//w:pict"):
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_before = Pt(3); p.paragraph_format.space_after = Pt(3)
            p.paragraph_format.first_line_indent = None
            p.paragraph_format.line_spacing_rule = WD_LINE_SPACING.SINGLE
            p.paragraph_format.line_spacing = 1
    table_stats = format_tables(doc, table_configs, bool(options["apply_three_line_tables"]))
    pages_added = ensure_centered_page_numbers(doc) if options["add_centered_page_numbers"] else 0
    args.output_docx.parent.mkdir(parents=True, exist_ok=True)
    temp_base = args.output_docx.with_suffix(".base.docx")
    doc.save(temp_base)

    report: dict[str, Any] = {
        "input": str(args.input_docx), "output": str(args.output_docx),
        "roles": dict(Counter(roles.values())), "heading_prefixes_normalized": heading_changed,
        "tables_formatted": table_stats, "page_fields_added": pages_added, "page_setup": page_stats,
        "ruc_header": header_stats,
        "content_completion": completion_report,
        "summary_layout": summary_layout,
        "frontmatter_normalized_for_wps": frontmatter_normalized,
        "frontmatter_layout_tables_stabilized": frontmatter_tables_stabilized,
        "request_overrides": options.get("_request_overrides", {}),
        "template_requirements": options.get("_template_requirements", {}),
        "style_overrides": style_overrides,
    }
    try:
        with tempfile.TemporaryDirectory(prefix="paperfmt_") as td:
            unz = Path(td) / "unz"; unzip_docx(temp_base, unz)
            report["citation_audit"] = audit_manual_citations(unz, roles)
            convert_manual_citations_to_footnotes(unz, options, report)
            patch_footnotes(unz, options, report)
            patch_footnote_reference_links(unz, options, report)
            patch_caption_crossrefs(unz, roles, options, report)
            reposition_figures_and_tables(unz, report)
            final_quality_pass(unz, roles, table_configs, report, style_overrides, options)
            patch_styles_for_portability(unz, report)
            patch_settings(unz, options, report)
            report["reference_audit"] = audit_reference_entries(unz, roles)
            validate_cross_reference_fields(unz, report)
            verify_content_integrity(unz, original_snapshot, report)
            fq = report.get("final_quality", {})
            if fq.get("remaining_font_mismatches", 0) or fq.get("remaining_unprotected_ascii_double_quotes", 0) or fq.get("quote_balance_errors", 0) or fq.get("wps_frontmatter_issues"):
                raise RuntimeError("最终字体、引号或WPS题名区质量门禁未通过。")
            zip_docx(unz, args.output_docx)
    except Exception as exc:
        report["status"] = "failed"
        report["failure_reason"] = str(exc)
        args.output_docx.unlink(missing_ok=True)
        args.report.parent.mkdir(parents=True, exist_ok=True)
        write_report(args.report, report)
        temp_base.unlink(missing_ok=True)
        raise
    report["status"] = "passed"
    temp_base.unlink(missing_ok=True)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    write_report(args.report, report)
    print(f"[OK] formatted: {args.output_docx}")
    print(f"[OK] report: {args.report}")

if __name__ == "__main__":
    main()
