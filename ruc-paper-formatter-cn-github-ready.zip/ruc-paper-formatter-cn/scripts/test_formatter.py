#!/usr/bin/env python3
"""Regression smoke test for the academic-paper formatter."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

from docx import Document
from docx.shared import Inches
from lxml import etree

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}
HERE = Path(__file__).resolve().parent


def run(*args: str) -> None:
    proc = subprocess.run([sys.executable, *args], text=True, capture_output=True)
    if proc.returncode:
        raise RuntimeError(proc.stdout + "\n" + proc.stderr)


def make_png(path: Path) -> None:
    from PIL import Image
    Image.new("RGB", (8, 8), (255, 255, 255)).save(path)


def visible_xml(docx: Path):
    with zipfile.ZipFile(docx) as zf:
        return etree.fromstring(zf.read("word/document.xml"))



def inject_rogue_metrics(src: Path) -> None:
    """Inject Word run metrics that often cause local Word/WPS reflow."""
    with zipfile.ZipFile(src) as zin:
        files = {info.filename: zin.read(info.filename) for info in zin.infolist()}
    root = etree.fromstring(files["word/document.xml"])
    # Add legacy list/border/tab-leader properties to the title.  These are
    # common causes of WPS-only title drift and must be fully removed.
    title_p = root.xpath('./w:body/w:p[1]', namespaces=NS)[0]
    ppr = title_p.find('w:pPr', namespaces=NS)
    if ppr is None:
        ppr = etree.Element(f'{{{W}}}pPr'); title_p.insert(0, ppr)
    numpr = etree.SubElement(ppr, f'{{{W}}}numPr')
    ilvl = etree.SubElement(numpr, f'{{{W}}}ilvl'); ilvl.set(f'{{{W}}}val', '0')
    numid = etree.SubElement(numpr, f'{{{W}}}numId'); numid.set(f'{{{W}}}val', '1')
    pbdr = etree.SubElement(ppr, f'{{{W}}}pBdr')
    bottom = etree.SubElement(pbdr, f'{{{W}}}bottom'); bottom.set(f'{{{W}}}val', 'dotted'); bottom.set(f'{{{W}}}sz', '4')
    tabs = etree.SubElement(ppr, f'{{{W}}}tabs')
    tab = etree.SubElement(tabs, f'{{{W}}}tab'); tab.set(f'{{{W}}}val', 'right'); tab.set(f'{{{W}}}leader', 'dot'); tab.set(f'{{{W}}}pos', '8000')
    heading_p = root.xpath('.//w:p[.//w:t[contains(text(),"一、一、引言")]]', namespaces=NS)[0]
    hppr = heading_p.find('w:pPr', namespaces=NS)
    if hppr is None:
        hppr = etree.Element(f'{{{W}}}pPr'); heading_p.insert(0, hppr)
    hnumpr = etree.SubElement(hppr, f'{{{W}}}numPr')
    hilvl = etree.SubElement(hnumpr, f'{{{W}}}ilvl'); hilvl.set(f'{{{W}}}val', '0')
    hnumid = etree.SubElement(hnumpr, f'{{{W}}}numId'); hnumid.set(f'{{{W}}}val', '1')
    target = root.xpath('.//w:r[w:t[contains(text(),"研究者将")]]', namespaces=NS)[0]
    rpr = target.find('w:rPr', namespaces=NS)
    if rpr is None:
        rpr = etree.Element(f'{{{W}}}rPr'); target.insert(0, rpr)
    for tag, val in (("spacing", "24"), ("position", "4"), ("w", "130"), ("kern", "28")):
        el = etree.SubElement(rpr, f'{{{W}}}{tag}'); el.set(f'{{{W}}}val', val)
    # Wrap one quoted paragraph in a content control and another in an
    # internal hyperlink to verify quote replacement is not limited to plain runs.
    sdt_run = root.xpath('.//w:r[w:t[contains(text(),"内容控件中的")]]', namespaces=NS)[0]
    parent = sdt_run.getparent(); pos = parent.index(sdt_run); parent.remove(sdt_run)
    sdt = etree.Element(f'{{{W}}}sdt'); etree.SubElement(sdt, f'{{{W}}}sdtPr')
    content = etree.SubElement(sdt, f'{{{W}}}sdtContent'); content.append(sdt_run); parent.insert(pos, sdt)
    link_run = root.xpath('.//w:r[w:t[contains(text(),"超链接中的")]]', namespaces=NS)[0]
    parent = link_run.getparent(); pos = parent.index(link_run); parent.remove(link_run)
    link = etree.Element(f'{{{W}}}hyperlink'); link.set(f'{{{W}}}anchor', '_Top'); link.append(link_run); parent.insert(pos, link)
    files["word/document.xml"] = etree.tostring(root, xml_declaration=True, encoding="UTF-8", standalone="yes")
    with zipfile.ZipFile(src, 'w', zipfile.ZIP_DEFLATED) as zout:
        for name, data in files.items():
            zout.writestr(name, data)


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="paperfmt-test-") as td:
        d = Path(td); src = d / "input.docx"; png = d / "tiny.png"; make_png(png)
        doc = Document()
        title = doc.add_paragraph()
        title.paragraph_format.left_indent = Inches(1)
        title.paragraph_format.right_indent = Inches(0.5)
        title.add_run('浅谈\t“理性')
        title.add_run().add_break()
        title.add_run('人” 的符号化意义')
        doc.add_paragraph('——课程论文排版测试')
        doc.add_paragraph('2024202624 李泓羲')
        doc.add_paragraph("摘要")
        doc.add_paragraph("本文围绕课程论文格式统一展开，说明自动排版、字体检查与交叉引用处理的基本方法。")
        doc.add_paragraph("关键词：")
        doc.add_paragraph("课程论文；格式规范；自动排版")
        doc.add_paragraph("一、一、引言")
        p = doc.add_paragraph(); p.add_run('这是一段“中文引号”和').bold = False; p.add_run("加粗强调").bold = True; p.add_run('，并包含 JSON {"key":"value"}。如图'); p.add_run("1"); p.add_run("所示。")
        p = doc.add_paragraph(); p.add_run('研究者将"'); p.add_run('数字劳动'); p.add_run('"视为一种分析概念。')
        doc.add_paragraph('即使该段未分类，也要把"平台治理"改成中文引号。')
        doc.add_paragraph('本文称"平台效应"，同时保留 JSON {"key":"value"}，并保留5"单位符号。')
        doc.add_paragraph('内容控件中的"制度创新"也要转换。')
        doc.add_paragraph('超链接中的"平台规则"也要转换。')
        doc.add_paragraph("图1 测试图片")
        pic = doc.add_paragraph(); pic.add_run().add_picture(str(png), width=Inches(0.2))
        table = doc.add_table(rows=2, cols=2); table.cell(0,0).text='"关键变量"'; table.cell(0,1).text="数值"; table.cell(1,0).text="A"; table.cell(1,1).text="1"
        doc.add_paragraph("参考文献")
        doc.add_paragraph("[1] 张三. 测试文献[J]. 测试学报, 2024, 1(1): 1-2.")
        doc.save(src)
        inject_rogue_metrics(src)
        inv=d/'inv.json'; plan=d/'plan.json'; out=d/'out.docx'; report=d/'report.md'
        run(str(HERE/'inspect_docx.py'), str(src), '--out', str(inv))
        data=json.loads(inv.read_text(encoding='utf-8'))
        plan_data=data['plan_scaffold']
        for item in data['paragraphs']:
            if '即使该段未分类' in item.get('text', ''):
                plan_data['paragraph_roles'][str(item['index'])] = 'no_change'
        plan_data['request_overrides']={'body_font_size_pt': {'value': 12, 'source': 'current_user_request', 'evidence': '正文统一改为小四号'}}
        plan_data['style_overrides']={'body': {'font_size_pt': 12}}
        plan_data.setdefault('options', {})['ruc_header'] = {
            'enabled': True,
            'scope': 'all_pages',
            'logo_width_cm': 3.85,
            'header_distance_cm': 1.5,
            'replace_existing': True
        }
        plan.write_text(json.dumps(plan_data,ensure_ascii=False),encoding='utf-8')
        run(str(HERE/'format_academic_docx.py'), str(src), str(out), '--plan', str(plan), '--report', str(report))
        root=visible_xml(out); text=''.join(root.xpath('.//w:t/text()',namespaces=NS))
        title_p = root.xpath('./w:body/w:p[1]', namespaces=NS)[0]
        title_text = ''.join(title_p.xpath('.//w:t/text()', namespaces=NS))
        assert title_text == '浅谈“理性人”的符号化意义', title_text
        assert not title_p.xpath('.//w:tab|.//w:br|.//w:cr', namespaces=NS)
        assert not title_p.xpath('./w:pPr/w:tabs|./w:pPr/w:numPr|./w:pPr/w:pBdr|./w:pPr/w:framePr|./w:pPr/w:pStyle', namespaces=NS)
        assert title_p.xpath('./w:pPr/w:jc[@w:val="center"]', namespaces=NS)
        subtitle_p = root.xpath('./w:body/w:p[2]', namespaces=NS)[0]
        author_p = root.xpath('./w:body/w:p[3]', namespaces=NS)[0]
        assert ''.join(subtitle_p.xpath('.//w:t/text()', namespaces=NS)) == '——课程论文排版测试'
        assert ''.join(author_p.xpath('.//w:t/text()', namespaces=NS)) == '2024202624 李泓羲'
        assert subtitle_p.xpath('./w:pPr/w:jc[@w:val="center"]', namespaces=NS)
        assert author_p.xpath('./w:pPr/w:jc[@w:val="center"]', namespaces=NS)
        for p0 in (subtitle_p, author_p):
            pind = p0.find('w:pPr/w:ind', namespaces=NS)
            assert pind is not None
            for attr in ('left','right','firstLine','hanging','start','end'):
                assert pind.get(f'{{{W}}}{attr}') == '0'
        ind = title_p.find('w:pPr/w:ind', namespaces=NS)
        assert ind is not None
        for attr in ('left','right','firstLine','hanging','start','end'):
            assert ind.get(f'{{{W}}}{attr}') == '0'
        assert '“中文引号”' in text
        assert '研究者将“数字劳动”视为一种分析概念。' in text
        assert '即使该段未分类，也要把“平台治理”改成中文引号。' in text
        assert '本文称“平台效应”，同时保留 JSON {"key":"value"}，并保留5"单位符号。' in text
        assert '内容控件中的“制度创新”也要转换。' in text
        assert '超链接中的“平台规则”也要转换。' in text
        assert '“关键变量”' in text
        assert '{"key":"value"}' in text
        abstract_paras = root.xpath('.//w:body/w:p[starts-with(string(.),"［摘要］")]', namespaces=NS)
        keyword_paras = root.xpath('.//w:body/w:p[starts-with(string(.),"［关键词］")]', namespaces=NS)
        assert len(abstract_paras) == 1
        assert len(keyword_paras) == 1
        assert ''.join(abstract_paras[0].xpath('.//w:t/text()', namespaces=NS)).startswith('［摘要］本文')
        assert ''.join(keyword_paras[0].xpath('.//w:t/text()', namespaces=NS)) == '［关键词］课程论文；格式规范；自动排版'
        assert not root.xpath('.//w:body/w:p[normalize-space(string(.))="摘要" or normalize-space(string(.))="关键词："]', namespaces=NS)
        heading_paras = root.xpath('.//w:body/w:p[normalize-space(string(.))="一、引言"]', namespaces=NS)
        assert len(heading_paras) == 1
        ref_heading = root.xpath('.//w:body/w:p[normalize-space(string(.))="参考文献"]', namespaces=NS)[0]
        pb = ref_heading.find('w:pPr/w:pageBreakBefore', namespaces=NS)
        assert pb is not None and pb.get(f'{{{W}}}val', '1') not in {'0','false','off'}
        assert not heading_paras[0].xpath('./w:pPr/w:numPr|./w:pPr/w:pStyle', namespaces=NS)
        assert '一、一、引言' not in text
        abstract_runs = abstract_paras[0].xpath('./w:r', namespaces=NS)
        assert len(abstract_runs) >= 2
        label_font = abstract_runs[0].find('w:rPr/w:rFonts', namespaces=NS)
        body_font = abstract_runs[1].find('w:rPr/w:rFonts', namespaces=NS)
        assert label_font is not None and label_font.get(f'{{{W}}}eastAsia') == '黑体'
        assert body_font is not None and body_font.get(f'{{{W}}}eastAsia') == '仿宋'
        bold_run=root.xpath('.//w:r[w:t[contains(text(),"加粗强调")]]',namespaces=NS)[0]
        assert bold_run.find('w:rPr/w:b',namespaces=NS) is not None
        body_run=root.xpath('.//w:r[w:t[contains(text(),"这是一段")]]',namespaces=NS)[0]
        body_size=body_run.find('w:rPr/w:sz',namespaces=NS)
        assert body_size is not None and body_size.get(f'{{{W}}}val') == '24'
        report_text=report.read_text(encoding='utf-8')
        assert '修改状态：**已全部完成**' in report_text and 'AI生成内容：**无**' in report_text
        cap=root.xpath('.//w:p[.//w:t[contains(text(),"测试图片")]]',namespaces=NS)[0]
        sizes={x.get(f'{{{W}}}val') for x in cap.xpath('.//w:rPr/w:sz',namespaces=NS)}
        assert sizes == {'18'}, sizes
        assert root.xpath('.//w:instrText[contains(text(),"SEQ PaperFigure")]',namespaces=NS)
        assert root.xpath('.//w:instrText[contains(text(),"REF _PaperFig")]',namespaces=NS)
        assert not root.xpath('.//w:rPr/w:spacing|.//w:rPr/w:position|.//w:rPr/w:w|.//w:rPr/w:kern', namespaces=NS)
        assert not root.xpath('.//w:p[.//w:t][not(w:pPr/w:snapToGrid[@w:val="0"])]', namespaces=NS)
        with zipfile.ZipFile(out) as zf:
            settings = etree.fromstring(zf.read('word/settings.xml'))
            styles = etree.fromstring(zf.read('word/styles.xml'))
            compat = settings.xpath('.//w:compatSetting[@w:name="compatibilityMode"]', namespaces=NS)
            assert compat and compat[0].get(f'{{{W}}}val') == '15'
            update = settings.find('w:updateFields', namespaces=NS)
            assert update is not None and update.get(f'{{{W}}}val') == 'false'
            csc = settings.find('w:characterSpacingControl', namespaces=NS)
            assert csc is not None and csc.get(f'{{{W}}}val') == 'doNotCompress'
            defaults = styles.find('w:docDefaults/w:rPrDefault/w:rPr/w:rFonts', namespaces=NS)
            assert defaults is not None and defaults.get(f'{{{W}}}eastAsia') == '宋体'
            assert defaults.get(f'{{{W}}}ascii') == 'Times New Roman'
            header_names = sorted(n for n in zf.namelist() if n.startswith('word/header') and n.endswith('.xml'))
            assert header_names, 'RUC header part missing'
            header = etree.fromstring(zf.read(header_names[0]))
            assert header.xpath('.//w:drawing', namespaces=NS), 'RUC header image missing'
            assert header.xpath('.//w:pPr/w:pBdr/w:bottom[@w:val="single"]', namespaces=NS), 'header bottom border missing'
            assert not header.xpath('.//w:tab', namespaces=NS), 'header must not use tabs'
            rel_name = 'word/_rels/' + Path(header_names[0]).name + '.rels'
            assert rel_name in zf.namelist(), 'header relationships missing'
            assert any(n.startswith('word/media/') for n in zf.namelist()), 'header image asset missing from package'
        # Reopen locally with python-docx to catch package-level corruption.
        reopened = Document(out)
        assert len(reopened.paragraphs) >= 10
        run(str(HERE/'verify_formatted_docx.py'), str(out))
        # Second pass must not add another SEQ/REF/PAGE field.
        inv2=d/'inv2.json'; plan2=d/'plan2.json'; out2=d/'out2.docx'; report2=d/'report2.md'
        run(str(HERE/'inspect_docx.py'), str(out), '--out', str(inv2))
        data2=json.loads(inv2.read_text(encoding='utf-8')); plan2.write_text(json.dumps(data2['plan_scaffold'],ensure_ascii=False),encoding='utf-8')
        run(str(HERE/'format_academic_docx.py'), str(out), str(out2), '--plan', str(plan2), '--report', str(report2))
        root2=visible_xml(out2)
        for token in ('SEQ PaperFigure','REF _PaperFig',' PAGE '):
            c1=len(root.xpath(f'.//w:instrText[contains(text(),"{token}")]',namespaces=NS))
            c2=len(root2.xpath(f'.//w:instrText[contains(text(),"{token}")]',namespaces=NS))
            assert c1 == c2, (token,c1,c2)

        # Legacy layout-table front matter must remain borderless, full width,
        # and must not be converted to a three-line data table.
        tbl_src=d/'table_title_input.docx'; tbl_inv=d/'table_title_inv.json'; tbl_plan=d/'table_title_plan.json'
        tbl_out=d/'table_title_out.docx'; tbl_report=d/'table_title_report.md'
        td=Document(); td.add_paragraph('')
        t=td.add_table(rows=2, cols=1)
        tp=t.cell(0,0).paragraphs[0]; tp.alignment=1; tr=tp.add_run('浅谈\t“理性'); tr.font.size=Inches(0.31); tp.add_run().add_break(); tp.add_run('人” 的符号化意义')
        ap=t.cell(1,0).paragraphs[0]; ap.alignment=1; ap.add_run('2024202624 李泓羲').font.size=Inches(0.19)
        td.add_paragraph('摘要：本文讨论课程论文排版。'); td.add_paragraph('关键词：格式规范；WPS'); td.add_paragraph('一、引言'); td.add_paragraph('正文。'); td.save(tbl_src)
        run(str(HERE/'inspect_docx.py'), str(tbl_src), '--out', str(tbl_inv))
        tdata=json.loads(tbl_inv.read_text(encoding='utf-8')); tpdata=tdata['plan_scaffold']; tbl_plan.write_text(json.dumps(tpdata,ensure_ascii=False),encoding='utf-8')
        run(str(HERE/'format_academic_docx.py'), str(tbl_src), str(tbl_out), '--plan', str(tbl_plan), '--report', str(tbl_report))
        with zipfile.ZipFile(tbl_out) as zf:
            troot=etree.fromstring(zf.read('word/document.xml'))
            tparas=troot.xpath('.//w:tbl[1]//w:p', namespaces=NS)
            ttitle=next(p for p in tparas if '浅谈' in ''.join(p.xpath('.//w:t/text()',namespaces=NS)))
            assert ''.join(ttitle.xpath('.//w:t/text()',namespaces=NS)) == '浅谈“理性人”的符号化意义'
            assert not ttitle.xpath('.//w:tab|.//w:br|.//w:cr|./w:pPr/w:tabs|./w:pPr/w:numPr|./w:pPr/w:pBdr|./w:pPr/w:framePr|./w:pPr/w:pStyle', namespaces=NS)
            assert ttitle.xpath('./w:pPr/w:jc[@w:val="center"]',namespaces=NS)
            borders=troot.xpath('.//w:tbl[1]/w:tblPr/w:tblBorders/*',namespaces=NS)
            assert borders and all(x.get(f'{{{W}}}val') == 'nil' for x in borders)
        assert '后续手动处理：**无**' in tbl_report.read_text(encoding='utf-8')

        # Generated Chinese abstracts must be normalized before insertion and
        # independently rechecked even if role indices drift.
        gen_src=d/'generated_input.docx'; gen_inv=d/'generated_inv.json'; gen_plan=d/'generated_plan.json'
        gen_out=d/'generated_out.docx'; gen_report=d/'generated_report.md'
        gd=Document(); gd.add_paragraph('生成摘要测试'); gd.add_paragraph('一、问题提出'); gd.add_paragraph('本文讨论理性人概念及其符号化意义。'); gd.save(gen_src)
        run(str(HERE/'inspect_docx.py'), str(gen_src), '--out', str(gen_inv))
        gdata=json.loads(gen_inv.read_text(encoding='utf-8')); gp=gdata['plan_scaffold']
        gp['insertions']=[{
            'role':'abstract', 'before_paragraph':1,
            'text':'本文围绕"理性人"概念展开，并讨论＂符号化＂在课程论文中的表达。',
            'source':'model_generated', 'evidence_paragraphs':[2]
        }]
        gen_plan.write_text(json.dumps(gp,ensure_ascii=False),encoding='utf-8')
        run(str(HERE/'format_academic_docx.py'), str(gen_src), str(gen_out), '--plan', str(gen_plan), '--report', str(gen_report))
        groot=visible_xml(gen_out)
        abstracts=groot.xpath('.//w:body/w:p[starts-with(string(.),"［摘要］")]', namespaces=NS)
        assert len(abstracts)==1
        gtext=''.join(abstracts[0].xpath('.//w:t/text()', namespaces=NS))
        assert '“理性人”' in gtext and '“符号化”' in gtext, gtext
        assert '"' not in gtext and '＂' not in gtext
        run(str(HERE/'verify_formatted_docx.py'), str(gen_out))
    print('[OK] formatter regression smoke test passed')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
