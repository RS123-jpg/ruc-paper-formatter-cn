#!/usr/bin/env python3
"""Portable DOCX renderer for ChatGPT skill execution and compatibility checks.

Converts DOCX to PDF with WPS Writer or Microsoft Word on Windows, and
LibreOffice elsewhere. Rasterizes the PDF to page PNGs with PyMuPDF for visual
QA. WPS rendering is preferred for users who will open the final file in WPS.
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def run(cmd: list[str], *, env: dict[str, str] | None = None) -> None:
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=env)
    if proc.returncode != 0:
        raise RuntimeError(
            f"Command failed ({proc.returncode}): {' '.join(cmd)}\n"
            f"STDOUT:\n{proc.stdout}\nSTDERR:\n{proc.stderr}"
        )


def convert_with_libreoffice(src: Path, out_dir: Path) -> Path | None:
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if not exe:
        return None
    profile = out_dir / "lo-profile"
    profile.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env["HOME"] = str(out_dir / "home")
    Path(env["HOME"]).mkdir(parents=True, exist_ok=True)
    profile_uri = profile.resolve().as_uri()
    run([
        exe,
        "--headless",
        f"-env:UserInstallation={profile_uri}",
        "--convert-to",
        "pdf",
        "--outdir",
        str(out_dir),
        str(src),
    ], env=env)
    pdf = out_dir / f"{src.stem}.pdf"
    return pdf if pdf.exists() and pdf.stat().st_size > 0 else None


def ps_quote(value: str) -> str:
    return value.replace("'", "''")


def convert_with_wps_windows(src: Path, out_dir: Path) -> Path | None:
    """Best-effort PDF export through an installed WPS Writer COM server."""
    if os.name != "nt":
        return None
    ps = shutil.which("powershell") or shutil.which("pwsh")
    if not ps:
        return None
    pdf = out_dir / f"{src.stem}.pdf"
    script = f"""
$ErrorActionPreference = 'Stop'
$app = $null
$progIds = @('kwps.Application', 'Kwps.Application', 'wps.Application', 'Wps.Application')
foreach ($progId in $progIds) {{
  try {{ $app = New-Object -ComObject $progId; break }} catch {{ }}
}}
if ($null -eq $app) {{ throw 'WPS Writer COM automation is unavailable.' }}
$app.Visible = $false
try {{
  $doc = $app.Documents.Open('{ps_quote(str(src.resolve()))}', $false, $true)
  try {{ $doc.Repaginate() }} catch {{ }}
  $exported = $false
  try {{ $doc.ExportAsFixedFormat('{ps_quote(str(pdf.resolve()))}', 17); $exported = $true }} catch {{ }}
  if (-not $exported) {{
    try {{ $doc.SaveAs2('{ps_quote(str(pdf.resolve()))}', 17); $exported = $true }} catch {{ }}
  }}
  if (-not $exported) {{
    try {{ $doc.SaveAs('{ps_quote(str(pdf.resolve()))}', 17); $exported = $true }} catch {{ }}
  }}
  if (-not $exported) {{ throw 'WPS Writer could not export the document to PDF.' }}
  $doc.Close($false)
}} finally {{
  try {{ $app.Quit() }} catch {{ }}
}}
"""
    script_path = out_dir / "export_wps_pdf.ps1"
    script_path.write_text(script, encoding="utf-8-sig")
    try:
        run([ps, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script_path)])
    except RuntimeError:
        return None
    return pdf if pdf.exists() and pdf.stat().st_size > 0 else None


def convert_with_word_windows(src: Path, out_dir: Path) -> Path | None:
    if os.name != "nt":
        return None
    ps = shutil.which("powershell") or shutil.which("pwsh")
    if not ps:
        return None
    pdf = out_dir / f"{src.stem}.pdf"
    script = f"""
$ErrorActionPreference = 'Stop'
$word = New-Object -ComObject Word.Application
$word.Visible = $false
$word.Options.UpdateFieldsAtPrint = $false
$word.Options.UpdateLinksAtPrint = $false
try {{
  $doc = $word.Documents.Open('{ps_quote(str(src.resolve()))}', $false, $true)
  $doc.Repaginate()
  $doc.SaveAs2('{ps_quote(str(pdf.resolve()))}', 17)
  $doc.Close($false)
}} finally {{
  $word.Quit()
}}
"""
    script_path = out_dir / "export_word_pdf.ps1"
    script_path.write_text(script, encoding="utf-8-sig")
    run([ps, "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script_path)])
    return pdf if pdf.exists() and pdf.stat().st_size > 0 else None


def rasterize(pdf: Path, out_dir: Path, dpi: int) -> int:
    try:
        import fitz  # PyMuPDF
    except ImportError as exc:
        raise RuntimeError(
            "PyMuPDF is required for page PNG rendering. Run: "
            "python -m pip install -r scripts/requirements.txt"
        ) from exc
    doc = fitz.open(pdf)
    scale = dpi / 72.0
    matrix = fitz.Matrix(scale, scale)
    for index, page in enumerate(doc, start=1):
        pix = page.get_pixmap(matrix=matrix, alpha=False)
        pix.save(out_dir / f"page-{index}.png")
    count = len(doc)
    doc.close()
    return count


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_docx")
    parser.add_argument("--output_dir", required=True)
    parser.add_argument("--emit_pdf", action="store_true")
    parser.add_argument("--dpi", type=int, default=144)
    parser.add_argument("--engine", choices=["auto", "wps", "word", "libreoffice"], default="auto")
    args = parser.parse_args()

    src = Path(args.input_docx).expanduser().resolve()
    if not src.exists() or src.suffix.lower() != ".docx":
        raise SystemExit(f"Input must be an existing .docx: {src}")
    out_dir = Path(args.output_dir).expanduser().resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="docx-render-") as tmp:
        tmp_dir = Path(tmp)
        pdf = None
        method = ""
        if args.engine == "wps":
            pdf = convert_with_wps_windows(src, tmp_dir); method = "WPS Writer"
        elif args.engine == "word":
            pdf = convert_with_word_windows(src, tmp_dir); method = "Microsoft Word"
        elif args.engine == "libreoffice":
            pdf = convert_with_libreoffice(src, tmp_dir); method = "LibreOffice"
        elif os.name == "nt":
            # The target user opens the deliverable in WPS. Prefer WPS itself,
            # then Word, then LibreOffice so the QA engine matches local display.
            pdf = convert_with_wps_windows(src, tmp_dir); method = "WPS Writer"
            if pdf is None:
                pdf = convert_with_word_windows(src, tmp_dir); method = "Microsoft Word"
            if pdf is None:
                pdf = convert_with_libreoffice(src, tmp_dir); method = "LibreOffice"
        else:
            pdf = convert_with_libreoffice(src, tmp_dir); method = "LibreOffice"
            if pdf is None:
                pdf = convert_with_word_windows(src, tmp_dir); method = "Microsoft Word"
        if pdf is None:
            raise SystemExit(
                "No DOCX renderer found. On Windows install WPS Writer or Microsoft Word "
                "with PowerShell available; otherwise install LibreOffice and put soffice on PATH."
            )
        page_count = rasterize(pdf, out_dir, args.dpi)
        if args.emit_pdf:
            shutil.copy2(pdf, out_dir / pdf.name)

    print(f"Rendered {page_count} page(s) with {method} to {out_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
