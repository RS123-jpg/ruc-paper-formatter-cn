#!/usr/bin/env python3
"""Verify structural quality gates in a formatted academic DOCX."""
from __future__ import annotations

import argparse
import json
import re
import tempfile
import sys
from collections import Counter
from pathlib import Path

from lxml import etree

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from format_academic_docx import (
    ROLE_XML_FONT, count_unprotected_ascii_quotes, paragraph_should_normalize_quotes,
    quote_text_nodes, role_from_bookmarks, semantic_role_from_visible_text,
)

W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W}


def wq(name: str) -> str:
    return f"{{{W}}}{name}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("input_docx", type=Path)
    ap.add_argument("--out", type=Path)
    args = ap.parse_args()
    import zipfile
    with zipfile.ZipFile(args.input_docx) as zf:
        root = etree.fromstring(zf.read("word/document.xml"))
        bookmarks = {x.get(wq("name")) for x in root.xpath(".//w:bookmarkStart", namespaces=NS) if x.get(wq("name"))}
        fields = Counter(); broken = []
        for code in root.xpath(".//w:instrText/text()", namespaces=NS):
            clean = " ".join(code.split())
            m = re.search(r"\b(REF|NOTEREF|SEQ|PAGE)\s*([A-Za-z0-9_:\-.]*)", clean, re.I)
            if not m:
                continue
            typ, target = m.group(1).upper(), m.group(2)
            fields[typ] += 1
            if typ in {"REF", "NOTEREF"} and target and target not in bookmarks:
                broken.append(f"{typ}->{target}")
        visible = "\n".join(root.xpath(".//w:t/text()", namespaces=NS))
        reference_errors = [x for x in ["错误！未找到引用源", "Error! Reference source not found"] if x in visible]
        role_bookmarks = len([b for b in bookmarks if b.startswith("_PaperRole_")])
        font_missing = 0
        rogue_run_metrics = 0
        for p in root.xpath(".//w:p", namespaces=NS):
            role = role_from_bookmarks(p, "body")
            require_font = role in ROLE_XML_FONT
            for r in p.xpath(".//w:r[w:t]", namespaces=NS):
                if r.find("w:footnoteReference", namespaces=NS) is not None:
                    continue
                rpr = r.find("w:rPr", namespaces=NS)
                if require_font and (rpr is None or rpr.find("w:rFonts", namespaces=NS) is None or rpr.find("w:sz", namespaces=NS) is None):
                    font_missing += 1
                    continue
                if rpr is not None:
                    rogue_run_metrics += len(rpr.xpath("./w:spacing|./w:position|./w:w|./w:kern", namespaces=NS))

        # Strong quote verification over all Chinese prose paragraphs, including
        # table cells, text boxes, content controls, and hyperlinks.
        quote_remaining = 0; quote_balance_errors = 0
        top_paras = root.xpath("./w:body/w:p", namespaces=NS)
        top_index = {id(p): i for i, p in enumerate(top_paras)}
        for p in root.xpath(".//w:p", namespaces=NS):
            idx = top_index.get(id(p))
            role = role_from_bookmarks(p, "body") if idx is None else role_from_bookmarks(p, "body")
            text = "".join(t.text or "" for t in quote_text_nodes(p))
            if paragraph_should_normalize_quotes(role, text):
                quote_remaining += count_unprotected_ascii_quotes(text)
                if text.count("“") != text.count("”"):
                    quote_balance_errors += 1
        if "word/footnotes.xml" in zf.namelist():
            froot = etree.fromstring(zf.read("word/footnotes.xml"))
            for p in froot.xpath(".//w:footnote[not(@w:id='-1') and not(@w:id='0')]//w:p", namespaces=NS):
                text = "".join(t.text or "" for t in quote_text_nodes(p))
                if paragraph_should_normalize_quotes("footnote", text):
                    quote_remaining += count_unprotected_ascii_quotes(text)
                    if text.count("“") != text.count("”"):
                        quote_balance_errors += 1

        settings = etree.fromstring(zf.read("word/settings.xml")) if "word/settings.xml" in zf.namelist() else None
        compatibility_mode = None; update_fields_on_open = None; char_spacing_control = None
        if settings is not None:
            compat = settings.xpath(".//w:compatSetting[@w:name='compatibilityMode']", namespaces=NS)
            if compat: compatibility_mode = compat[0].get(wq("val"))
            upd = settings.find("w:updateFields", namespaces=NS)
            if upd is not None: update_fields_on_open = upd.get(wq("val"))
            csc = settings.find("w:characterSpacingControl", namespaces=NS)
            if csc is not None: char_spacing_control = csc.get(wq("val"))

        default_fonts_ok = False
        if "word/styles.xml" in zf.namelist():
            styles = etree.fromstring(zf.read("word/styles.xml"))
            rfonts = styles.find("w:docDefaults/w:rPrDefault/w:rPr/w:rFonts", namespaces=NS)
            default_fonts_ok = bool(rfonts is not None and rfonts.get(wq("eastAsia")) == "宋体" and rfonts.get(wq("ascii")) == "Times New Roman")

        snap_grid_missing = 0
        for p in root.xpath(".//w:p[.//w:t]", namespaces=NS):
            snap = p.find("w:pPr/w:snapToGrid", namespaces=NS)
            if snap is None or snap.get(wq("val")) not in {"0", "false", "off"}:
                snap_grid_missing += 1

        wps_frontmatter_issues = []
        for p in root.xpath("./w:body/w:p", namespaces=NS):
            text = "".join(t.text or "" for t in quote_text_nodes(p))
            role = semantic_role_from_visible_text(role_from_bookmarks(p, "body"), text)
            if role not in {"title", "subtitle", "author", "author_info"}:
                continue
            if p.xpath(".//w:tab|.//w:br|.//w:cr", namespaces=NS):
                wps_frontmatter_issues.append(f"{role}: contains tab/manual break")
            if p.find("w:pPr/w:tabs", namespaces=NS) is not None:
                wps_frontmatter_issues.append(f"{role}: contains custom tab stops")
            jc = p.find("w:pPr/w:jc", namespaces=NS)
            if jc is None or jc.get(wq("val")) != "center":
                wps_frontmatter_issues.append(f"{role}: not explicitly centered")
            ind = p.find("w:pPr/w:ind", namespaces=NS)
            if ind is None or any(ind.get(wq(a), "0") not in {"0", None} for a in ("left", "right", "firstLine", "hanging", "start", "end")):
                wps_frontmatter_issues.append(f"{role}: nonzero or missing explicit indents")
            if p.find("w:pPr/w:framePr", namespaces=NS) is not None:
                wps_frontmatter_issues.append(f"{role}: frame positioning remains")

        summary_quote_issues = []
        for p in root.xpath(".//w:p", namespaces=NS):
            text = "".join(t.text or "" for t in quote_text_nodes(p))
            role = semantic_role_from_visible_text(role_from_bookmarks(p, "body"), text)
            if role in {"abstract", "keywords"} and count_unprotected_ascii_quotes(text):
                summary_quote_issues.append(text[:100])

        # Explicit visible heading prefixes and automatic list numbering must
        # never coexist. WPS otherwise renders headings as ``一、一、引言``.
        numbered_style_ids = set()
        if "word/styles.xml" in zf.namelist():
            styles_root = etree.fromstring(zf.read("word/styles.xml"))
            for st in styles_root.xpath(".//w:style[w:pPr/w:numPr]", namespaces=NS):
                sid = st.get(wq("styleId"))
                if sid:
                    numbered_style_ids.add(sid)
        heading_numbering_issues = []
        dup_patterns = {
            "heading1": re.compile(r"^(?:[一二三四五六七八九十百]+、\s*){2,}"),
            "heading2": re.compile(r"^(?:（[一二三四五六七八九十百]+）\s*){2,}"),
            "heading3": re.compile(r"^(?:\d+[.．]\s*){2,}"),
            "heading4": re.compile(r"^(?:（\d+）\s*){2,}"),
        }
        for p in root.xpath("./w:body/w:p", namespaces=NS):
            text = "".join(t.text or "" for t in quote_text_nodes(p)).strip()
            role = semantic_role_from_visible_text(role_from_bookmarks(p, "body"), text)
            if role not in dup_patterns:
                continue
            if p.find("w:pPr/w:numPr", namespaces=NS) is not None:
                heading_numbering_issues.append(f"{role}: automatic numPr remains: {text[:60]}")
            pstyle = p.find("w:pPr/w:pStyle", namespaces=NS)
            if pstyle is not None and pstyle.get(wq("val")) in numbered_style_ids:
                heading_numbering_issues.append(f"{role}: numbered paragraph style remains: {text[:60]}")
            if dup_patterns[role].match(text):
                heading_numbering_issues.append(f"{role}: duplicated visible prefix: {text[:60]}")

        result = {
            "input": str(args.input_docx),
            "field_counts": dict(fields),
            "broken_field_targets": broken,
            "visible_reference_errors": reference_errors,
            "role_bookmarks": role_bookmarks,
            "runs_missing_explicit_font_or_size": font_missing,
            "remaining_unprotected_ascii_quotes": quote_remaining,
            "quote_balance_errors": quote_balance_errors,
            "rogue_run_metric_properties": rogue_run_metrics,
            "paragraphs_missing_snap_to_grid_off": snap_grid_missing,
            "compatibility_mode": compatibility_mode,
            "update_fields_on_open": update_fields_on_open,
            "character_spacing_control": char_spacing_control,
            "default_fonts_ok": default_fonts_ok,
            "wps_frontmatter_issues": wps_frontmatter_issues,
            "summary_straight_quote_issues": summary_quote_issues,
            "heading_numbering_issues": heading_numbering_issues,
        }
        result["passed"] = (
            not broken and not reference_errors and role_bookmarks > 0 and font_missing == 0
            and quote_remaining == 0 and quote_balance_errors == 0
            and rogue_run_metrics == 0 and snap_grid_missing == 0
            and compatibility_mode == "15" and update_fields_on_open in {"0", "false", "off"}
            and char_spacing_control == "doNotCompress" and default_fonts_ok
            and not wps_frontmatter_issues and not summary_quote_issues
            and not heading_numbering_issues
        )
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.write_text(text, encoding="utf-8")
    print(text)
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
