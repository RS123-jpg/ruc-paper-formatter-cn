#!/usr/bin/env python3
"""Automated first-pass QA for rendered DOCX page PNGs.

This does not replace human page review. It detects likely blank pages, content
clipping at page edges, inconsistent page sizes, and missing page images.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

try:
    from PIL import Image, ImageChops
except ImportError as exc:  # pragma: no cover
    raise SystemExit("Pillow is required. Run: python -m pip install -r scripts/requirements.txt") from exc


def nonwhite_bbox(image: Image.Image, threshold: int = 247):
    rgb = image.convert("RGB")
    bg = Image.new("RGB", rgb.size, (255, 255, 255))
    diff = ImageChops.difference(rgb, bg).convert("L")
    mask = diff.point(lambda p: 255 if p > (255 - threshold) else 0)
    return mask.getbbox(), mask


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("render_dir", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--edge_px", type=int, default=8)
    parser.add_argument("--blank_ratio", type=float, default=0.001)
    args = parser.parse_args()

    pages = sorted(args.render_dir.glob("page-*.png"), key=lambda p: int(p.stem.split("-")[-1]))
    result = {"page_count": len(pages), "pages": [], "warnings": [], "passed": True}
    if not pages:
        result["warnings"].append("未找到 page-*.png。")
        result["passed"] = False
    sizes = set()
    for page in pages:
        with Image.open(page) as im:
            sizes.add(im.size)
            bbox, mask = nonwhite_bbox(im)
            pixels = im.width * im.height
            nonwhite = 0 if bbox is None else mask.crop(bbox).histogram()[255]
            ratio = nonwhite / pixels if pixels else 0
            edge_touch = False
            if bbox is not None:
                left, top, right, bottom = bbox
                edge_touch = left <= args.edge_px or top <= args.edge_px or right >= im.width - args.edge_px or bottom >= im.height - args.edge_px
            page_info = {"file": page.name, "size": list(im.size), "content_ratio": round(ratio, 6), "content_bbox": list(bbox) if bbox else None, "edge_touch": edge_touch}
            result["pages"].append(page_info)
            if ratio < args.blank_ratio:
                result["warnings"].append(f"{page.name} 疑似空白页。")
            if edge_touch:
                result["warnings"].append(f"{page.name} 内容接近或触及页面边缘，可能存在裁切。")
    if len(sizes) > 1:
        result["warnings"].append("渲染页面尺寸不一致，可能存在横向分节或异常页面设置。")
    result["passed"] = not result["warnings"]
    text = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        args.out.parent.mkdir(parents=True, exist_ok=True)
        args.out.write_text(text, encoding="utf-8")
    print(text)
    return 0 if result["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
