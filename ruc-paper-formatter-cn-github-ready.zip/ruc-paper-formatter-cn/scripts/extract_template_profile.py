#!/usr/bin/env python3
"""Extract a conservative formatting profile from a DOCX template or example.

The output is a model-readable aid. It never edits the target paper and should
be reviewed before values are copied into plan.json overrides.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from docx import Document
from docx.oxml.ns import qn


def run_profile(run) -> dict[str, Any]:
    rpr = run._r.rPr
    east = None
    if rpr is not None and rpr.rFonts is not None:
        east = rpr.rFonts.get(qn("w:eastAsia"))
    return {
        "east_asia_font": east,
        "latin_font": run.font.name,
        "size_pt": run.font.size.pt if run.font.size else None,
        "bold": run.bold,
        "italic": run.italic,
    }


def paragraph_profile(p) -> dict[str, Any]:
    sample_run = next((r for r in p.runs if r.text.strip()), None)
    pf = p.paragraph_format
    return {
        "text": p.text[:120],
        "style": p.style.name if p.style else None,
        "alignment": int(p.alignment) if p.alignment is not None else None,
        "space_before_pt": pf.space_before.pt if pf.space_before else None,
        "space_after_pt": pf.space_after.pt if pf.space_after else None,
        "line_spacing": getattr(pf.line_spacing, "pt", pf.line_spacing),
        "first_line_indent_pt": pf.first_line_indent.pt if pf.first_line_indent else None,
        "run": run_profile(sample_run) if sample_run else None,
    }


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("template_docx", type=Path)
    ap.add_argument("--out", type=Path, required=True)
    args = ap.parse_args()
    doc = Document(args.template_docx)
    sections = []
    for i, s in enumerate(doc.sections):
        sections.append({
            "index": i,
            "page_width_cm": round(s.page_width.cm, 3) if s.page_width else None,
            "page_height_cm": round(s.page_height.cm, 3) if s.page_height else None,
            "top_margin_cm": round(s.top_margin.cm, 3) if s.top_margin else None,
            "bottom_margin_cm": round(s.bottom_margin.cm, 3) if s.bottom_margin else None,
            "left_margin_cm": round(s.left_margin.cm, 3) if s.left_margin else None,
            "right_margin_cm": round(s.right_margin.cm, 3) if s.right_margin else None,
            "header_distance_cm": round(s.header_distance.cm, 3) if s.header_distance else None,
            "footer_distance_cm": round(s.footer_distance.cm, 3) if s.footer_distance else None,
            "landscape": bool(s.page_width and s.page_height and s.page_width > s.page_height),
        })
    paragraphs = [paragraph_profile(p) for p in doc.paragraphs[:80] if p.text.strip()]
    styles = {}
    for name in ["Normal", "Title", "Subtitle", "Heading 1", "Heading 2", "Heading 3"]:
        if name in doc.styles:
            st = doc.styles[name]
            styles[name] = {
                "font_name": st.font.name,
                "font_size_pt": st.font.size.pt if st.font.size else None,
                "bold": st.font.bold,
                "italic": st.font.italic,
            }
    result = {"input": str(args.template_docx), "sections": sections, "styles": styles, "sample_paragraphs": paragraphs}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[OK] template profile written to {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
